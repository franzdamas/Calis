package com.example.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.core.view.MotionEventCompat;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;

/* JADX INFO: compiled from: ReminderAlarmReceiver.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001a\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0016¨\u0006\u000b"}, d2 = {"Lcom/example/util/ReminderAlarmReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "()V", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ReminderAlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_ST_TASK_REMINDER = "com.example.ACTION_ST_TASK_REMINDER";
    public static final String ACTION_TC_SESSION_REMINDER = "com.example.ACTION_TC_SESSION_REMINDER";
    private static final String TAG = "ReminderAlarmReceiver";
    public static final int $stable = 8;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action;
        Intrinsics.checkNotNullParameter(context, "context");
        if (intent != null && (action = intent.getAction()) != null) {
            Log.d(TAG, "ReminderAlarmReceiver triggered with action: " + action);
            BroadcastReceiver.PendingResult pendingResult = goAsync();
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new AnonymousClass1(action, context, intent, pendingResult, null), 3, null);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderAlarmReceiver$onReceive$1, reason: invalid class name */
    /* JADX INFO: compiled from: ReminderAlarmReceiver.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderAlarmReceiver$onReceive$1", f = "ReminderAlarmReceiver.kt", i = {}, l = {21, MotionEventCompat.AXIS_GENERIC_7}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $action;
        final /* synthetic */ Context $context;
        final /* synthetic */ Intent $intent;
        final /* synthetic */ BroadcastReceiver.PendingResult $pendingResult;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, Context context, Intent intent, BroadcastReceiver.PendingResult pendingResult, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$action = str;
            this.$context = context;
            this.$intent = intent;
            this.$pendingResult = pendingResult;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass1(this.$action, this.$context, this.$intent, this.$pendingResult, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Code duplicated, block: B:54:0x00e5 A[RETURN] */
        /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String str = this.$action;
                        switch (str.hashCode()) {
                            case -1787487905:
                                if (!str.equals("android.intent.action.QUICKBOOT_POWERON")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case -1417835046:
                                if (!str.equals("com.htc.intent.action.QUICKBOOT_POWERON")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case -905063602:
                                if (!str.equals("android.intent.action.LOCKED_BOOT_COMPLETED")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 502473491:
                                if (!str.equals("android.intent.action.TIMEZONE_CHANGED")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 505380757:
                                if (!str.equals("android.intent.action.TIME_SET")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 798292259:
                                if (!str.equals("android.intent.action.BOOT_COMPLETED")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 1041332296:
                                if (!str.equals("android.intent.action.DATE_CHANGED")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 1737074039:
                                if (!str.equals("android.intent.action.MY_PACKAGE_REPLACED")) {
                                    return Unit.INSTANCE;
                                }
                                Log.d(ReminderAlarmReceiver.TAG, "System time/date or boot change (" + this.$action + ") received - re-evaluating reminders");
                                ReminderNotificationHelper.INSTANCE.clearSessionReminderKeys(this.$context);
                                ReminderNotificationHelper.INSTANCE.clearTaskReminderKeys(this.$context);
                                this.label = 2;
                                if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                return Unit.INSTANCE;
                            case 1845640947:
                                if (!str.equals(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER)) {
                                    return Unit.INSTANCE;
                                }
                                this.label = 1;
                                if (ReminderNotificationHelper.INSTANCE.handleSessionReminderAlarmTrigger(this.$context, this.$intent, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                return Unit.INSTANCE;
                            case 2032398982:
                                if (str.equals(ReminderAlarmReceiver.ACTION_ST_TASK_REMINDER)) {
                                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                                }
                                return Unit.INSTANCE;
                            default:
                                return Unit.INSTANCE;
                        }
                    case 1:
                        ResultKt.throwOnFailure($result);
                        return Unit.INSTANCE;
                    case 2:
                        ResultKt.throwOnFailure($result);
                        ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } catch (Exception e) {
                Log.e(ReminderAlarmReceiver.TAG, "Error in ReminderAlarmReceiver", e);
            } finally {
                this.$pendingResult.finish();
            }
        }
    }
}
