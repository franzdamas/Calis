package com.example.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: ScheduleUtils.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005J\u0016\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u0005J\u001e\u0010\t\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005J\u000e\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u0005¨\u0006\u0010"}, d2 = {"Lcom/example/util/ScheduleUtils;", "", "<init>", "()V", "getTodayDateString", "", "isTodayInSchedule", "", "daysString", "isDayInSchedule", "calendar", "Ljava/util/Calendar;", "abbr", "fullName", "formatDisplayTime", "raw", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ScheduleUtils {
    public static final int $stable = 0;
    public static final ScheduleUtils INSTANCE = new ScheduleUtils();

    private ScheduleUtils() {
    }

    public final String getTodayDateString() {
        String str = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    public final boolean isTodayInSchedule(String daysString) {
        Intrinsics.checkNotNullParameter(daysString, "daysString");
        if (StringsKt.isBlank(daysString)) {
            return true;
        }
        Calendar calendar = Calendar.getInstance();
        Intrinsics.checkNotNullExpressionValue(calendar, "getInstance(...)");
        return isDayInSchedule(calendar, daysString);
    }

    public final boolean isDayInSchedule(Calendar calendar, String daysString) {
        Pair pair;
        Intrinsics.checkNotNullParameter(calendar, "calendar");
        Intrinsics.checkNotNullParameter(daysString, "daysString");
        if (StringsKt.isBlank(daysString)) {
            return true;
        }
        int dayOfWeek = calendar.get(7);
        switch (dayOfWeek) {
            case 1:
                pair = TuplesKt.to("SUN", "Sunday");
                break;
            case 2:
                pair = TuplesKt.to("MON", "Monday");
                break;
            case 3:
                pair = TuplesKt.to("TUE", "Tuesday");
                break;
            case 4:
                pair = TuplesKt.to("WED", "Wednesday");
                break;
            case 5:
                pair = TuplesKt.to("THU", "Thursday");
                break;
            case 6:
                pair = TuplesKt.to("FRI", "Friday");
                break;
            case 7:
                pair = TuplesKt.to("SAT", "Saturday");
                break;
            default:
                pair = TuplesKt.to("", "");
                break;
        }
        String abbr = (String) pair.component1();
        String fullName = (String) pair.component2();
        return isDayInSchedule(abbr, fullName, daysString);
    }

    /* JADX WARN: Code duplicated, block: B:115:0x025d  */
    /* JADX WARN: Code duplicated, block: B:122:0x0272  */
    /* JADX WARN: Code duplicated, block: B:129:0x0286  */
    /* JADX WARN: Code duplicated, block: B:136:0x029a  */
    /* JADX WARN: Code duplicated, block: B:143:0x02ae  */
    /* JADX WARN: Code duplicated, block: B:150:0x02c2  */
    /* JADX WARN: Code duplicated, block: B:157:0x02d9  */
    /* JADX WARN: Code duplicated, block: B:294:0x025c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:327:0x0285 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:331:0x02c1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:336:0x0271 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:338:0x02ad A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:343:0x0299 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:348:0x02d8 A[SYNTHETIC] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final boolean isDayInSchedule(String abbr, String fullName, String daysString) {
        int i;
        char c;
        String str;
        String str2;
        int startIdx;
        int endIdx;
        Intrinsics.checkNotNullParameter(abbr, "abbr");
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        Intrinsics.checkNotNullParameter(daysString, "daysString");
        String upperCase = daysString.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        String upper = StringsKt.trim((CharSequence) upperCase).toString();
        if (upper.length() == 0) {
            return false;
        }
        if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "MON-FRI", false, 2, (Object) null)) {
            i = 5;
        } else {
            i = 5;
            if (!StringsKt.contains$default((CharSequence) upper, (CharSequence) "MON - FRI", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "MONDAY TO FRIDAY", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "MONDAY - FRIDAY", false, 2, (Object) null)) {
                if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "MON-SAT", false, 2, (Object) null)) {
                    c = 1;
                } else {
                    c = 1;
                    if (!StringsKt.contains$default((CharSequence) upper, (CharSequence) "MON - SAT", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "MONDAY TO SATURDAY", false, 2, (Object) null)) {
                        if (!StringsKt.contains$default((CharSequence) upper, (CharSequence) "DAILY", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "EVERYDAY", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "MON-SUN", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) "ALL DAYS", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper, (CharSequence) abbr, false, 2, (Object) null)) {
                            String upperCase2 = fullName.toUpperCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                            if (!StringsKt.contains$default((CharSequence) upper, (CharSequence) upperCase2, false, 2, (Object) null)) {
                                Iterable iterableSplit = new Regex("[-/,\\s]+").split(upper, 0);
                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterableSplit, 10));
                                Iterator it = iterableSplit.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(StringsKt.trim((CharSequence) it.next()).toString());
                                }
                                Collection arrayList2 = new ArrayList();
                                for (Object obj : (List) arrayList) {
                                    if (((String) obj).length() > 0) {
                                        arrayList2.add(obj);
                                    }
                                }
                                List tokens = (List) arrayList2;
                                Iterator it2 = tokens.iterator();
                                while (true) {
                                    String str3 = "TU";
                                    String str4 = "TH";
                                    if (!it2.hasNext()) {
                                        if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "-", false, 2, (Object) null)) {
                                            Iterable iterableSplit$default = StringsKt.split$default((CharSequence) upper, new String[]{"-"}, false, 0, 6, (Object) null);
                                            Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterableSplit$default, 10));
                                            Iterator it3 = iterableSplit$default.iterator();
                                            while (it3.hasNext()) {
                                                arrayList3.add(StringsKt.trim((CharSequence) it3.next()).toString());
                                                iterableSplit$default = iterableSplit$default;
                                            }
                                            List parts = (List) arrayList3;
                                            if (parts.size() == 2) {
                                                List dayOrder = CollectionsKt.listOf((Object[]) new String[]{"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"});
                                                List list = dayOrder;
                                                int i2 = 0;
                                                int i3 = 0;
                                                Iterator it4 = list.iterator();
                                                while (true) {
                                                    List list2 = list;
                                                    if (it4.hasNext()) {
                                                        String str5 = (String) it4.next();
                                                        int i4 = i2;
                                                        int i5 = i3;
                                                        str = str3;
                                                        str2 = str4;
                                                        if (StringsKt.startsWith$default((String) parts.get(0), str5, false, 2, (Object) null) || StringsKt.startsWith$default(str5, (String) parts.get(0), false, 2, (Object) null)) {
                                                            startIdx = i5;
                                                        } else {
                                                            i3 = i5 + 1;
                                                            list = list2;
                                                            i2 = i4;
                                                            str3 = str;
                                                            str4 = str2;
                                                        }
                                                    } else {
                                                        str = str3;
                                                        str2 = str4;
                                                        startIdx = -1;
                                                    }
                                                }
                                                List list3 = dayOrder;
                                                int i6 = 0;
                                                int i7 = 0;
                                                Iterator it5 = list3.iterator();
                                                while (true) {
                                                    if (it5.hasNext()) {
                                                        List list4 = list3;
                                                        String str6 = (String) it5.next();
                                                        int i8 = i6;
                                                        int i9 = i7;
                                                        Iterator it6 = it5;
                                                        if (StringsKt.startsWith$default((String) parts.get(1), str6, false, 2, (Object) null) || StringsKt.startsWith$default(str6, (String) parts.get(1), false, 2, (Object) null)) {
                                                            endIdx = i9;
                                                        } else {
                                                            i7 = i9 + 1;
                                                            list3 = list4;
                                                            i6 = i8;
                                                            it5 = it6;
                                                        }
                                                    } else {
                                                        endIdx = -1;
                                                    }
                                                }
                                                int currentIdx = dayOrder.indexOf(abbr);
                                                if (startIdx != -1 && endIdx != -1 && currentIdx != -1) {
                                                    if (startIdx <= endIdx) {
                                                        if (startIdx <= currentIdx && currentIdx <= endIdx) {
                                                            return true;
                                                        }
                                                    } else if (currentIdx >= startIdx || currentIdx <= endIdx) {
                                                        return true;
                                                    }
                                                }
                                            } else {
                                                str = "TU";
                                                str2 = "TH";
                                            }
                                        } else {
                                            str = "TU";
                                            str2 = "TH";
                                        }
                                        if (Intrinsics.areEqual(abbr, "MON") && (StringsKt.contains$default((CharSequence) upper, (CharSequence) "M,", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "M-", false, 2, (Object) null) || StringsKt.startsWith$default(upper, "M", false, 2, (Object) null))) {
                                            return true;
                                        }
                                        if (Intrinsics.areEqual(abbr, "TUE") && (StringsKt.contains$default((CharSequence) upper, (CharSequence) "T,", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) str, false, 2, (Object) null))) {
                                            return true;
                                        }
                                        if (Intrinsics.areEqual(abbr, "WED") && (StringsKt.contains$default((CharSequence) upper, (CharSequence) "W,", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "W-", false, 2, (Object) null))) {
                                            return true;
                                        }
                                        if (Intrinsics.areEqual(abbr, "THU") && (StringsKt.contains$default((CharSequence) upper, (CharSequence) "TH,", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) str2, false, 2, (Object) null))) {
                                            return true;
                                        }
                                        if (Intrinsics.areEqual(abbr, "FRI")) {
                                            return StringsKt.contains$default((CharSequence) upper, (CharSequence) "F,", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "F-", false, 2, (Object) null);
                                        }
                                        return false;
                                    }
                                    String token = (String) it2.next();
                                    switch (token.hashCode()) {
                                        case -2015173360:
                                            if (token.equals("MONDAY")) {
                                                if (Intrinsics.areEqual(abbr, "MON")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case -1940284966:
                                            if (token.equals("THURSDAY")) {
                                                if (Intrinsics.areEqual(abbr, "THU")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case -1837857328:
                                            if (token.equals("SUNDAY")) {
                                                if (Intrinsics.areEqual(abbr, "SUN")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case -1331574855:
                                            if (token.equals("SATURDAY")) {
                                                if (Intrinsics.areEqual(abbr, "SAT")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case -259361235:
                                            if (token.equals("TUESDAY")) {
                                                if (Intrinsics.areEqual(abbr, "TUE")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case -114841802:
                                            if (token.equals("WEDNESDAY")) {
                                                if (Intrinsics.areEqual(abbr, "WED")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 70:
                                            if (token.equals("F")) {
                                                if (Intrinsics.areEqual(abbr, "FRI")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 77:
                                            if (token.equals("M")) {
                                                if (Intrinsics.areEqual(abbr, "MON")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 84:
                                            if (token.equals("T")) {
                                                if (Intrinsics.areEqual(abbr, "TUE")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 87:
                                            if (token.equals("W")) {
                                                if (Intrinsics.areEqual(abbr, "WED")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2638:
                                            if (token.equals("SA")) {
                                                if (Intrinsics.areEqual(abbr, "SAT")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2658:
                                            if (token.equals("SU")) {
                                                if (Intrinsics.areEqual(abbr, "SUN")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2676:
                                            if (token.equals("TH")) {
                                                if (Intrinsics.areEqual(abbr, "THU")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2689:
                                            if (token.equals("TU")) {
                                                if (Intrinsics.areEqual(abbr, "TUE")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 69885:
                                            if (token.equals("FRI")) {
                                                if (Intrinsics.areEqual(abbr, "FRI")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 76524:
                                            if (token.equals("MON")) {
                                                if (Intrinsics.areEqual(abbr, "MON")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 81862:
                                            if (token.equals("SAT")) {
                                                if (Intrinsics.areEqual(abbr, "SAT")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 82476:
                                            if (token.equals("SUN")) {
                                                if (Intrinsics.areEqual(abbr, "SUN")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 83041:
                                            if (token.equals("THU")) {
                                                if (Intrinsics.areEqual(abbr, "THU")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 83428:
                                            if (token.equals("TUE")) {
                                                if (Intrinsics.areEqual(abbr, "TUE")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 85814:
                                            if (token.equals("WED")) {
                                                if (Intrinsics.areEqual(abbr, "WED")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2574353:
                                            if (token.equals("THUR")) {
                                                if (Intrinsics.areEqual(abbr, "THU")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2586351:
                                            if (token.equals("TUES")) {
                                                if (Intrinsics.areEqual(abbr, "TUE")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        case 2082011487:
                                            if (token.equals("FRIDAY")) {
                                                if (Intrinsics.areEqual(abbr, "FRI")) {
                                                    return true;
                                                }
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                        return true;
                    }
                }
                String[] strArr = new String[6];
                strArr[0] = "MON";
                strArr[c] = "TUE";
                strArr[2] = "WED";
                strArr[3] = "THU";
                strArr[4] = "FRI";
                strArr[5] = "SAT";
                return CollectionsKt.listOf((Object[]) strArr).contains(abbr);
            }
        }
        String[] strArr2 = new String[i];
        strArr2[0] = "MON";
        strArr2[1] = "TUE";
        strArr2[2] = "WED";
        strArr2[3] = "THU";
        strArr2[4] = "FRI";
        return CollectionsKt.listOf((Object[]) strArr2).contains(abbr);
    }

    public final String formatDisplayTime(String raw) {
        boolean z;
        Intrinsics.checkNotNullParameter(raw, "raw");
        if (StringsKt.isBlank(raw)) {
            return "--:--";
        }
        String trimmed = StringsKt.trim((CharSequence) raw).toString();
        if (StringsKt.contains((CharSequence) trimmed, (CharSequence) "AM", true) || StringsKt.contains((CharSequence) trimmed, (CharSequence) "PM", true)) {
            return trimmed;
        }
        if (trimmed.length() == 4) {
            String str = trimmed;
            int i = 0;
            while (true) {
                if (i < str.length()) {
                    if (!Character.isDigit(str.charAt(i))) {
                        z = false;
                        break;
                    }
                    i++;
                } else {
                    z = true;
                    break;
                }
            }
            if (z) {
                String strSubstring = trimmed.substring(0, 2);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                Integer intOrNull = StringsKt.toIntOrNull(strSubstring);
                int hour = intOrNull != null ? intOrNull.intValue() : 0;
                String min = trimmed.substring(2, 4);
                Intrinsics.checkNotNullExpressionValue(min, "substring(...)");
                int displayHour = 12;
                String period = hour >= 12 ? "PM" : "AM";
                if (hour != 0) {
                    displayHour = 1 <= hour && hour < 13 ? hour : hour - 12;
                }
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                String str2 = String.format(Locale.US, "%d:%s %s", Arrays.copyOf(new Object[]{Integer.valueOf(displayHour), min, period}, 3));
                Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
                return str2;
            }
        }
        return raw;
    }
}
