package com.example.util;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.util.Log;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AutoStartUtils.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/example/util/AutoStartUtils;", "", "<init>", "()V", "TAG", "", "isIgnoringBatteryOptimizations", "", "context", "Landroid/content/Context;", "openAutoStartOrAppSettings", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AutoStartUtils {
    public static final int $stable = 0;
    public static final AutoStartUtils INSTANCE = new AutoStartUtils();
    private static final String TAG = "AutoStartUtils";

    private AutoStartUtils() {
    }

    public final boolean isIgnoringBatteryOptimizations(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            Object systemService = context.getSystemService("power");
            PowerManager powerManager = systemService instanceof PowerManager ? (PowerManager) systemService : null;
            return powerManager != null && powerManager.isIgnoringBatteryOptimizations(context.getPackageName());
        } catch (Exception e) {
            Log.e(TAG, "Error checking battery optimization", e);
            return false;
        }
    }

    public final void openAutoStartOrAppSettings(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        List oemIntents = CollectionsKt.listOf((Object[]) new Intent[]{new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")), new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerSettings")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")), new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")), new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")), new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")), new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")), new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity")), new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity")), new Intent().setComponent(new ComponentName("com.transsion.phonemanager", "com.transsion.phonemanager.settings.StartupManagerActivity"))});
        for (Object obj : oemIntents) {
            Intrinsics.checkNotNullExpressionValue(obj, "next(...)");
            Intent intent = (Intent) obj;
            try {
                intent.addFlags(268435456);
                if (intent.resolveActivity(context.getPackageManager()) != null) {
                    context.startActivity(intent);
                    return;
                }
                continue;
            } catch (Exception e) {
            }
        }
        try {
            Intent batteryIntent = new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
            batteryIntent.addFlags(268435456);
            if (batteryIntent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(batteryIntent);
                return;
            }
        } catch (Exception e2) {
            Log.w(TAG, "Failed to launch battery optimization settings", e2);
        }
        try {
            Intent appInfoIntent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
            appInfoIntent.setData(Uri.fromParts("package", context.getPackageName(), null));
            appInfoIntent.addFlags(268435456);
            context.startActivity(appInfoIntent);
        } catch (Exception e3) {
            Log.e(TAG, "Failed to open App Info settings", e3);
        }
    }
}
