package com.example.util;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.activity.result.ActivityResultLauncher;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationRequestCompat;
import io.ktor.sse.ServerSentEventKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: BlePermissionUtils.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\n\u001a\u0004\u0018\u00010\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0005J\u0011\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\u0002\u0010\u0010J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\u0005J\u000e\u0010\u0013\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\u0005J\u000e\u0010\u0014\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\u0005J\u000e\u0010\u0015\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\u0005J \u0010\u0016\u001a\u00020\u00172\u0006\u0010\f\u001a\u00020\u00052\u0010\b\u0002\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u0019J.\u0010\u001a\u001a\u00020\u00172\b\u0010\u001b\u001a\u0004\u0018\u00010\u000b2\u000e\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u001c\u0018\u00010\u00192\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00170\u001eJ\u000e\u0010\u001f\u001a\u00020\u000f2\u0006\u0010 \u001a\u00020\u000fJ&\u0010!\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020\u000f2\u0006\u0010#\u001a\u00020\u000f2\u0006\u0010 \u001a\u00020\u000f2\u0006\u0010$\u001a\u00020\u000fJ\u001a\u0010%\u001a\u00020\u000f2\u0006\u0010&\u001a\u00020\u000f2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005J\u001a\u0010'\u001a\u00020\u000f2\u0006\u0010&\u001a\u00020\u000f2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t¨\u0006("}, d2 = {"Lcom/example/util/BlePermissionUtils;", "", "<init>", "()V", "appContext", "Landroid/content/Context;", "getAppContext", "()Landroid/content/Context;", "setAppContext", "(Landroid/content/Context;)V", "findActivity", "Landroid/app/Activity;", "context", "getRequiredPermissions", "", "", "()[Ljava/lang/String;", "hasPermissions", "", "isBluetoothEnabled", "isLocationEnabled", "hasNotificationPermission", "requestNotificationPermission", "", "launcher", "Landroidx/activity/result/ActivityResultLauncher;", "requestEnableBluetooth", "activity", "Landroid/content/Intent;", "onEnabling", "Lkotlin/Function0;", "formatMiddleInitials", "middleName", "formatTeacherName", "honorific", "firstName", "surname", "formatTeacherNameWithMiddleInitial", "fullName", "formatStudentNameWithMiddleInitial", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class BlePermissionUtils {
    private static volatile Context appContext;
    public static final BlePermissionUtils INSTANCE = new BlePermissionUtils();
    public static final int $stable = 8;

    private BlePermissionUtils() {
    }

    public final Context getAppContext() {
        return appContext;
    }

    public final void setAppContext(Context context) {
        appContext = context;
    }

    public final Activity findActivity(Context context) {
        Context currentContext = context == null ? appContext : context;
        while (currentContext instanceof ContextWrapper) {
            if (currentContext instanceof Activity) {
                return (Activity) currentContext;
            }
            currentContext = ((ContextWrapper) currentContext).getBaseContext();
        }
        if (currentContext instanceof Activity) {
            return (Activity) currentContext;
        }
        return null;
    }

    public final String[] getRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return new String[]{"android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT"};
        }
        return new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"};
    }

    public final boolean hasPermissions(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        String[] permissions = getRequiredPermissions();
        int length = permissions.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                return true;
            }
            if (!(ContextCompat.checkSelfPermission(context, permissions[i]) == 0)) {
                return false;
            }
            i++;
        }
    }

    public final boolean isBluetoothEnabled(Context context) {
        BluetoothAdapter adapter;
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            Object systemService = context.getSystemService("bluetooth");
            BluetoothManager manager = systemService instanceof BluetoothManager ? (BluetoothManager) systemService : null;
            return (manager == null || (adapter = manager.getAdapter()) == null || !adapter.isEnabled()) ? false : true;
        } catch (Throwable th) {
            return false;
        }
    }

    public final boolean isLocationEnabled(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (Build.VERSION.SDK_INT >= 31) {
            return true;
        }
        Object systemService = context.getSystemService("location");
        LocationManager locationManager = systemService instanceof LocationManager ? (LocationManager) systemService : null;
        if (locationManager != null && locationManager.isProviderEnabled("gps")) {
            return true;
        }
        return locationManager != null && locationManager.isProviderEnabled("network");
    }

    public final boolean hasNotificationPermission(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (Build.VERSION.SDK_INT >= 33) {
            return ContextCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") == 0;
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void requestNotificationPermission$default(BlePermissionUtils blePermissionUtils, Context context, ActivityResultLauncher activityResultLauncher, int i, Object obj) {
        if ((i & 2) != 0) {
            activityResultLauncher = null;
        }
        blePermissionUtils.requestNotificationPermission(context, activityResultLauncher);
    }

    public final void requestNotificationPermission(Context context, ActivityResultLauncher<String> launcher) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (Build.VERSION.SDK_INT >= 33) {
            Activity activity = findActivity(context);
            if (activity != null) {
                try {
                    ActivityCompat.requestPermissions(activity, new String[]{"android.permission.POST_NOTIFICATIONS"}, LocationRequestCompat.QUALITY_BALANCED_POWER_ACCURACY);
                    return;
                } catch (Throwable e) {
                    Log.e("BlePermissionUtils", "Error requesting POST_NOTIFICATIONS via Activity", e);
                }
            }
            if (launcher != null) {
                try {
                    launcher.launch("android.permission.POST_NOTIFICATIONS");
                    return;
                } catch (Throwable e2) {
                    Log.e("BlePermissionUtils", "Error requesting POST_NOTIFICATIONS via launcher", e2);
                }
            }
        }
        try {
            Intent intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
            intent.putExtra("android.provider.extra.APP_PACKAGE", context.getPackageName());
            intent.putExtra("android.provider.extra.APP_PACKAGE", context.getPackageName());
            intent.putExtra("app_package", context.getPackageName());
            intent.putExtra("app_uid", context.getApplicationInfo().uid);
            intent.addFlags(268435456);
            context.startActivity(intent);
        } catch (Throwable th) {
            try {
                Intent appDetailsIntent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                appDetailsIntent.setData(Uri.fromParts("package", context.getPackageName(), null));
                appDetailsIntent.addFlags(268435456);
                context.startActivity(appDetailsIntent);
            } catch (Throwable th2) {
            }
        }
    }

    public final void requestEnableBluetooth(Activity activity, ActivityResultLauncher<Intent> launcher, Function0<Unit> onEnabling) {
        Intrinsics.checkNotNullParameter(onEnabling, "onEnabling");
        onEnabling.invoke();
        Activity realActivity = activity == null ? findActivity(appContext) : activity;
        Activity context = realActivity != null ? realActivity : appContext;
        if (Build.VERSION.SDK_INT < 33) {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                boolean success = false;
                if (adapter != null && adapter.enable()) {
                    success = true;
                }
                if (success) {
                    return;
                }
            } catch (Throwable th) {
            }
        }
        try {
            Intent intent = new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE");
            if (launcher != null) {
                launcher.launch(intent);
            } else if (activity != null) {
                activity.startActivityForResult(intent, 1001);
            } else if (context != null) {
                intent.addFlags(268435456);
                context.startActivity(intent);
            }
        } catch (Throwable th2) {
            try {
                Intent settingsIntent = new Intent("android.settings.BLUETOOTH_SETTINGS");
                settingsIntent.addFlags(268435456);
                Activity activity2 = activity != null ? activity : context;
                if (activity2 != null) {
                    activity2.startActivity(settingsIntent);
                    Unit unit = Unit.INSTANCE;
                }
            } catch (Throwable th3) {
                Unit unit2 = Unit.INSTANCE;
            }
        }
    }

    public final String formatMiddleInitials(String middleName) {
        Character letter;
        Intrinsics.checkNotNullParameter(middleName, "middleName");
        String trimmed = StringsKt.trim((CharSequence) middleName).toString();
        if (StringsKt.isBlank(trimmed)) {
            return "";
        }
        Iterable iterableSplit = new Regex("[\\s\\-]+").split(trimmed, 0);
        Collection arrayList = new ArrayList();
        for (Object obj : iterableSplit) {
            if (!StringsKt.isBlank((String) obj)) {
                arrayList.add(obj);
            }
        }
        List<CharSequence> tokens = (List) arrayList;
        StringBuilder result = new StringBuilder();
        for (CharSequence token : tokens) {
            Iterable iterableSplit$default = StringsKt.split$default(token, new String[]{"."}, false, 0, 6, (Object) null);
            Collection arrayList2 = new ArrayList();
            for (Object obj2 : iterableSplit$default) {
                if (!StringsKt.isBlank((String) obj2)) {
                    arrayList2.add(obj2);
                }
            }
            List<CharSequence> subTokens = (List) arrayList2;
            Character letter2 = null;
            if (subTokens.size() > 1) {
                for (CharSequence sub : subTokens) {
                    CharSequence charSequence = sub;
                    int i = 0;
                    while (true) {
                        if (i < charSequence.length()) {
                            char cCharAt = charSequence.charAt(i);
                            if (Character.isLetter(cCharAt)) {
                                letter = Character.valueOf(cCharAt);
                                break;
                            }
                            i++;
                        } else {
                            letter = null;
                            break;
                        }
                    }
                    if (letter != null) {
                        result.append(Character.toUpperCase(letter.charValue()) + ".");
                    }
                }
            } else {
                CharSequence charSequence2 = token;
                for (int i2 = 0; i2 < charSequence2.length(); i2++) {
                    char cCharAt2 = charSequence2.charAt(i2);
                    if (Character.isLetter(cCharAt2)) {
                        letter2 = Character.valueOf(cCharAt2);
                        break;
                    }
                }
                if (letter2 != null) {
                    result.append(Character.toUpperCase(letter2.charValue()) + ".");
                }
            }
        }
        String string = result.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    public final String formatTeacherName(String honorific, String firstName, String middleName, String surname) {
        String nameWithMi;
        Intrinsics.checkNotNullParameter(honorific, "honorific");
        Intrinsics.checkNotNullParameter(firstName, "firstName");
        Intrinsics.checkNotNullParameter(middleName, "middleName");
        Intrinsics.checkNotNullParameter(surname, "surname");
        String h = StringsKt.trim((CharSequence) honorific).toString();
        String f = StringsKt.trim((CharSequence) firstName).toString();
        String mi = formatMiddleInitials(middleName);
        String s = StringsKt.trim((CharSequence) surname).toString();
        if (!StringsKt.isBlank(mi) && !StringsKt.isBlank(f) && !StringsKt.isBlank(s)) {
            nameWithMi = f + ServerSentEventKt.SPACE + mi + ServerSentEventKt.SPACE + s;
        } else if (StringsKt.isBlank(f) || StringsKt.isBlank(s)) {
            nameWithMi = !StringsKt.isBlank(s) ? s : f;
        } else {
            nameWithMi = f + ServerSentEventKt.SPACE + s;
        }
        if (!StringsKt.isBlank(h) && !StringsKt.isBlank(nameWithMi)) {
            return h + ServerSentEventKt.SPACE + nameWithMi;
        }
        String str = nameWithMi;
        if (StringsKt.isBlank(str)) {
            str = h;
        }
        return str;
    }

    public static /* synthetic */ String formatTeacherNameWithMiddleInitial$default(BlePermissionUtils blePermissionUtils, String str, Context context, int i, Object obj) {
        if ((i & 2) != 0) {
            context = null;
        }
        return blePermissionUtils.formatTeacherNameWithMiddleInitial(str, context);
    }

    public final String formatTeacherNameWithMiddleInitial(String fullName, Context context) {
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        String trimmed = StringsKt.trim((CharSequence) fullName).toString();
        if (StringsKt.isBlank(trimmed)) {
            return "";
        }
        Context effectiveContext = context == null ? appContext : context;
        if (effectiveContext != null) {
            try {
                SharedPreferences prefs = effectiveContext.getSharedPreferences("calis_auth_prefs", 0);
                String string = prefs.getString("teacher_first_name", null);
                String savedFirst = string != null ? StringsKt.trim((CharSequence) string).toString() : null;
                String string2 = prefs.getString("teacher_middle_name", null);
                String savedMiddle = string2 != null ? StringsKt.trim((CharSequence) string2).toString() : null;
                String string3 = prefs.getString("teacher_surname", null);
                String savedSurname = string3 != null ? StringsKt.trim((CharSequence) string3).toString() : null;
                String string4 = prefs.getString("teacher_honorific", null);
                String savedHonorific = string4 != null ? StringsKt.trim((CharSequence) string4).toString() : null;
                String str = savedFirst;
                if (!(str == null || StringsKt.isBlank(str))) {
                    String str2 = savedSurname;
                    if (!(str2 == null || StringsKt.isBlank(str2))) {
                        boolean matchesSurname = StringsKt.contains((CharSequence) trimmed, (CharSequence) savedSurname, true);
                        boolean matchesFirst = StringsKt.contains((CharSequence) trimmed, (CharSequence) savedFirst, true);
                        if (matchesSurname && matchesFirst) {
                            return formatTeacherName(savedHonorific == null ? "" : savedHonorific, savedFirst, savedMiddle == null ? "" : savedMiddle, savedSurname);
                        }
                    }
                }
            } catch (Exception e) {
            }
        }
        Iterable iterableSplit = new Regex("\\s+").split(trimmed, 0);
        Collection arrayList = new ArrayList();
        for (Object obj : iterableSplit) {
            if (!StringsKt.isBlank((String) obj)) {
                arrayList.add(obj);
            }
        }
        List parts = (List) arrayList;
        if (parts.size() <= 1) {
            return trimmed;
        }
        Set honorifics = SetsKt.setOf((Object[]) new String[]{"sir", "ma'am", "mr", "mr.", "ms", "ms.", "mrs", "mrs.", "dr", "dr.", "prof", "prof.", "bb", "bb.", "g", "g.", "gng", "gng."});
        String lowerCase = ((String) parts.get(0)).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        boolean hasHonorific = honorifics.contains(lowerCase);
        String honorific = hasHonorific ? (String) parts.get(0) : "";
        List nameParts = hasHonorific ? parts.subList(1, parts.size()) : parts;
        if (nameParts.size() <= 2) {
            String name = CollectionsKt.joinToString$default(nameParts, ServerSentEventKt.SPACE, null, null, 0, null, null, 62, null);
            return !StringsKt.isBlank(honorific) ? honorific + ServerSentEventKt.SPACE + name : name;
        }
        String surname = (String) CollectionsKt.last(nameParts);
        List firstAndMiddle = nameParts.subList(0, nameParts.size() - 1);
        String firstName = (String) firstAndMiddle.get(0);
        List middleTokens = firstAndMiddle.subList(1, firstAndMiddle.size());
        String middleInitials = formatMiddleInitials(CollectionsKt.joinToString$default(middleTokens, ServerSentEventKt.SPACE, null, null, 0, null, null, 62, null));
        String formattedName = !StringsKt.isBlank(middleInitials) ? firstName + ServerSentEventKt.SPACE + middleInitials + ServerSentEventKt.SPACE + surname : firstName + ServerSentEventKt.SPACE + surname;
        return !StringsKt.isBlank(honorific) ? honorific + ServerSentEventKt.SPACE + formattedName : formattedName;
    }

    public static /* synthetic */ String formatStudentNameWithMiddleInitial$default(BlePermissionUtils blePermissionUtils, String str, Context context, int i, Object obj) {
        if ((i & 2) != 0) {
            context = null;
        }
        return blePermissionUtils.formatStudentNameWithMiddleInitial(str, context);
    }

    public final String formatStudentNameWithMiddleInitial(String fullName, Context context) {
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        String trimmed = StringsKt.trim((CharSequence) fullName).toString();
        String str = "";
        if (StringsKt.isBlank(trimmed)) {
            return "";
        }
        Context effectiveContext = context == null ? appContext : context;
        if (effectiveContext != null) {
            try {
                SharedPreferences prefs = effectiveContext.getSharedPreferences("calis_auth_prefs", 0);
                String string = prefs.getString("student_first_name", null);
                String savedFirst = string != null ? StringsKt.trim((CharSequence) string).toString() : null;
                String string2 = prefs.getString("student_middle_name", null);
                String savedMiddle = string2 != null ? StringsKt.trim((CharSequence) string2).toString() : null;
                String string3 = prefs.getString("student_surname", null);
                String savedSurname = string3 != null ? StringsKt.trim((CharSequence) string3).toString() : null;
                String str2 = savedFirst;
                if (!(str2 == null || StringsKt.isBlank(str2))) {
                    String str3 = savedSurname;
                    if (!(str3 == null || StringsKt.isBlank(str3))) {
                        boolean matchesSurname = StringsKt.contains((CharSequence) trimmed, (CharSequence) savedSurname, true);
                        boolean matchesFirst = StringsKt.contains((CharSequence) trimmed, (CharSequence) savedFirst, true);
                        if (matchesSurname && matchesFirst) {
                            if (savedMiddle != null) {
                                str = savedMiddle;
                            }
                            String mi = formatMiddleInitials(str);
                            return (!StringsKt.isBlank(mi) ? new StringBuilder().append(savedFirst).append(ServerSentEventKt.SPACE).append(mi).append(ServerSentEventKt.SPACE).append(savedSurname) : new StringBuilder().append(savedFirst).append(ServerSentEventKt.SPACE).append(savedSurname)).toString();
                        }
                    }
                }
            } catch (Exception e) {
            }
        }
        Iterable iterableSplit = new Regex("\\s+").split(trimmed, 0);
        Collection arrayList = new ArrayList();
        for (Object obj : iterableSplit) {
            if (!StringsKt.isBlank((String) obj)) {
                arrayList.add(obj);
            }
        }
        List parts = (List) arrayList;
        if (parts.size() <= 2) {
            return trimmed;
        }
        String surname = (String) CollectionsKt.last(parts);
        List firstAndMiddle = parts.subList(0, parts.size() - 1);
        String firstName = (String) firstAndMiddle.get(0);
        List middleTokens = firstAndMiddle.subList(1, firstAndMiddle.size());
        String middleInitials = formatMiddleInitials(CollectionsKt.joinToString$default(middleTokens, ServerSentEventKt.SPACE, null, null, 0, null, null, 62, null));
        if (!StringsKt.isBlank(middleInitials)) {
            return firstName + ServerSentEventKt.SPACE + middleInitials + ServerSentEventKt.SPACE + surname;
        }
        return firstName + ServerSentEventKt.SPACE + surname;
    }
}
