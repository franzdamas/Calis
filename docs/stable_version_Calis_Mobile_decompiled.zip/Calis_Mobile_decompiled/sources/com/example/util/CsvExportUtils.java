package com.example.util;

import com.example.data.db.ApprovedStudentEntity;
import com.example.data.db.AttendanceEntity;
import com.example.data.db.ClassroomEntity;
import com.example.data.db.TaskEntity;
import com.example.data.db.TaskSubmissionEntity;
import io.ktor.sse.ServerSentEventKt;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: CsvExportUtils.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001:\u0004'()*B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J\u0010\u0010\b\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J\u000e\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0007J\u000e\u0010\u000e\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u0007J\u000e\u0010\u0011\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u0007JH\u0010\u0013\u001a\u001a\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00160\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00160\u00150\u00142\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00180\u00152\u001a\b\u0002\u0010\u0019\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070\u00140\u0015J4\u0010\u001a\u001a\u00020\u00072\b\u0010\u001b\u001a\u0004\u0018\u00010\u001c2\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00180\u00152\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00152\u0006\u0010\u001e\u001a\u00020\u001fJN\u0010 \u001a\u00020\u00072\b\u0010\u001b\u001a\u0004\u0018\u00010\u001c2\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00180\u00152\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\"0\u00152\u0018\u0010#\u001a\u0014\u0012\u0004\u0012\u00020\u0007\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\u00150$2\u0006\u0010\u001e\u001a\u00020&¨\u0006+"}, d2 = {"Lcom/example/util/CsvExportUtils;", "", "<init>", "()V", "isBoySex", "", "sex", "", "isGirlSex", "getMonthKey", "att", "Lcom/example/data/db/AttendanceEntity;", "formatMonthDisplay", "monthKey", "getNormalizedDate", "escapeCsv", "value", "formatLrnForCsv", "lrn", "partitionStudentsBySex", "Lkotlin/Pair;", "", "Lcom/example/util/CsvExportUtils$StudentItem;", "approvedStudents", "Lcom/example/data/db/ApprovedStudentEntity;", "additionalStudents", "generateAttendanceCsv", "classroom", "Lcom/example/data/db/ClassroomEntity;", "allLogs", "config", "Lcom/example/util/CsvExportUtils$AttendanceExportConfig;", "generateTasksCsv", "selectedTasks", "Lcom/example/data/db/TaskEntity;", "submissionsMap", "", "Lcom/example/data/db/TaskSubmissionEntity;", "Lcom/example/util/CsvExportUtils$TasksExportConfig;", "StudentItem", "AttendanceColumnKey", "AttendanceExportConfig", "TasksExportConfig", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CsvExportUtils {
    public static final int $stable = 0;
    public static final CsvExportUtils INSTANCE = new CsvExportUtils();

    /* JADX INFO: compiled from: CsvExportUtils.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[AttendanceColumnKey.values().length];
            try {
                iArr[AttendanceColumnKey.NO.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[AttendanceColumnKey.PRESENT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[AttendanceColumnKey.ABSENT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[AttendanceColumnKey.LATE.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[AttendanceColumnKey.STUDENT_NAME.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[AttendanceColumnKey.LRN.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr[AttendanceColumnKey.DATES.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private CsvExportUtils() {
    }

    public final boolean isBoySex(String sex) {
        String string;
        if (sex != null && (string = StringsKt.trim((CharSequence) sex).toString()) != null) {
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String s = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(s, "toLowerCase(...)");
            if (s != null) {
                if (Intrinsics.areEqual(s, "m") || Intrinsics.areEqual(s, "male") || Intrinsics.areEqual(s, "boy") || ((StringsKt.startsWith$default(s, "male", false, 2, (Object) null) && !StringsKt.startsWith$default(s, "female", false, 2, (Object) null)) || StringsKt.contains$default((CharSequence) s, (CharSequence) "boy", false, 2, (Object) null))) {
                    return !StringsKt.contains$default((CharSequence) s, (CharSequence) "female", false, 2, (Object) null);
                }
                return false;
            }
        }
        return false;
    }

    public final boolean isGirlSex(String sex) {
        String string;
        if (sex != null && (string = StringsKt.trim((CharSequence) sex).toString()) != null) {
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String s = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(s, "toLowerCase(...)");
            if (s != null) {
                return Intrinsics.areEqual(s, "f") || Intrinsics.areEqual(s, "female") || Intrinsics.areEqual(s, "girl") || StringsKt.contains$default((CharSequence) s, (CharSequence) "female", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) s, (CharSequence) "girl", false, 2, (Object) null);
            }
        }
        return false;
    }

    public final String getMonthKey(AttendanceEntity att) {
        Intrinsics.checkNotNullParameter(att, "att");
        String rawDate = StringsKt.trim((CharSequence) att.getDate()).toString();
        if (rawDate.length() >= 7 && rawDate.charAt(4) == '-') {
            String strSubstring = rawDate.substring(0, 7);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            return strSubstring;
        }
        long timestamp = att.getTimestamp();
        long millis = att.getTimestamp();
        if (timestamp < 100000000000L) {
            millis *= 1000;
        }
        if (millis > 0) {
            String str = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date(millis));
            Intrinsics.checkNotNullExpressionValue(str, "format(...)");
            return str;
        }
        try {
            Date parsed = new SimpleDateFormat("MM/dd/yyyy", Locale.US).parse((String) StringsKt.split$default((CharSequence) rawDate, new String[]{ServerSentEventKt.SPACE}, false, 0, 6, (Object) null).get(0));
            if (parsed != null) {
                String str2 = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(parsed);
                Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
                return str2;
            }
            return "Unknown";
        } catch (Exception e) {
            return "Unknown";
        }
    }

    public final String formatMonthDisplay(String monthKey) {
        Intrinsics.checkNotNullParameter(monthKey, "monthKey");
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM", Locale.getDefault());
            Date date = sdf.parse(monthKey);
            if (date != null) {
                String str = new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(date);
                Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                return str;
            }
        } catch (Exception e) {
        }
        return monthKey;
    }

    public final String getNormalizedDate(AttendanceEntity att) {
        Intrinsics.checkNotNullParameter(att, "att");
        String rawDate = StringsKt.trim((CharSequence) att.getDate()).toString();
        if (rawDate.length() >= 10 && rawDate.charAt(4) == '-' && rawDate.charAt(7) == '-') {
            String strSubstring = rawDate.substring(0, 10);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            return strSubstring;
        }
        long timestamp = att.getTimestamp();
        long millis = att.getTimestamp();
        if (timestamp < 100000000000L) {
            millis *= 1000;
        }
        if (millis > 0) {
            String str = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(millis));
            Intrinsics.checkNotNullExpressionValue(str, "format(...)");
            return str;
        }
        try {
            Date parsed = new SimpleDateFormat("MM/dd/yyyy", Locale.US).parse((String) StringsKt.split$default((CharSequence) rawDate, new String[]{ServerSentEventKt.SPACE}, false, 0, 6, (Object) null).get(0));
            if (parsed != null) {
                String str2 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(parsed);
                Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
                return str2;
            }
        } catch (Exception e) {
        }
        return rawDate;
    }

    public final String escapeCsv(String value) {
        Intrinsics.checkNotNullParameter(value, "value");
        if (!StringsKt.contains$default((CharSequence) value, (CharSequence) ",", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) value, (CharSequence) "\"", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) value, (CharSequence) "\n", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) value, (CharSequence) "\r", false, 2, (Object) null)) {
            return value;
        }
        return "\"" + StringsKt.replace$default(value, "\"", "\"\"", false, 4, (Object) null) + "\"";
    }

    public final String formatLrnForCsv(String lrn) {
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        String trimmed = StringsKt.trim((CharSequence) lrn).toString();
        return trimmed.length() == 0 ? "" : "=\"" + trimmed + "\"";
    }

    /* JADX INFO: compiled from: CsvExportUtils.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B)\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"}, d2 = {"Lcom/example/util/CsvExportUtils$StudentItem;", "", "studentId", "", "studentName", "sex", "lrn", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getStudentId", "()Ljava/lang/String;", "getStudentName", "getSex", "getLrn", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class StudentItem {
        public static final int $stable = 0;
        private final String lrn;
        private final String sex;
        private final String studentId;
        private final String studentName;

        public static /* synthetic */ StudentItem copy$default(StudentItem studentItem, String str, String str2, String str3, String str4, int i, Object obj) {
            if ((i & 1) != 0) {
                str = studentItem.studentId;
            }
            if ((i & 2) != 0) {
                str2 = studentItem.studentName;
            }
            if ((i & 4) != 0) {
                str3 = studentItem.sex;
            }
            if ((i & 8) != 0) {
                str4 = studentItem.lrn;
            }
            return studentItem.copy(str, str2, str3, str4);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getStudentId() {
            return this.studentId;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getStudentName() {
            return this.studentName;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getSex() {
            return this.sex;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getLrn() {
            return this.lrn;
        }

        public final StudentItem copy(String studentId, String studentName, String sex, String lrn) {
            Intrinsics.checkNotNullParameter(studentId, "studentId");
            Intrinsics.checkNotNullParameter(studentName, "studentName");
            Intrinsics.checkNotNullParameter(sex, "sex");
            Intrinsics.checkNotNullParameter(lrn, "lrn");
            return new StudentItem(studentId, studentName, sex, lrn);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof StudentItem)) {
                return false;
            }
            StudentItem studentItem = (StudentItem) other;
            return Intrinsics.areEqual(this.studentId, studentItem.studentId) && Intrinsics.areEqual(this.studentName, studentItem.studentName) && Intrinsics.areEqual(this.sex, studentItem.sex) && Intrinsics.areEqual(this.lrn, studentItem.lrn);
        }

        public int hashCode() {
            return (((((this.studentId.hashCode() * 31) + this.studentName.hashCode()) * 31) + this.sex.hashCode()) * 31) + this.lrn.hashCode();
        }

        public String toString() {
            return "StudentItem(studentId=" + this.studentId + ", studentName=" + this.studentName + ", sex=" + this.sex + ", lrn=" + this.lrn + ")";
        }

        public StudentItem(String studentId, String studentName, String sex, String lrn) {
            Intrinsics.checkNotNullParameter(studentId, "studentId");
            Intrinsics.checkNotNullParameter(studentName, "studentName");
            Intrinsics.checkNotNullParameter(sex, "sex");
            Intrinsics.checkNotNullParameter(lrn, "lrn");
            this.studentId = studentId;
            this.studentName = studentName;
            this.sex = sex;
            this.lrn = lrn;
        }

        public /* synthetic */ StudentItem(String str, String str2, String str3, String str4, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, str2, str3, (i & 8) != 0 ? "" : str4);
        }

        public final String getStudentId() {
            return this.studentId;
        }

        public final String getStudentName() {
            return this.studentName;
        }

        public final String getSex() {
            return this.sex;
        }

        public final String getLrn() {
            return this.lrn;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Pair partitionStudentsBySex$default(CsvExportUtils csvExportUtils, List list, List list2, int i, Object obj) {
        if ((i & 2) != 0) {
            list2 = CollectionsKt.emptyList();
        }
        return csvExportUtils.partitionStudentsBySex(list, list2);
    }

    public final Pair<List<StudentItem>, List<StudentItem>> partitionStudentsBySex(List<ApprovedStudentEntity> approvedStudents, List<Pair<String, String>> additionalStudents) {
        Intrinsics.checkNotNullParameter(approvedStudents, "approvedStudents");
        Intrinsics.checkNotNullParameter(additionalStudents, "additionalStudents");
        Map map = new LinkedHashMap();
        for (ApprovedStudentEntity s : approvedStudents) {
            map.put(s.getStudentId(), new StudentItem(s.getStudentId(), StringsKt.trim((CharSequence) s.getStudentName()).toString(), isBoySex(s.getSex()) ? "Male" : isGirlSex(s.getSex()) ? "Female" : StringsKt.trim((CharSequence) s.getSex()).toString(), StringsKt.trim((CharSequence) s.getLrn()).toString()));
        }
        for (Pair<String, String> pair : additionalStudents) {
            String id = pair.component1();
            String name = pair.component2();
            if (!map.containsKey(id)) {
                map.put(id, new StudentItem(id, StringsKt.trim((CharSequence) name).toString(), "Unspecified", null, 8, null));
            }
        }
        Iterable iterableValues = map.values();
        Collection arrayList = new ArrayList();
        for (Object obj : iterableValues) {
            if (INSTANCE.isBoySex(((StudentItem) obj).getSex())) {
                arrayList.add(obj);
            }
        }
        List boys = CollectionsKt.sortedWith((List) arrayList, new Comparator() { // from class: com.example.util.CsvExportUtils$partitionStudentsBySex$$inlined$sortedBy$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                String studentName = ((CsvExportUtils.StudentItem) t).getStudentName();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
                String lowerCase = studentName.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String studentName2 = ((CsvExportUtils.StudentItem) t2).getStudentName();
                Locale locale2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale2, "getDefault(...)");
                String lowerCase2 = studentName2.toLowerCase(locale2);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                return ComparisonsKt.compareValues(lowerCase, lowerCase2);
            }
        });
        Iterable iterableValues2 = map.values();
        Collection arrayList2 = new ArrayList();
        for (Object obj2 : iterableValues2) {
            if (INSTANCE.isGirlSex(((StudentItem) obj2).getSex())) {
                arrayList2.add(obj2);
            }
        }
        List girls = CollectionsKt.sortedWith((List) arrayList2, new Comparator() { // from class: com.example.util.CsvExportUtils$partitionStudentsBySex$$inlined$sortedBy$2
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                String studentName = ((CsvExportUtils.StudentItem) t).getStudentName();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
                String lowerCase = studentName.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String studentName2 = ((CsvExportUtils.StudentItem) t2).getStudentName();
                Locale locale2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale2, "getDefault(...)");
                String lowerCase2 = studentName2.toLowerCase(locale2);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                return ComparisonsKt.compareValues(lowerCase, lowerCase2);
            }
        });
        Iterable iterableValues3 = map.values();
        Collection arrayList3 = new ArrayList();
        for (Object obj3 : iterableValues3) {
            StudentItem studentItem = (StudentItem) obj3;
            if ((INSTANCE.isBoySex(studentItem.getSex()) || INSTANCE.isGirlSex(studentItem.getSex())) ? false : true) {
                arrayList3.add(obj3);
            }
        }
        return new Pair<>(boys, CollectionsKt.plus((Collection) girls, CollectionsKt.sortedWith((List) arrayList3, new Comparator() { // from class: com.example.util.CsvExportUtils$partitionStudentsBySex$$inlined$sortedBy$3
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                String studentName = ((CsvExportUtils.StudentItem) t).getStudentName();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
                String lowerCase = studentName.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String studentName2 = ((CsvExportUtils.StudentItem) t2).getStudentName();
                Locale locale2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue(locale2, "getDefault(...)");
                String lowerCase2 = studentName2.toLowerCase(locale2);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                return ComparisonsKt.compareValues(lowerCase, lowerCase2);
            }
        })));
    }

    /* JADX INFO: compiled from: CsvExportUtils.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\b\u0086\u0081\u0002\u0018\u0000 \u000f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000fB\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000e¨\u0006\u0010"}, d2 = {"Lcom/example/util/CsvExportUtils$AttendanceColumnKey;", "", "displayName", "", "<init>", "(Ljava/lang/String;ILjava/lang/String;)V", "getDisplayName", "()Ljava/lang/String;", "NO", "PRESENT", "ABSENT", "LATE", "STUDENT_NAME", "LRN", "DATES", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public enum AttendanceColumnKey {
        NO("No."),
        PRESENT("Present"),
        ABSENT("Absent"),
        LATE("Late"),
        STUDENT_NAME("Student Name"),
        LRN("LRN"),
        DATES("[Date]");

        private final String displayName;
        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
        public static final Companion INSTANCE = new Companion(null);
        private static final List<AttendanceColumnKey> DEFAULT_ORDER = CollectionsKt.listOf((Object[]) new AttendanceColumnKey[]{NO, PRESENT, ABSENT, LATE, STUDENT_NAME, LRN, DATES});

        public static EnumEntries<AttendanceColumnKey> getEntries() {
            return $ENTRIES;
        }

        AttendanceColumnKey(String displayName) {
            this.displayName = displayName;
        }

        public final String getDisplayName() {
            return this.displayName;
        }

        /* JADX INFO: compiled from: CsvExportUtils.kt */
        @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/example/util/CsvExportUtils$AttendanceColumnKey$Companion;", "", "<init>", "()V", "DEFAULT_ORDER", "", "Lcom/example/util/CsvExportUtils$AttendanceColumnKey;", "getDEFAULT_ORDER", "()Ljava/util/List;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            public final List<AttendanceColumnKey> getDEFAULT_ORDER() {
                return AttendanceColumnKey.DEFAULT_ORDER;
            }
        }
    }

    /* JADX INFO: compiled from: CsvExportUtils.kt */
    @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001Bk\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\b\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\u0006\u0012\b\b\u0002\u0010\n\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0004\u0012\b\b\u0002\u0010\f\u001a\u00020\u0004\u0012\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0006HÆ\u0003J\t\u0010 \u001a\u00020\u0006HÆ\u0003J\t\u0010!\u001a\u00020\u0006HÆ\u0003J\t\u0010\"\u001a\u00020\u0006HÆ\u0003J\t\u0010#\u001a\u00020\u0004HÆ\u0003J\t\u0010$\u001a\u00020\u0004HÆ\u0003J\t\u0010%\u001a\u00020\u0004HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eHÆ\u0003Jo\u0010'\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\t\u001a\u00020\u00062\b\b\u0002\u0010\n\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\u00042\b\b\u0002\u0010\f\u001a\u00020\u00042\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eHÆ\u0001J\u0013\u0010(\u001a\u00020\u00062\b\u0010)\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010*\u001a\u00020+HÖ\u0001J\t\u0010,\u001a\u00020\u0004HÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0014R\u0011\u0010\n\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\f\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001d¨\u0006-"}, d2 = {"Lcom/example/util/CsvExportUtils$AttendanceExportConfig;", "", "selectedMonths", "", "", "isMatrixLayout", "", "useShortCodes", "includeSectionHeaders", "includeAllApprovedStudents", "presentLabel", "absentLabel", "lateLabel", "columnOrder", "", "Lcom/example/util/CsvExportUtils$AttendanceColumnKey;", "<init>", "(Ljava/util/Set;ZZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getSelectedMonths", "()Ljava/util/Set;", "()Z", "getUseShortCodes", "getIncludeSectionHeaders", "getIncludeAllApprovedStudents", "getPresentLabel", "()Ljava/lang/String;", "getAbsentLabel", "getLateLabel", "getColumnOrder", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class AttendanceExportConfig {
        public static final int $stable = 8;
        private final String absentLabel;
        private final List<AttendanceColumnKey> columnOrder;
        private final boolean includeAllApprovedStudents;
        private final boolean includeSectionHeaders;
        private final boolean isMatrixLayout;
        private final String lateLabel;
        private final String presentLabel;
        private final Set<String> selectedMonths;
        private final boolean useShortCodes;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ AttendanceExportConfig copy$default(AttendanceExportConfig attendanceExportConfig, Set set, boolean z, boolean z2, boolean z3, boolean z4, String str, String str2, String str3, List list, int i, Object obj) {
            if ((i & 1) != 0) {
                set = attendanceExportConfig.selectedMonths;
            }
            if ((i & 2) != 0) {
                z = attendanceExportConfig.isMatrixLayout;
            }
            if ((i & 4) != 0) {
                z2 = attendanceExportConfig.useShortCodes;
            }
            if ((i & 8) != 0) {
                z3 = attendanceExportConfig.includeSectionHeaders;
            }
            if ((i & 16) != 0) {
                z4 = attendanceExportConfig.includeAllApprovedStudents;
            }
            if ((i & 32) != 0) {
                str = attendanceExportConfig.presentLabel;
            }
            if ((i & 64) != 0) {
                str2 = attendanceExportConfig.absentLabel;
            }
            if ((i & 128) != 0) {
                str3 = attendanceExportConfig.lateLabel;
            }
            if ((i & 256) != 0) {
                list = attendanceExportConfig.columnOrder;
            }
            String str4 = str3;
            List list2 = list;
            String str5 = str;
            String str6 = str2;
            boolean z5 = z4;
            boolean z6 = z2;
            return attendanceExportConfig.copy(set, z, z6, z3, z5, str5, str6, str4, list2);
        }

        public final Set<String> component1() {
            return this.selectedMonths;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final boolean getIsMatrixLayout() {
            return this.isMatrixLayout;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final boolean getUseShortCodes() {
            return this.useShortCodes;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final boolean getIncludeSectionHeaders() {
            return this.includeSectionHeaders;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final boolean getIncludeAllApprovedStudents() {
            return this.includeAllApprovedStudents;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getPresentLabel() {
            return this.presentLabel;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final String getAbsentLabel() {
            return this.absentLabel;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final String getLateLabel() {
            return this.lateLabel;
        }

        public final List<AttendanceColumnKey> component9() {
            return this.columnOrder;
        }

        public final AttendanceExportConfig copy(Set<String> selectedMonths, boolean isMatrixLayout, boolean useShortCodes, boolean includeSectionHeaders, boolean includeAllApprovedStudents, String presentLabel, String absentLabel, String lateLabel, List<? extends AttendanceColumnKey> columnOrder) {
            Intrinsics.checkNotNullParameter(selectedMonths, "selectedMonths");
            Intrinsics.checkNotNullParameter(presentLabel, "presentLabel");
            Intrinsics.checkNotNullParameter(absentLabel, "absentLabel");
            Intrinsics.checkNotNullParameter(lateLabel, "lateLabel");
            Intrinsics.checkNotNullParameter(columnOrder, "columnOrder");
            return new AttendanceExportConfig(selectedMonths, isMatrixLayout, useShortCodes, includeSectionHeaders, includeAllApprovedStudents, presentLabel, absentLabel, lateLabel, columnOrder);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof AttendanceExportConfig)) {
                return false;
            }
            AttendanceExportConfig attendanceExportConfig = (AttendanceExportConfig) other;
            return Intrinsics.areEqual(this.selectedMonths, attendanceExportConfig.selectedMonths) && this.isMatrixLayout == attendanceExportConfig.isMatrixLayout && this.useShortCodes == attendanceExportConfig.useShortCodes && this.includeSectionHeaders == attendanceExportConfig.includeSectionHeaders && this.includeAllApprovedStudents == attendanceExportConfig.includeAllApprovedStudents && Intrinsics.areEqual(this.presentLabel, attendanceExportConfig.presentLabel) && Intrinsics.areEqual(this.absentLabel, attendanceExportConfig.absentLabel) && Intrinsics.areEqual(this.lateLabel, attendanceExportConfig.lateLabel) && Intrinsics.areEqual(this.columnOrder, attendanceExportConfig.columnOrder);
        }

        public int hashCode() {
            return (((((((((((((((this.selectedMonths.hashCode() * 31) + Boolean.hashCode(this.isMatrixLayout)) * 31) + Boolean.hashCode(this.useShortCodes)) * 31) + Boolean.hashCode(this.includeSectionHeaders)) * 31) + Boolean.hashCode(this.includeAllApprovedStudents)) * 31) + this.presentLabel.hashCode()) * 31) + this.absentLabel.hashCode()) * 31) + this.lateLabel.hashCode()) * 31) + this.columnOrder.hashCode();
        }

        public String toString() {
            return "AttendanceExportConfig(selectedMonths=" + this.selectedMonths + ", isMatrixLayout=" + this.isMatrixLayout + ", useShortCodes=" + this.useShortCodes + ", includeSectionHeaders=" + this.includeSectionHeaders + ", includeAllApprovedStudents=" + this.includeAllApprovedStudents + ", presentLabel=" + this.presentLabel + ", absentLabel=" + this.absentLabel + ", lateLabel=" + this.lateLabel + ", columnOrder=" + this.columnOrder + ")";
        }

        /* JADX WARN: Multi-variable type inference failed */
        public AttendanceExportConfig(Set<String> selectedMonths, boolean isMatrixLayout, boolean useShortCodes, boolean includeSectionHeaders, boolean includeAllApprovedStudents, String presentLabel, String absentLabel, String lateLabel, List<? extends AttendanceColumnKey> columnOrder) {
            Intrinsics.checkNotNullParameter(selectedMonths, "selectedMonths");
            Intrinsics.checkNotNullParameter(presentLabel, "presentLabel");
            Intrinsics.checkNotNullParameter(absentLabel, "absentLabel");
            Intrinsics.checkNotNullParameter(lateLabel, "lateLabel");
            Intrinsics.checkNotNullParameter(columnOrder, "columnOrder");
            this.selectedMonths = selectedMonths;
            this.isMatrixLayout = isMatrixLayout;
            this.useShortCodes = useShortCodes;
            this.includeSectionHeaders = includeSectionHeaders;
            this.includeAllApprovedStudents = includeAllApprovedStudents;
            this.presentLabel = presentLabel;
            this.absentLabel = absentLabel;
            this.lateLabel = lateLabel;
            this.columnOrder = columnOrder;
        }

        public /* synthetic */ AttendanceExportConfig(Set set, boolean z, boolean z2, boolean z3, boolean z4, String str, String str2, String str3, List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(set, (i & 2) != 0 ? true : z, (i & 4) != 0 ? true : z2, (i & 8) != 0 ? true : z3, (i & 16) != 0 ? true : z4, (i & 32) != 0 ? "Present" : str, (i & 64) != 0 ? "Absent" : str2, (i & 128) != 0 ? "Late" : str3, (i & 256) != 0 ? AttendanceColumnKey.INSTANCE.getDEFAULT_ORDER() : list);
        }

        public final Set<String> getSelectedMonths() {
            return this.selectedMonths;
        }

        public final boolean isMatrixLayout() {
            return this.isMatrixLayout;
        }

        public final boolean getUseShortCodes() {
            return this.useShortCodes;
        }

        public final boolean getIncludeSectionHeaders() {
            return this.includeSectionHeaders;
        }

        public final boolean getIncludeAllApprovedStudents() {
            return this.includeAllApprovedStudents;
        }

        public final String getPresentLabel() {
            return this.presentLabel;
        }

        public final String getAbsentLabel() {
            return this.absentLabel;
        }

        public final String getLateLabel() {
            return this.lateLabel;
        }

        public final List<AttendanceColumnKey> getColumnOrder() {
            return this.columnOrder;
        }
    }

    public final String generateAttendanceCsv(ClassroomEntity classroom, List<ApprovedStudentEntity> approvedStudents, List<AttendanceEntity> allLogs, AttendanceExportConfig config) {
        List<AttendanceEntity> list;
        List<Pair<String, String>> listEmptyList;
        List<AttendanceEntity> list2;
        Pair<List<StudentItem>, List<StudentItem>> pairPartitionStudentsBySex;
        String classroomName;
        String teacherName;
        String dayOnly;
        Intrinsics.checkNotNullParameter(approvedStudents, "approvedStudents");
        Intrinsics.checkNotNullParameter(allLogs, "allLogs");
        Intrinsics.checkNotNullParameter(config, "config");
        if (config.getSelectedMonths().isEmpty()) {
            list = allLogs;
        } else {
            Collection arrayList = new ArrayList();
            for (Object obj : allLogs) {
                if (config.getSelectedMonths().contains(INSTANCE.getMonthKey((AttendanceEntity) obj))) {
                    arrayList.add(obj);
                }
            }
            list = (List) arrayList;
        }
        List<AttendanceEntity> list3 = list;
        if (config.getIncludeAllApprovedStudents()) {
            List<AttendanceEntity> list4 = list3;
            Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list4, 10));
            for (AttendanceEntity attendanceEntity : list4) {
                arrayList2.add(TuplesKt.to(attendanceEntity.getStudentId(), attendanceEntity.getStudentName()));
            }
            listEmptyList = (List) arrayList2;
        } else {
            listEmptyList = CollectionsKt.emptyList();
        }
        List<Pair<String, String>> list5 = listEmptyList;
        if (config.getIncludeAllApprovedStudents()) {
            pairPartitionStudentsBySex = partitionStudentsBySex(approvedStudents, list5);
            list2 = list3;
        } else {
            List<AttendanceEntity> list6 = list3;
            Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list6, 10));
            Iterator it = list6.iterator();
            while (it.hasNext()) {
                arrayList3.add(((AttendanceEntity) it.next()).getStudentId());
            }
            Set studentIdsWithLogs = CollectionsKt.toSet((List) arrayList3);
            Collection arrayList4 = new ArrayList();
            for (Object obj2 : approvedStudents) {
                if (studentIdsWithLogs.contains(((ApprovedStudentEntity) obj2).getStudentId())) {
                    arrayList4.add(obj2);
                }
            }
            List filteredApproved = (List) arrayList4;
            List<AttendanceEntity> list7 = list3;
            Collection arrayList5 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list7, 10));
            for (AttendanceEntity attendanceEntity2 : list7) {
                arrayList5.add(TuplesKt.to(attendanceEntity2.getStudentId(), attendanceEntity2.getStudentName()));
                list3 = list3;
            }
            list2 = list3;
            List additionalFromLogs = (List) arrayList5;
            pairPartitionStudentsBySex = partitionStudentsBySex(filteredApproved, additionalFromLogs);
        }
        List<StudentItem> listComponent1 = pairPartitionStudentsBySex.component1();
        List<StudentItem> listComponent2 = pairPartitionStudentsBySex.component2();
        StringBuilder sb = new StringBuilder();
        String nowFormatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String selectedMonthsDisplay = config.getSelectedMonths().isEmpty() ? "All Months" : CollectionsKt.joinToString$default(CollectionsKt.sorted(config.getSelectedMonths()), ", ", null, null, 0, null, new Function1() { // from class: com.example.util.CsvExportUtils$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj3) {
                return CsvExportUtils.generateAttendanceCsv$lambda$11((String) obj3);
            }
        }, 30, null);
        sb.append("ATTENDANCE LOG & REGISTER EXPORT\n");
        if (classroom == null || (classroomName = classroom.getClassroomName()) == null) {
            classroomName = "Classroom";
        }
        sb.append("Classroom / Section: " + escapeCsv(classroomName) + "\n");
        if (classroom == null || (teacherName = classroom.getTeacherName()) == null) {
            teacherName = "Teacher";
        }
        sb.append("Teacher: " + escapeCsv(teacherName) + "\n");
        sb.append("Export Date: " + nowFormatted + "\n");
        sb.append("Month & Year: " + selectedMonthsDisplay + "\n");
        sb.append("Student Counts: Total=" + (listComponent1.size() + listComponent2.size()) + ", Male=" + listComponent1.size() + ", Female=" + listComponent2.size() + "\n\n");
        Iterable iterable = list2;
        Collection arrayList6 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
        Iterator it2 = iterable.iterator();
        while (it2.hasNext()) {
            arrayList6.add(INSTANCE.getNormalizedDate((AttendanceEntity) it2.next()));
            listComponent2 = listComponent2;
            nowFormatted = nowFormatted;
        }
        List<StudentItem> list8 = listComponent2;
        List<String> uniqueDates = CollectionsKt.sorted(CollectionsKt.distinct((List) arrayList6));
        Map statusLookup = new LinkedHashMap();
        for (AttendanceEntity log : list2) {
            String normDate = getNormalizedDate(log);
            String status = log.getStatus();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String status2 = status.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(status2, "toUpperCase(...)");
            statusLookup.put(new Pair(log.getStudentId(), normDate), status2);
        }
        List<AttendanceColumnKey> default_order = config.getColumnOrder().isEmpty() ? AttendanceColumnKey.INSTANCE.getDEFAULT_ORDER() : config.getColumnOrder();
        List headerCells = new ArrayList();
        for (AttendanceColumnKey key : default_order) {
            switch (WhenMappings.$EnumSwitchMapping$0[key.ordinal()]) {
                case 1:
                    headerCells.add("No.");
                    statusLookup = statusLookup;
                    break;
                case 2:
                    headerCells.add(config.getPresentLabel());
                    statusLookup = statusLookup;
                    break;
                case 3:
                    headerCells.add(config.getAbsentLabel());
                    statusLookup = statusLookup;
                    break;
                case 4:
                    headerCells.add(config.getLateLabel());
                    statusLookup = statusLookup;
                    break;
                case 5:
                    headerCells.add("Student Name");
                    statusLookup = statusLookup;
                    break;
                case 6:
                    headerCells.add("LRN");
                    statusLookup = statusLookup;
                    break;
                case 7:
                    for (String d : uniqueDates) {
                        Map statusLookup2 = statusLookup;
                        if (d.length() >= 10 && d.charAt(4) == '-' && d.charAt(7) == '-') {
                            dayOnly = d.substring(8);
                            Intrinsics.checkNotNullExpressionValue(dayOnly, "substring(...)");
                        } else {
                            dayOnly = (String) CollectionsKt.last(StringsKt.split$default((CharSequence) d, new String[]{"-"}, false, 0, 6, (Object) null));
                        }
                        headerCells.add(escapeCsv(dayOnly));
                        statusLookup = statusLookup2;
                    }
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
        }
        Map statusLookup3 = statusLookup;
        sb.append(CollectionsKt.joinToString$default(headerCells, ",", null, null, 0, null, null, 62, null)).append("\n");
        generateAttendanceCsv$appendStudentRows(config, sb, uniqueDates, statusLookup3, default_order, "Male", listComponent1, 1);
        generateAttendanceCsv$appendStudentRows(config, sb, uniqueDates, statusLookup3, default_order, "Female", list8, 1);
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    static final CharSequence generateAttendanceCsv$lambda$11(String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return INSTANCE.formatMonthDisplay(it);
    }

    private static final String generateAttendanceCsv$formatStatusCode(AttendanceExportConfig $config, String status) {
        if (status == null || StringsKt.equals(status, "UNMARKED", true)) {
            return "N/A";
        }
        if ($config.getUseShortCodes()) {
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String upperCase = status.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            switch (upperCase.hashCode()) {
                case 2329254:
                    return !upperCase.equals("LATE") ? status : "L";
                case 399705243:
                    return !upperCase.equals("PRESENT") ? status : "P";
                case 1924388665:
                    return !upperCase.equals("ABSENT") ? status : "A";
                default:
                    return status;
            }
        }
        Locale locale2 = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue(locale2, "getDefault(...)");
        String upperCase2 = status.toUpperCase(locale2);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        switch (upperCase2.hashCode()) {
            case 2329254:
                return !upperCase2.equals("LATE") ? status : AttendanceLabels.INSTANCE.getLate();
            case 399705243:
                return !upperCase2.equals("PRESENT") ? status : AttendanceLabels.INSTANCE.getPresent();
            case 1924388665:
                return !upperCase2.equals("ABSENT") ? status : AttendanceLabels.INSTANCE.getAbsent();
            default:
                return status;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private static final int generateAttendanceCsv$appendStudentRows(AttendanceExportConfig $config, StringBuilder sb, List<String> list, Map<Pair<String, String>, String> map, List<? extends AttendanceColumnKey> list2, String groupName, List<StudentItem> list3, int startNum) {
        String upperCase;
        if (list3.isEmpty()) {
            return startNum;
        }
        if ($config.getIncludeSectionHeaders()) {
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String upperCase2 = groupName.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
            sb.append(upperCase2 + "\n");
        }
        int currentNum = 1;
        Iterator<StudentItem> it = list3.iterator();
        while (it.hasNext()) {
            StudentItem st = it.next();
            int presentCount = 0;
            int absentCount = 0;
            int lateCount = 0;
            List dateStatuses = new ArrayList();
            for (String d : list) {
                String stStatus = map.get(new Pair(st.getStudentId(), d));
                currentNum = currentNum;
                it = it;
                dateStatuses.add(INSTANCE.escapeCsv(generateAttendanceCsv$formatStatusCode($config, stStatus)));
                if (stStatus != null) {
                    Locale locale2 = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue(locale2, "getDefault(...)");
                    upperCase = stStatus.toUpperCase(locale2);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                } else {
                    upperCase = null;
                }
                if (upperCase != null) {
                    switch (upperCase.hashCode()) {
                        case 2329254:
                            if (upperCase.equals("LATE")) {
                                lateCount++;
                            }
                            break;
                        case 399705243:
                            if (upperCase.equals("PRESENT")) {
                                presentCount++;
                            }
                            break;
                        case 1924388665:
                            if (upperCase.equals("ABSENT")) {
                                absentCount++;
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            int currentNum2 = currentNum;
            Iterator<StudentItem> it2 = it;
            List row = new ArrayList();
            for (AttendanceColumnKey key : list2) {
                switch (WhenMappings.$EnumSwitchMapping$0[key.ordinal()]) {
                    case 1:
                        row.add(String.valueOf(currentNum2));
                        break;
                    case 2:
                        row.add(String.valueOf(presentCount));
                        break;
                    case 3:
                        row.add(String.valueOf(absentCount));
                        break;
                    case 4:
                        row.add(String.valueOf(lateCount));
                        break;
                    case 5:
                        row.add(INSTANCE.escapeCsv(st.getStudentName()));
                        break;
                    case 6:
                        row.add(INSTANCE.formatLrnForCsv(st.getLrn()));
                        break;
                    case 7:
                        row.addAll(dateStatuses);
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
            }
            sb.append(CollectionsKt.joinToString$default(row, ",", null, null, 0, null, null, 62, null)).append("\n");
            currentNum = currentNum2 + 1;
            it = it2;
        }
        int currentNum3 = list3.size();
        return startNum + currentNum3;
    }

    /* JADX INFO: compiled from: CsvExportUtils.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u001b\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u00032\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0013"}, d2 = {"Lcom/example/util/CsvExportUtils$TasksExportConfig;", "", "treatMissingAsZero", "", "includeSectionHeaders", "<init>", "(ZZ)V", "getTreatMissingAsZero", "()Z", "getIncludeSectionHeaders", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class TasksExportConfig {
        public static final int $stable = 0;
        private final boolean includeSectionHeaders;
        private final boolean treatMissingAsZero;

        /* JADX WARN: Illegal instructions before constructor call */
        public TasksExportConfig() {
            boolean z = false;
            this(z, z, 3, null);
        }

        public static /* synthetic */ TasksExportConfig copy$default(TasksExportConfig tasksExportConfig, boolean z, boolean z2, int i, Object obj) {
            if ((i & 1) != 0) {
                z = tasksExportConfig.treatMissingAsZero;
            }
            if ((i & 2) != 0) {
                z2 = tasksExportConfig.includeSectionHeaders;
            }
            return tasksExportConfig.copy(z, z2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getTreatMissingAsZero() {
            return this.treatMissingAsZero;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final boolean getIncludeSectionHeaders() {
            return this.includeSectionHeaders;
        }

        public final TasksExportConfig copy(boolean treatMissingAsZero, boolean includeSectionHeaders) {
            return new TasksExportConfig(treatMissingAsZero, includeSectionHeaders);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TasksExportConfig)) {
                return false;
            }
            TasksExportConfig tasksExportConfig = (TasksExportConfig) other;
            return this.treatMissingAsZero == tasksExportConfig.treatMissingAsZero && this.includeSectionHeaders == tasksExportConfig.includeSectionHeaders;
        }

        public int hashCode() {
            return (Boolean.hashCode(this.treatMissingAsZero) * 31) + Boolean.hashCode(this.includeSectionHeaders);
        }

        public String toString() {
            return "TasksExportConfig(treatMissingAsZero=" + this.treatMissingAsZero + ", includeSectionHeaders=" + this.includeSectionHeaders + ")";
        }

        public TasksExportConfig(boolean treatMissingAsZero, boolean includeSectionHeaders) {
            this.treatMissingAsZero = treatMissingAsZero;
            this.includeSectionHeaders = includeSectionHeaders;
        }

        public /* synthetic */ TasksExportConfig(boolean z, boolean z2, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? true : z2);
        }

        public final boolean getTreatMissingAsZero() {
            return this.treatMissingAsZero;
        }

        public final boolean getIncludeSectionHeaders() {
            return this.includeSectionHeaders;
        }
    }

    public final String generateTasksCsv(ClassroomEntity classroom, List<ApprovedStudentEntity> approvedStudents, List<TaskEntity> selectedTasks, Map<String, ? extends List<TaskSubmissionEntity>> submissionsMap, TasksExportConfig config) {
        String classroomName;
        String teacherName;
        Intrinsics.checkNotNullParameter(approvedStudents, "approvedStudents");
        Intrinsics.checkNotNullParameter(selectedTasks, "selectedTasks");
        Intrinsics.checkNotNullParameter(submissionsMap, "submissionsMap");
        Intrinsics.checkNotNullParameter(config, "config");
        List additional = new ArrayList();
        Iterator<? extends List<TaskSubmissionEntity>> it = submissionsMap.values().iterator();
        while (it.hasNext()) {
            for (TaskSubmissionEntity sub : it.next()) {
                additional.add(TuplesKt.to(sub.getStudentId(), sub.getStudentName()));
            }
        }
        Pair<List<StudentItem>, List<StudentItem>> pairPartitionStudentsBySex = partitionStudentsBySex(approvedStudents, additional);
        List<StudentItem> listComponent1 = pairPartitionStudentsBySex.component1();
        List<StudentItem> listComponent2 = pairPartitionStudentsBySex.component2();
        StringBuilder sb = new StringBuilder();
        String nowFormatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        sb.append("CLASSROOM TASKS & GRADEBOOK EXPORT\n");
        if (classroom == null || (classroomName = classroom.getClassroomName()) == null) {
            classroomName = "Classroom";
        }
        sb.append("Classroom / Section: " + escapeCsv(classroomName) + "\n");
        if (classroom == null || (teacherName = classroom.getTeacherName()) == null) {
            teacherName = "Teacher";
        }
        sb.append("Teacher: " + escapeCsv(teacherName) + "\n");
        sb.append("Export Date: " + nowFormatted + "\n");
        sb.append("Included Tasks: " + selectedTasks.size() + "\n");
        sb.append("Student Counts: Total=" + (listComponent1.size() + listComponent2.size()) + ", Male=" + listComponent1.size() + ", Female=" + listComponent2.size() + "\n\n");
        List headerCells = CollectionsKt.mutableListOf("No.", "Student Name", "LRN");
        for (TaskEntity task : selectedTasks) {
            headerCells.add(escapeCsv(task.getTitle()));
        }
        sb.append(CollectionsKt.joinToString$default(headerCells, ",", null, null, 0, null, null, 62, null)).append("\n");
        generateTasksCsv$appendStudentRows$14(config, sb, selectedTasks, submissionsMap, "Male", listComponent1);
        generateTasksCsv$appendStudentRows$14(config, sb, selectedTasks, submissionsMap, "Female", listComponent2);
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    private static final int generateTasksCsv$appendStudentRows$14(TasksExportConfig $config, StringBuilder sb, List<TaskEntity> list, Map<String, ? extends List<TaskSubmissionEntity>> map, String groupName, List<StudentItem> list2) {
        TaskSubmissionEntity sub;
        Object obj;
        if (list2.isEmpty()) {
            return 0;
        }
        if ($config.getIncludeSectionHeaders()) {
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue(locale, "getDefault(...)");
            String upperCase = groupName.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            sb.append(upperCase + "\n");
        }
        int num = 1;
        for (StudentItem st : list2) {
            List row = new ArrayList();
            row.add(String.valueOf(num));
            row.add(INSTANCE.escapeCsv(st.getStudentName()));
            row.add(INSTANCE.formatLrnForCsv(st.getLrn()));
            int i = 0;
            int size = list.size();
            while (i < size) {
                TaskEntity task = list.get(i);
                List<TaskSubmissionEntity> list3 = map.get(task.getTkid());
                if (list3 != null) {
                    Iterator<T> it = list3.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            obj = null;
                            break;
                        }
                        Object next = it.next();
                        if (Intrinsics.areEqual(((TaskSubmissionEntity) next).getStudentId(), st.getStudentId())) {
                            obj = next;
                            break;
                        }
                    }
                    sub = (TaskSubmissionEntity) obj;
                } else {
                    sub = null;
                }
                if (task.getMaxScore() > 0) {
                    if (sub != null) {
                        row.add(sub.getScore() + "/" + task.getMaxScore());
                    } else {
                        row.add("");
                    }
                } else if (sub != null) {
                    row.add("Submitted");
                } else {
                    row.add("");
                }
                i++;
                list = list;
            }
            sb.append(CollectionsKt.joinToString$default(row, ",", null, null, 0, null, null, 62, null)).append("\n");
            num++;
        }
        return list2.size();
    }
}
