package com.example.util;

import android.R;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import com.example.MainActivity;
import com.example.data.db.AttendanceDao;
import com.example.data.db.AttendanceEntity;
import com.example.data.db.CalisDatabase;
import com.example.data.db.ClassroomDao;
import com.example.data.db.ClassroomEntity;
import com.example.data.db.StudentProfileEntity;
import com.example.data.db.TaskEntity;
import io.ktor.sse.ServerSentEventKt;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;

/* JADX INFO: compiled from: ReminderNotificationHelper.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\n\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016J\u0010\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0019\u001a\u00020\b2\b\b\u0002\u0010\u001a\u001a\u00020\u0005J\u0010\u0010\u001b\u001a\u00020\b2\b\b\u0002\u0010\u001a\u001a\u00020\u0005J\u0010\u0010\u001c\u001a\u00020\b2\b\b\u0002\u0010\u001d\u001a\u00020\u0005J\u0010\u0010\u001e\u001a\u00020\b2\b\b\u0002\u0010\u001d\u001a\u00020\u0005J\u0010\u0010\u001f\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u000e\u0010 \u001a\u00020\b2\u0006\u0010!\u001a\u00020\u0005J'\u0010\"\u001a\u0004\u0018\u00010#2\u0006\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\b2\b\b\u0002\u0010'\u001a\u00020#¢\u0006\u0002\u0010(J&\u0010)\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010$\u001a\u00020%2\u0006\u0010*\u001a\u00020#2\u0006\u0010&\u001a\u00020\bJ\u0016\u0010+\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010$\u001a\u00020%J(\u0010,\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010*\u001a\u00020#2\u0006\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020\bH\u0002J \u0010/\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020\bH\u0002J\u000e\u00100\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u0016\u00101\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016H\u0086@¢\u0006\u0002\u00102J\u000e\u00103\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u00104\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u00105\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J \u00106\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\b\u00107\u001a\u0004\u0018\u000108H\u0086@¢\u0006\u0002\u00109J\u001e\u0010:\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\bJ\u000e\u0010;\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010<\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u0016\u0010=\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\u0005J\u000e\u0010>\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010?\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0016J\u0016\u0010@\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010A\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006B"}, d2 = {"Lcom/example/util/ReminderNotificationHelper;", "", "<init>", "()V", "TAG", "", "CHANNEL_ID", "NOTIF_ID_SESSION_REMINDER", "", "NOTIF_ID_TASK_DEADLINE", "REQ_CODE_TC_ALARM", "REQ_CODE_ST_ALARM", "EXTRA_CLASSROOM_ID", "EXTRA_CLASSROOM_NAME", "EXTRA_CLASSROOM_START_TIME", "EXTRA_REMINDER_MINUTES", "EXTRA_SCHEDULED_TRIGGER_MS", "periodicJob", "Lkotlinx/coroutines/Job;", "hasExactAlarmPermission", "", "context", "Landroid/content/Context;", "informUserExactAlarmUnavailable", "", "getSessionAlarmRequestCode", "cid", "getSessionNotificationId", "getTaskAlarmRequestCode", "tkid", "getTaskNotificationId", "createNotificationChannel", "parseTimeToMinutes", "raw", "calculateNextSessionReminderTime", "", "classroom", "Lcom/example/data/db/ClassroomEntity;", "reminderMinutes", "currentTimeMillis", "(Lcom/example/data/db/ClassroomEntity;IJ)Ljava/lang/Long;", "scheduleSessionAlarm", "triggerAtMillis", "cancelSessionAlarm", "scheduleExactAlarm", "action", "requestCode", "cancelAlarm", "startPeriodicChecker", "rescheduleSessionRemindersSync", "(Landroid/content/Context;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "checkAndPostSessionReminder", "clearSessionReminderKeys", "clearTaskReminderKeys", "handleSessionReminderAlarmTrigger", "intent", "Landroid/content/Intent;", "(Landroid/content/Context;Landroid/content/Intent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "postSessionReminderNotification", "cancelSessionReminder", "checkAndPostTaskDeadlineReminder", "cancelTaskNotification", "cancelTaskDeadlineReminder", "checkAndPostCheckInReminder", "cancelCheckInAndLateNotifications", "classroomId", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ReminderNotificationHelper {
    private static final String CHANNEL_ID = "calis_reminders_channel";
    public static final String EXTRA_CLASSROOM_ID = "classroom_id";
    public static final String EXTRA_CLASSROOM_NAME = "classroom_name";
    public static final String EXTRA_CLASSROOM_START_TIME = "classroom_start_time";
    public static final String EXTRA_REMINDER_MINUTES = "reminder_minutes";
    public static final String EXTRA_SCHEDULED_TRIGGER_MS = "scheduled_trigger_ms";
    private static final int NOTIF_ID_SESSION_REMINDER = 5001;
    private static final int NOTIF_ID_TASK_DEADLINE = 5002;
    private static final int REQ_CODE_ST_ALARM = 8002;
    private static final int REQ_CODE_TC_ALARM = 8001;
    private static final String TAG = "ReminderNotification";
    private static Job periodicJob;
    public static final ReminderNotificationHelper INSTANCE = new ReminderNotificationHelper();
    public static final int $stable = 8;

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$handleSessionReminderAlarmTrigger$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper", f = "ReminderNotificationHelper.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, l = {522, 524, 525}, m = "handleSessionReminderAlarmTrigger", n = {"context", "intent", "prefs", "targetCid", "classroomNameExtra", "classroomStartTimeExtra", "db", "isEnabled", "reminderMinutesExtra", "reminderMinutes", "context", "intent", "prefs", "targetCid", "classroomNameExtra", "classroomStartTimeExtra", "db", "isEnabled", "reminderMinutesExtra", "reminderMinutes", "context", "intent", "prefs", "targetCid", "classroomNameExtra", "classroomStartTimeExtra", "db", "isEnabled", "reminderMinutesExtra", "reminderMinutes"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "Z$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "Z$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "Z$0", "I$0", "I$1"})
    static final class C08171 extends ContinuationImpl {
        int I$0;
        int I$1;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        C08171(Continuation<? super C08171> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return ReminderNotificationHelper.this.handleSessionReminderAlarmTrigger(null, null, this);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$rescheduleSessionRemindersSync$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper", f = "ReminderNotificationHelper.kt", i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2}, l = {374, 382, 383}, m = "rescheduleSessionRemindersSync", n = {"context", "prefs", "db", "isEnabled", "reminderMinutes", "context", "prefs", "db", "allClassrooms", "isEnabled", "reminderMinutes", "context", "prefs", "db", "allClassrooms", "isEnabled", "reminderMinutes"}, s = {"L$0", "L$1", "L$2", "Z$0", "I$0", "L$0", "L$1", "L$2", "L$3", "Z$0", "I$0", "L$0", "L$1", "L$2", "L$3", "Z$0", "I$0"})
    static final class C08181 extends ContinuationImpl {
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        C08181(Continuation<? super C08181> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return ReminderNotificationHelper.this.rescheduleSessionRemindersSync(null, this);
        }
    }

    private ReminderNotificationHelper() {
    }

    public final boolean hasExactAlarmPermission(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (Build.VERSION.SDK_INT >= 31) {
            Object systemService = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            AlarmManager alarmManager = systemService instanceof AlarmManager ? (AlarmManager) systemService : null;
            if (alarmManager != null) {
                return alarmManager.canScheduleExactAlarms();
            }
            return false;
        }
        return true;
    }

    private final void informUserExactAlarmUnavailable(final Context context) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.example.util.ReminderNotificationHelper$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    Toast.makeText(context, "Exact alarm permission is unavailable. Reminders will use standard scheduling.", 0).show();
                }
            });
        } catch (Exception e) {
            Log.w(TAG, "Could not show exact alarm permission toast", e);
        }
    }

    public static /* synthetic */ int getSessionAlarmRequestCode$default(ReminderNotificationHelper reminderNotificationHelper, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        return reminderNotificationHelper.getSessionAlarmRequestCode(str);
    }

    public final int getSessionAlarmRequestCode(String cid) {
        int hash;
        Intrinsics.checkNotNullParameter(cid, "cid");
        return (StringsKt.isBlank(cid) || (hash = Math.abs(cid.hashCode()) % 10000) == 0) ? REQ_CODE_TC_ALARM : hash + REQ_CODE_TC_ALARM;
    }

    public static /* synthetic */ int getSessionNotificationId$default(ReminderNotificationHelper reminderNotificationHelper, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        return reminderNotificationHelper.getSessionNotificationId(str);
    }

    public final int getSessionNotificationId(String cid) {
        int hash;
        Intrinsics.checkNotNullParameter(cid, "cid");
        return (StringsKt.isBlank(cid) || (hash = Math.abs(cid.hashCode()) % 10000) == 0) ? NOTIF_ID_SESSION_REMINDER : hash + NOTIF_ID_SESSION_REMINDER;
    }

    public static /* synthetic */ int getTaskAlarmRequestCode$default(ReminderNotificationHelper reminderNotificationHelper, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        return reminderNotificationHelper.getTaskAlarmRequestCode(str);
    }

    public final int getTaskAlarmRequestCode(String tkid) {
        int hash;
        Intrinsics.checkNotNullParameter(tkid, "tkid");
        return (StringsKt.isBlank(tkid) || (hash = Math.abs(tkid.hashCode()) % 10000) == 0) ? REQ_CODE_ST_ALARM : hash + REQ_CODE_ST_ALARM;
    }

    public static /* synthetic */ int getTaskNotificationId$default(ReminderNotificationHelper reminderNotificationHelper, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        return reminderNotificationHelper.getTaskNotificationId(str);
    }

    public final int getTaskNotificationId(String tkid) {
        int hash;
        Intrinsics.checkNotNullParameter(tkid, "tkid");
        return (StringsKt.isBlank(tkid) || (hash = Math.abs(tkid.hashCode()) % 10000) == 0) ? NOTIF_ID_TASK_DEADLINE : hash + NOTIF_ID_TASK_DEADLINE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            Object systemService = context.getSystemService("notification");
            NotificationManager manager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
            if (manager == null) {
                return;
            }
            NotificationChannel existing = manager.getNotificationChannel(CHANNEL_ID);
            if (existing == null) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Calis Reminders", 4);
                channel.setDescription("Reminders to start session and upcoming task deadlines");
                channel.enableVibration(true);
                channel.setVibrationPattern(new long[]{0, 500, 250, 500});
                channel.setShowBadge(true);
                manager.createNotificationChannel(channel);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:41:0x011d  */
    /* JADX WARN: Code duplicated, block: B:43:0x0124  */
    /* JADX WARN: Code duplicated, block: B:46:0x012f  */
    /* JADX WARN: Code duplicated, block: B:49:0x013e A[LOOP:1: B:44:0x0129->B:49:0x013e, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:52:0x0144  */
    /* JADX WARN: Code duplicated, block: B:54:0x0152  */
    /* JADX WARN: Code duplicated, block: B:55:0x0157  */
    /* JADX WARN: Code duplicated, block: B:58:0x0166  */
    /* JADX WARN: Code duplicated, block: B:60:0x016d  */
    /* JADX WARN: Code duplicated, block: B:62:0x0173  */
    /* JADX WARN: Code duplicated, block: B:77:0x0141 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:78:0x013c A[SYNTHETIC] */
    public final int parseTimeToMinutes(String raw) {
        int hour;
        String str;
        int i;
        boolean z;
        Integer intOrNull;
        int hour2;
        char c;
        Intrinsics.checkNotNullParameter(raw, "raw");
        String trimmed = StringsKt.trim((CharSequence) raw).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(trimmed, "toUpperCase(...)");
        if ((trimmed.length() == 0) || Intrinsics.areEqual(trimmed, "N/A") || Intrinsics.areEqual(trimmed, "--:--")) {
            return -1;
        }
        boolean isPM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "PM", false, 2, (Object) null);
        boolean isAM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "AM", false, 2, (Object) null);
        String clean = StringsKt.trim((CharSequence) StringsKt.replace$default(StringsKt.replace$default(trimmed, "AM", "", false, 4, (Object) null), "PM", "", false, 4, (Object) null)).toString();
        List parts = StringsKt.split$default((CharSequence) clean, new String[]{ServerSentEventKt.COLON}, false, 0, 6, (Object) null);
        int min = 0;
        if (parts.size() >= 2) {
            Integer intOrNull2 = StringsKt.toIntOrNull(StringsKt.trim((CharSequence) parts.get(0)).toString());
            hour = intOrNull2 != null ? intOrNull2.intValue() : 0;
            Integer intOrNull3 = StringsKt.toIntOrNull(StringsKt.trim((CharSequence) parts.get(1)).toString());
            min = intOrNull3 != null ? intOrNull3.intValue() : 0;
        } else {
            int hour3 = clean.length();
            if (hour3 != 4) {
                if (clean.length() == 3) {
                    Integer intOrNull4 = StringsKt.toIntOrNull(clean);
                    hour = intOrNull4 != null ? intOrNull4.intValue() : 0;
                } else {
                    str = clean;
                    i = 0;
                    while (true) {
                        if (i < str.length()) {
                            if (!Character.isDigit(str.charAt(i))) {
                                z = false;
                                break;
                            }
                            i++;
                        } else {
                            z = true;
                            break;
                        }
                    }
                    if (z) {
                        String strSubstring = clean.substring(0, 1);
                        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                        intOrNull = StringsKt.toIntOrNull(strSubstring);
                        if (intOrNull != null) {
                            hour2 = intOrNull.intValue();
                        } else {
                            hour2 = 0;
                        }
                        String strSubstring2 = clean.substring(1, 3);
                        Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                        Integer intOrNull5 = StringsKt.toIntOrNull(strSubstring2);
                        min = intOrNull5 != null ? intOrNull5.intValue() : 0;
                        hour = hour2;
                    } else {
                        Integer intOrNull6 = StringsKt.toIntOrNull(clean);
                        hour = intOrNull6 != null ? intOrNull6.intValue() : 0;
                    }
                }
            } else {
                String str2 = clean;
                int i2 = 0;
                while (true) {
                    if (i2 < str2.length()) {
                        if (!Character.isDigit(str2.charAt(i2))) {
                            c = 0;
                            break;
                        }
                        i2++;
                    } else {
                        c = 1;
                        break;
                    }
                }
                if (c != 0) {
                    String strSubstring3 = clean.substring(0, 2);
                    Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                    Integer intOrNull7 = StringsKt.toIntOrNull(strSubstring3);
                    hour = intOrNull7 != null ? intOrNull7.intValue() : 0;
                    String strSubstring4 = clean.substring(2, 4);
                    Intrinsics.checkNotNullExpressionValue(strSubstring4, "substring(...)");
                    Integer intOrNull8 = StringsKt.toIntOrNull(strSubstring4);
                    min = intOrNull8 != null ? intOrNull8.intValue() : 0;
                } else if (clean.length() == 3) {
                    Integer intOrNull9 = StringsKt.toIntOrNull(clean);
                    hour = intOrNull9 != null ? intOrNull9.intValue() : 0;
                } else {
                    str = clean;
                    i = 0;
                    while (true) {
                        if (i < str.length()) {
                            if (!Character.isDigit(str.charAt(i))) {
                                z = false;
                                break;
                            }
                            i++;
                        } else {
                            z = true;
                            break;
                        }
                    }
                    if (z) {
                        String strSubstring5 = clean.substring(0, 1);
                        Intrinsics.checkNotNullExpressionValue(strSubstring5, "substring(...)");
                        intOrNull = StringsKt.toIntOrNull(strSubstring5);
                        if (intOrNull != null) {
                            hour2 = intOrNull.intValue();
                        } else {
                            hour2 = 0;
                        }
                        String strSubstring6 = clean.substring(1, 3);
                        Intrinsics.checkNotNullExpressionValue(strSubstring6, "substring(...)");
                        Integer intOrNull10 = StringsKt.toIntOrNull(strSubstring6);
                        min = intOrNull10 != null ? intOrNull10.intValue() : 0;
                        hour = hour2;
                    } else {
                        Integer intOrNull11 = StringsKt.toIntOrNull(clean);
                        hour = intOrNull11 != null ? intOrNull11.intValue() : 0;
                    }
                }
            }
        }
        if (isPM && hour < 12) {
            hour += 12;
        }
        if (isAM && hour == 12) {
            hour = 0;
        }
        return (hour * 60) + min;
    }

    public static /* synthetic */ Long calculateNextSessionReminderTime$default(ReminderNotificationHelper reminderNotificationHelper, ClassroomEntity classroomEntity, int i, long j, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            j = System.currentTimeMillis();
        }
        return reminderNotificationHelper.calculateNextSessionReminderTime(classroomEntity, i, j);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0050  */
    /* JADX WARN: Code duplicated, block: B:22:0x0074 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:24:0x0079 A[SYNTHETIC] */
    public final Long calculateNextSessionReminderTime(ClassroomEntity classroom, int reminderMinutes, long currentTimeMillis) {
        int startMins;
        long reminderTimeMillis;
        Intrinsics.checkNotNullParameter(classroom, "classroom");
        if (reminderMinutes <= 0 || (startMins = parseTimeToMinutes(classroom.getStartTime())) < 0) {
            return null;
        }
        int startHour = startMins / 60;
        int startMinute = startMins % 60;
        for (int dayOffset = 0; dayOffset < 15; dayOffset++) {
            Calendar classCal = Calendar.getInstance();
            classCal.setTimeInMillis(currentTimeMillis);
            classCal.add(6, dayOffset);
            if (StringsKt.isBlank(classroom.getDays())) {
                classCal.set(11, startHour);
                classCal.set(12, startMinute);
                classCal.set(13, 0);
                classCal.set(14, 0);
                long classStartTimeMillis = classCal.getTimeInMillis();
                reminderTimeMillis = classStartTimeMillis - (((long) reminderMinutes) * 60000);
                if (reminderTimeMillis > currentTimeMillis) {
                    return Long.valueOf(reminderTimeMillis);
                }
            } else {
                ScheduleUtils scheduleUtils = ScheduleUtils.INSTANCE;
                Intrinsics.checkNotNull(classCal);
                if (scheduleUtils.isDayInSchedule(classCal, classroom.getDays())) {
                    classCal.set(11, startHour);
                    classCal.set(12, startMinute);
                    classCal.set(13, 0);
                    classCal.set(14, 0);
                    long classStartTimeMillis2 = classCal.getTimeInMillis();
                    reminderTimeMillis = classStartTimeMillis2 - (((long) reminderMinutes) * 60000);
                    if (reminderTimeMillis > currentTimeMillis) {
                        return Long.valueOf(reminderTimeMillis);
                    }
                } else {
                    continue;
                }
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:40:0x014a A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:41:0x014b  */
    public final void scheduleSessionAlarm(Context context, ClassroomEntity classroom, long triggerAtMillis, int reminderMinutes) {
        String str;
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(classroom, "classroom");
        if (triggerAtMillis <= 0) {
            return;
        }
        AlarmManager alarmManager = null;
        try {
            try {
                Object systemService = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
                AlarmManager alarmManager2 = systemService instanceof AlarmManager ? (AlarmManager) systemService : null;
                if (alarmManager2 == null) {
                    return;
                }
                str = NotificationCompat.CATEGORY_ALARM;
                try {
                    Intent intent = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
                    intent.setAction(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER);
                    try {
                        intent.setData(Uri.parse("calis://session_reminder/" + classroom.getCid()));
                        intent.putExtra(EXTRA_CLASSROOM_ID, classroom.getCid());
                        intent.putExtra(EXTRA_CLASSROOM_NAME, classroom.getClassroomName());
                        intent.putExtra(EXTRA_CLASSROOM_START_TIME, classroom.getStartTime());
                        intent.putExtra(EXTRA_REMINDER_MINUTES, reminderMinutes);
                        intent.putExtra(EXTRA_SCHEDULED_TRIGGER_MS, triggerAtMillis);
                        int reqCode = getSessionAlarmRequestCode(classroom.getCid());
                        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, reqCode, intent, 201326592);
                        boolean canExact = hasExactAlarmPermission(context);
                        if (Build.VERSION.SDK_INT < 31 || canExact) {
                            alarmManager2.setExactAndAllowWhileIdle(0, triggerAtMillis, pendingIntent);
                        } else {
                            alarmManager2.setAndAllowWhileIdle(0, triggerAtMillis, pendingIntent);
                            informUserExactAlarmUnavailable(context);
                        }
                        Log.d(TAG, "Scheduled session reminder alarm for " + classroom.getClassroomName() + " (" + classroom.getCid() + ") at " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(triggerAtMillis)));
                        return;
                    } catch (SecurityException e) {
                        e = e;
                    }
                } catch (SecurityException e2) {
                    e = e2;
                }
            } catch (SecurityException e3) {
                e = e3;
                str = NotificationCompat.CATEGORY_ALARM;
            }
        } catch (Exception e4) {
            Log.e(TAG, "Failed to schedule session reminder alarm", e4);
            return;
        }
        Log.w(TAG, "Exact alarm permission missing when scheduling, falling back to inexact alarm", e);
        try {
            Object systemService2 = context.getSystemService(str);
            if (systemService2 instanceof AlarmManager) {
                try {
                    alarmManager = (AlarmManager) systemService2;
                    if (alarmManager == null) {
                        return;
                    }
                    AlarmManager alarmManager3 = alarmManager;
                    Intent intent2 = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
                    try {
                        intent2.setAction(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER);
                        intent2.setData(Uri.parse("calis://session_reminder/" + classroom.getCid()));
                        intent2.putExtra(EXTRA_CLASSROOM_ID, classroom.getCid());
                        intent2.putExtra(EXTRA_CLASSROOM_NAME, classroom.getClassroomName());
                        intent2.putExtra(EXTRA_CLASSROOM_START_TIME, classroom.getStartTime());
                        intent2.putExtra(EXTRA_REMINDER_MINUTES, reminderMinutes);
                        intent2.putExtra(EXTRA_SCHEDULED_TRIGGER_MS, triggerAtMillis);
                        try {
                            int reqCode2 = getSessionAlarmRequestCode(classroom.getCid());
                            alarmManager3.setAndAllowWhileIdle(0, triggerAtMillis, PendingIntent.getBroadcast(context, reqCode2, intent2, 201326592));
                            informUserExactAlarmUnavailable(context);
                            Unit unit = Unit.INSTANCE;
                            return;
                        } catch (Exception e5) {
                            ex = e5;
                        }
                    } catch (Exception e6) {
                        ex = e6;
                    }
                } catch (Exception e7) {
                    ex = e7;
                }
            } else {
                if (alarmManager == null) {
                    return;
                }
                AlarmManager alarmManager4 = alarmManager;
                Intent intent3 = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
                intent3.setAction(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER);
                intent3.setData(Uri.parse("calis://session_reminder/" + classroom.getCid()));
                intent3.putExtra(EXTRA_CLASSROOM_ID, classroom.getCid());
                intent3.putExtra(EXTRA_CLASSROOM_NAME, classroom.getClassroomName());
                intent3.putExtra(EXTRA_CLASSROOM_START_TIME, classroom.getStartTime());
                intent3.putExtra(EXTRA_REMINDER_MINUTES, reminderMinutes);
                intent3.putExtra(EXTRA_SCHEDULED_TRIGGER_MS, triggerAtMillis);
                int reqCode3 = getSessionAlarmRequestCode(classroom.getCid());
                alarmManager4.setAndAllowWhileIdle(0, triggerAtMillis, PendingIntent.getBroadcast(context, reqCode3, intent3, 201326592));
                informUserExactAlarmUnavailable(context);
                Unit unit2 = Unit.INSTANCE;
                return;
            }
        } catch (Exception e8) {
            ex = e8;
        }
        Integer.valueOf(Log.e(TAG, "Failed fallback alarm scheduling", ex));
    }

    public final void cancelSessionAlarm(Context context, ClassroomEntity classroom) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(classroom, "classroom");
        try {
            Object systemService = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            AlarmManager alarmManager = systemService instanceof AlarmManager ? (AlarmManager) systemService : null;
            if (alarmManager == null) {
                return;
            }
            Intent intent = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
            intent.setAction(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER);
            intent.setData(Uri.parse("calis://session_reminder/" + classroom.getCid()));
            int reqCode = getSessionAlarmRequestCode(classroom.getCid());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, reqCode, intent, 603979776);
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel session alarm for " + classroom.getCid(), e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void scheduleExactAlarm(Context context, long triggerAtMillis, String action, int requestCode) {
        if (triggerAtMillis <= System.currentTimeMillis()) {
            return;
        }
        try {
            Object systemService = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            AlarmManager alarmManager = systemService instanceof AlarmManager ? (AlarmManager) systemService : null;
            if (alarmManager == null) {
                return;
            }
            Intent intent = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
            intent.setAction(action);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 201326592);
            if (Build.VERSION.SDK_INT < 31 || hasExactAlarmPermission(context)) {
                alarmManager.setExactAndAllowWhileIdle(0, triggerAtMillis, pendingIntent);
            } else {
                alarmManager.setAndAllowWhileIdle(0, triggerAtMillis, pendingIntent);
                informUserExactAlarmUnavailable(context);
            }
            Log.d(TAG, "Scheduled alarm for " + action + " at " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(triggerAtMillis)));
        } catch (SecurityException e) {
            Log.w(TAG, "SecurityException in scheduleExactAlarm", e);
            try {
                Object systemService2 = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
                AlarmManager alarmManager2 = systemService2 instanceof AlarmManager ? (AlarmManager) systemService2 : null;
                if (alarmManager2 == null) {
                    return;
                }
                Intent intent2 = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
                intent2.setAction(action);
                alarmManager2.setAndAllowWhileIdle(0, triggerAtMillis, PendingIntent.getBroadcast(context, requestCode, intent2, 201326592));
                informUserExactAlarmUnavailable(context);
                Unit unit = Unit.INSTANCE;
            } catch (Exception ex) {
                Integer.valueOf(Log.e(TAG, "Failed fallback in scheduleExactAlarm", ex));
            }
        } catch (Exception e2) {
            Log.e(TAG, "Failed to schedule alarm for " + action, e2);
        }
    }

    private final void cancelAlarm(Context context, String action, int requestCode) {
        try {
            Object systemService = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            AlarmManager alarmManager = systemService instanceof AlarmManager ? (AlarmManager) systemService : null;
            if (alarmManager == null) {
                return;
            }
            Intent intent = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
            intent.setAction(action);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 603979776);
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel alarm for " + action, e);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$startPeriodicChecker$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$startPeriodicChecker$1", f = "ReminderNotificationHelper.kt", i = {0}, l = {356}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    static final class C08191 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08191(Context context, Continuation<? super C08191> continuation) {
            super(2, continuation);
            this.$context = context;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            C08191 c08191 = new C08191(this.$context, continuation);
            c08191.L$0 = obj;
            return c08191;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08191) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            CoroutineScope $this$launch = (CoroutineScope) this.L$0;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            while (CoroutineScopeKt.isActive($this$launch)) {
                try {
                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(this.$context);
                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.$context);
                    ReminderNotificationHelper.INSTANCE.checkAndPostCheckInReminder(this.$context);
                } catch (Exception e) {
                    Log.e(ReminderNotificationHelper.TAG, "Error in periodic reminder check", e);
                }
                this.L$0 = $this$launch;
                this.label = 1;
                if (DelayKt.delay(30000L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }
    }

    public final void startPeriodicChecker(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        Job job = periodicJob;
        boolean z = false;
        if (job != null && job.isActive()) {
            z = true;
        }
        if (z) {
            return;
        }
        periodicJob = BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C08191(context, null), 3, null);
    }

    /* JADX WARN: Code duplicated, block: B:37:0x00de  */
    /* JADX WARN: Code duplicated, block: B:38:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:40:0x0106 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:41:0x0107  */
    /* JADX WARN: Code duplicated, block: B:44:0x0111  */
    /* JADX WARN: Code duplicated, block: B:46:0x0136 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:47:0x0137  */
    /* JADX WARN: Code duplicated, block: B:49:0x0144  */
    /* JADX WARN: Code duplicated, block: B:53:0x015b  */
    /* JADX WARN: Code duplicated, block: B:55:0x015e  */
    /* JADX WARN: Code duplicated, block: B:58:0x0193  */
    /* JADX WARN: Code duplicated, block: B:62:0x01f7  */
    /* JADX WARN: Code duplicated, block: B:63:0x0215  */
    /* JADX WARN: Code duplicated, block: B:65:0x022d  */
    /* JADX WARN: Code duplicated, block: B:71:0x0246  */
    /* JADX WARN: Code duplicated, block: B:7:0x001a  */
    /* JADX WARN: Code duplicated, block: B:85:0x0278 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:86:0x026a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x0286 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:89:0x0255 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:90:0x024f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:91:0x01a8 A[SYNTHETIC] */
    public final Object rescheduleSessionRemindersSync(Context context, Continuation<? super Unit> continuation) {
        C08181 c08181;
        SharedPreferences prefs;
        boolean isEnabled;
        int reminderMinutes;
        CalisDatabase db;
        Object allClassroomsSync;
        List allClassrooms;
        Object activeBoundClassroomSync;
        List allClassrooms2;
        int reminderMinutes2;
        boolean isEnabled2;
        int reminderMinutes3;
        ClassroomEntity classroomEntity;
        int reminderMinutes4;
        List allClassrooms3;
        boolean isEnabled3;
        Object anyClassroomSync;
        boolean isEnabled4;
        List allClassrooms4;
        CalisDatabase db2;
        SharedPreferences prefs2;
        long now;
        Calendar calendar;
        String todayDateStr;
        Iterator it;
        ClassroomEntity classroom;
        int startMins;
        Context context2;
        long todayClassStartMs;
        long now2;
        long todayReminderMs;
        boolean handledToday;
        C08181 c08182;
        Object $result;
        long now3;
        ClassroomEntity classroom2;
        ReminderNotificationHelper reminderNotificationHelper;
        Iterator it2;
        Long nextOccurrenceTrigger;
        Long nextTrigger;
        this = this;
        Context context3 = context;
        if (continuation instanceof C08181) {
            c08181 = (C08181) continuation;
            if ((c08181.label & Integer.MIN_VALUE) != 0) {
                c08181.label -= Integer.MIN_VALUE;
            } else {
                c08181 = this.new C08181(continuation);
            }
        } else {
            c08181 = this.new C08181(continuation);
        }
        C08181 c08183 = c08181;
        Object $result2 = c08183.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (c08183.label) {
            case 0:
                ResultKt.throwOnFailure($result2);
                prefs = context3.getSharedPreferences("calis_auth_prefs", 0);
                isEnabled = prefs.getBoolean("remind_start_session", false);
                if (!isEnabled) {
                    cancelSessionReminder(context);
                    return Unit.INSTANCE;
                }
                reminderMinutes = prefs.getInt("remind_start_session_minutes", 15);
                if (reminderMinutes <= 0) {
                    return Unit.INSTANCE;
                }
                db = CalisDatabase.INSTANCE.getDatabase(context3);
                try {
                    ClassroomDao classroomDao = db.classroomDao();
                    c08183.L$0 = context3;
                    c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                    c08183.L$2 = db;
                    c08183.Z$0 = isEnabled;
                    c08183.I$0 = reminderMinutes;
                    c08183.label = 1;
                    allClassroomsSync = classroomDao.getAllClassroomsSync(c08183);
                    if (allClassroomsSync == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    allClassrooms = (List) allClassroomsSync;
                    break;
                } catch (Exception e) {
                    allClassrooms = CollectionsKt.emptyList();
                }
                if (allClassrooms.isEmpty()) {
                    ClassroomDao classroomDao2 = db.classroomDao();
                    c08183.L$0 = context3;
                    c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                    c08183.L$2 = db;
                    c08183.L$3 = SpillingKt.nullOutSpilledVariable(allClassrooms);
                    c08183.Z$0 = isEnabled;
                    c08183.I$0 = reminderMinutes;
                    c08183.label = 2;
                    activeBoundClassroomSync = classroomDao2.getActiveBoundClassroomSync(c08183);
                    if (activeBoundClassroomSync == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    boolean z = isEnabled;
                    allClassrooms2 = allClassrooms;
                    reminderMinutes2 = reminderMinutes;
                    isEnabled2 = z;
                    classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                    if (classroomEntity == null) {
                        ClassroomDao classroomDao3 = db.classroomDao();
                        c08183.L$0 = context3;
                        c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                        c08183.L$2 = SpillingKt.nullOutSpilledVariable(db);
                        c08183.L$3 = SpillingKt.nullOutSpilledVariable(allClassrooms2);
                        c08183.Z$0 = isEnabled2;
                        c08183.I$0 = reminderMinutes2;
                        c08183.label = 3;
                        anyClassroomSync = classroomDao3.getAnyClassroomSync(c08183);
                        if (anyClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        isEnabled4 = isEnabled2;
                        allClassrooms4 = allClassrooms2;
                        db2 = db;
                        prefs2 = prefs;
                        classroomEntity = (ClassroomEntity) anyClassroomSync;
                        List list = allClassrooms4;
                        reminderMinutes4 = reminderMinutes2;
                        allClassrooms3 = list;
                        prefs = prefs2;
                        db = db2;
                        isEnabled3 = isEnabled4;
                    } else {
                        boolean z2 = isEnabled2;
                        reminderMinutes4 = reminderMinutes2;
                        allClassrooms3 = allClassrooms2;
                        isEnabled3 = z2;
                    }
                    allClassrooms = CollectionsKt.listOfNotNull(classroomEntity);
                    reminderMinutes3 = reminderMinutes4;
                } else {
                    reminderMinutes3 = reminderMinutes;
                }
                if (allClassrooms.isEmpty()) {
                    return Unit.INSTANCE;
                }
                this.cancelAlarm(context3, ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER, REQ_CODE_TC_ALARM);
                now = System.currentTimeMillis();
                calendar = Calendar.getInstance();
                calendar.setTimeInMillis(now);
                List classrooms = allClassrooms;
                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                it = classrooms.iterator();
                while (it.hasNext()) {
                    classroom = (ClassroomEntity) it.next();
                    this.cancelSessionAlarm(context3, classroom);
                    todayDateStr = todayDateStr;
                    String todayDateStr2 = classroom.getStartTime();
                    startMins = this.parseTimeToMinutes(todayDateStr2);
                    if (startMins >= 0) {
                        ScheduleUtils scheduleUtils = ScheduleUtils.INSTANCE;
                        Intrinsics.checkNotNull(calendar);
                        scheduleUtils.isDayInSchedule(calendar, classroom.getDays());
                        Calendar calendar2 = Calendar.getInstance();
                        calendar2.setTimeInMillis(now);
                        context2 = context3;
                        calendar2.set(11, startMins / 60);
                        calendar2.set(12, startMins % 60);
                        calendar2.set(13, 0);
                        calendar2.set(14, 0);
                        todayClassStartMs = calendar2.getTimeInMillis();
                        now2 = now;
                        todayReminderMs = todayClassStartMs - (((long) reminderMinutes3) * 60000);
                        handledToday = false;
                        if (todayReminderMs > now2) {
                            classroom2 = classroom;
                            c08182 = c08183;
                            $result = $result2;
                            context3 = context2;
                            now3 = now2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, todayReminderMs, reminderMinutes3);
                            handledToday = true;
                        } else {
                            c08182 = c08183;
                            $result = $result2;
                            now3 = now2;
                            classroom2 = classroom;
                            context3 = context2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            if (now3 >= todayReminderMs && now3 < todayClassStartMs && !classroom2.isActiveSession()) {
                                reminderNotificationHelper.postSessionReminderNotification(context3, classroom2, reminderMinutes3);
                                handledToday = true;
                                nextOccurrenceTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, todayClassStartMs);
                                if (nextOccurrenceTrigger != null) {
                                    reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextOccurrenceTrigger.longValue(), reminderMinutes3);
                                }
                            }
                        }
                        if (handledToday) {
                            it = it2;
                            now = now3;
                            $result2 = $result;
                            c08183 = c08182;
                        } else {
                            nextTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, now3);
                            if (nextTrigger != null) {
                                reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextTrigger.longValue(), reminderMinutes3);
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            } else {
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            }
                        }
                    } else {
                        now = now;
                        c08183 = c08183;
                    }
                }
                return Unit.INSTANCE;
            case 1:
                reminderMinutes = c08183.I$0;
                isEnabled = c08183.Z$0;
                db = (CalisDatabase) c08183.L$2;
                prefs = (SharedPreferences) c08183.L$1;
                context3 = (Context) c08183.L$0;
                try {
                    ResultKt.throwOnFailure($result2);
                    allClassroomsSync = $result2;
                    allClassrooms = (List) allClassroomsSync;
                    break;
                } catch (Exception e2) {
                    allClassrooms = CollectionsKt.emptyList();
                }
                if (allClassrooms.isEmpty()) {
                    reminderMinutes3 = reminderMinutes;
                } else {
                    ClassroomDao classroomDao4 = db.classroomDao();
                    c08183.L$0 = context3;
                    c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                    c08183.L$2 = db;
                    c08183.L$3 = SpillingKt.nullOutSpilledVariable(allClassrooms);
                    c08183.Z$0 = isEnabled;
                    c08183.I$0 = reminderMinutes;
                    c08183.label = 2;
                    activeBoundClassroomSync = classroomDao4.getActiveBoundClassroomSync(c08183);
                    if (activeBoundClassroomSync == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    boolean z3 = isEnabled;
                    allClassrooms2 = allClassrooms;
                    reminderMinutes2 = reminderMinutes;
                    isEnabled2 = z3;
                    classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                    if (classroomEntity == null) {
                        ClassroomDao classroomDao5 = db.classroomDao();
                        c08183.L$0 = context3;
                        c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                        c08183.L$2 = SpillingKt.nullOutSpilledVariable(db);
                        c08183.L$3 = SpillingKt.nullOutSpilledVariable(allClassrooms2);
                        c08183.Z$0 = isEnabled2;
                        c08183.I$0 = reminderMinutes2;
                        c08183.label = 3;
                        anyClassroomSync = classroomDao5.getAnyClassroomSync(c08183);
                        if (anyClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        isEnabled4 = isEnabled2;
                        allClassrooms4 = allClassrooms2;
                        db2 = db;
                        prefs2 = prefs;
                        classroomEntity = (ClassroomEntity) anyClassroomSync;
                        List list2 = allClassrooms4;
                        reminderMinutes4 = reminderMinutes2;
                        allClassrooms3 = list2;
                        prefs = prefs2;
                        db = db2;
                        isEnabled3 = isEnabled4;
                    } else {
                        boolean z4 = isEnabled2;
                        reminderMinutes4 = reminderMinutes2;
                        allClassrooms3 = allClassrooms2;
                        isEnabled3 = z4;
                    }
                    allClassrooms = CollectionsKt.listOfNotNull(classroomEntity);
                    reminderMinutes3 = reminderMinutes4;
                }
                if (allClassrooms.isEmpty()) {
                    return Unit.INSTANCE;
                }
                this.cancelAlarm(context3, ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER, REQ_CODE_TC_ALARM);
                now = System.currentTimeMillis();
                calendar = Calendar.getInstance();
                calendar.setTimeInMillis(now);
                List classrooms2 = allClassrooms;
                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                it = classrooms2.iterator();
                while (it.hasNext()) {
                    classroom = (ClassroomEntity) it.next();
                    this.cancelSessionAlarm(context3, classroom);
                    todayDateStr = todayDateStr;
                    String todayDateStr3 = classroom.getStartTime();
                    startMins = this.parseTimeToMinutes(todayDateStr3);
                    if (startMins >= 0) {
                        ScheduleUtils scheduleUtils2 = ScheduleUtils.INSTANCE;
                        Intrinsics.checkNotNull(calendar);
                        scheduleUtils2.isDayInSchedule(calendar, classroom.getDays());
                        Calendar calendar3 = Calendar.getInstance();
                        calendar3.setTimeInMillis(now);
                        context2 = context3;
                        calendar3.set(11, startMins / 60);
                        calendar3.set(12, startMins % 60);
                        calendar3.set(13, 0);
                        calendar3.set(14, 0);
                        todayClassStartMs = calendar3.getTimeInMillis();
                        now2 = now;
                        todayReminderMs = todayClassStartMs - (((long) reminderMinutes3) * 60000);
                        handledToday = false;
                        if (todayReminderMs > now2) {
                            classroom2 = classroom;
                            c08182 = c08183;
                            $result = $result2;
                            context3 = context2;
                            now3 = now2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, todayReminderMs, reminderMinutes3);
                            handledToday = true;
                        } else {
                            c08182 = c08183;
                            $result = $result2;
                            now3 = now2;
                            classroom2 = classroom;
                            context3 = context2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            if (now3 >= todayReminderMs) {
                                reminderNotificationHelper.postSessionReminderNotification(context3, classroom2, reminderMinutes3);
                                handledToday = true;
                                nextOccurrenceTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, todayClassStartMs);
                                if (nextOccurrenceTrigger != null) {
                                    reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextOccurrenceTrigger.longValue(), reminderMinutes3);
                                }
                            }
                        }
                        if (handledToday) {
                            nextTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, now3);
                            if (nextTrigger != null) {
                                reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextTrigger.longValue(), reminderMinutes3);
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            } else {
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            }
                        } else {
                            it = it2;
                            now = now3;
                            $result2 = $result;
                            c08183 = c08182;
                        }
                    } else {
                        now = now;
                        c08183 = c08183;
                    }
                }
                return Unit.INSTANCE;
            case 2:
                reminderMinutes2 = c08183.I$0;
                isEnabled2 = c08183.Z$0;
                allClassrooms2 = (List) c08183.L$3;
                db = (CalisDatabase) c08183.L$2;
                prefs = (SharedPreferences) c08183.L$1;
                context3 = (Context) c08183.L$0;
                ResultKt.throwOnFailure($result2);
                activeBoundClassroomSync = $result2;
                classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                if (classroomEntity == null) {
                    ClassroomDao classroomDao6 = db.classroomDao();
                    c08183.L$0 = context3;
                    c08183.L$1 = SpillingKt.nullOutSpilledVariable(prefs);
                    c08183.L$2 = SpillingKt.nullOutSpilledVariable(db);
                    c08183.L$3 = SpillingKt.nullOutSpilledVariable(allClassrooms2);
                    c08183.Z$0 = isEnabled2;
                    c08183.I$0 = reminderMinutes2;
                    c08183.label = 3;
                    anyClassroomSync = classroomDao6.getAnyClassroomSync(c08183);
                    if (anyClassroomSync == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    isEnabled4 = isEnabled2;
                    allClassrooms4 = allClassrooms2;
                    db2 = db;
                    prefs2 = prefs;
                    classroomEntity = (ClassroomEntity) anyClassroomSync;
                    List list3 = allClassrooms4;
                    reminderMinutes4 = reminderMinutes2;
                    allClassrooms3 = list3;
                    prefs = prefs2;
                    db = db2;
                    isEnabled3 = isEnabled4;
                } else {
                    boolean z5 = isEnabled2;
                    reminderMinutes4 = reminderMinutes2;
                    allClassrooms3 = allClassrooms2;
                    isEnabled3 = z5;
                }
                allClassrooms = CollectionsKt.listOfNotNull(classroomEntity);
                reminderMinutes3 = reminderMinutes4;
                if (allClassrooms.isEmpty()) {
                    return Unit.INSTANCE;
                }
                this.cancelAlarm(context3, ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER, REQ_CODE_TC_ALARM);
                now = System.currentTimeMillis();
                calendar = Calendar.getInstance();
                calendar.setTimeInMillis(now);
                List classrooms3 = allClassrooms;
                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                it = classrooms3.iterator();
                while (it.hasNext()) {
                    classroom = (ClassroomEntity) it.next();
                    this.cancelSessionAlarm(context3, classroom);
                    todayDateStr = todayDateStr;
                    String todayDateStr4 = classroom.getStartTime();
                    startMins = this.parseTimeToMinutes(todayDateStr4);
                    if (startMins >= 0) {
                        ScheduleUtils scheduleUtils3 = ScheduleUtils.INSTANCE;
                        Intrinsics.checkNotNull(calendar);
                        scheduleUtils3.isDayInSchedule(calendar, classroom.getDays());
                        Calendar calendar4 = Calendar.getInstance();
                        calendar4.setTimeInMillis(now);
                        context2 = context3;
                        calendar4.set(11, startMins / 60);
                        calendar4.set(12, startMins % 60);
                        calendar4.set(13, 0);
                        calendar4.set(14, 0);
                        todayClassStartMs = calendar4.getTimeInMillis();
                        now2 = now;
                        todayReminderMs = todayClassStartMs - (((long) reminderMinutes3) * 60000);
                        handledToday = false;
                        if (todayReminderMs > now2) {
                            classroom2 = classroom;
                            c08182 = c08183;
                            $result = $result2;
                            context3 = context2;
                            now3 = now2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, todayReminderMs, reminderMinutes3);
                            handledToday = true;
                        } else {
                            c08182 = c08183;
                            $result = $result2;
                            now3 = now2;
                            classroom2 = classroom;
                            context3 = context2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            if (now3 >= todayReminderMs) {
                                reminderNotificationHelper.postSessionReminderNotification(context3, classroom2, reminderMinutes3);
                                handledToday = true;
                                nextOccurrenceTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, todayClassStartMs);
                                if (nextOccurrenceTrigger != null) {
                                    reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextOccurrenceTrigger.longValue(), reminderMinutes3);
                                }
                            }
                        }
                        if (handledToday) {
                            nextTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, now3);
                            if (nextTrigger != null) {
                                reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextTrigger.longValue(), reminderMinutes3);
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            } else {
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            }
                        } else {
                            it = it2;
                            now = now3;
                            $result2 = $result;
                            c08183 = c08182;
                        }
                    } else {
                        now = now;
                        c08183 = c08183;
                    }
                }
                return Unit.INSTANCE;
            case 3:
                reminderMinutes2 = c08183.I$0;
                isEnabled4 = c08183.Z$0;
                allClassrooms4 = (List) c08183.L$3;
                db2 = (CalisDatabase) c08183.L$2;
                prefs2 = (SharedPreferences) c08183.L$1;
                context3 = (Context) c08183.L$0;
                ResultKt.throwOnFailure($result2);
                anyClassroomSync = $result2;
                classroomEntity = (ClassroomEntity) anyClassroomSync;
                List list4 = allClassrooms4;
                reminderMinutes4 = reminderMinutes2;
                allClassrooms3 = list4;
                prefs = prefs2;
                db = db2;
                isEnabled3 = isEnabled4;
                allClassrooms = CollectionsKt.listOfNotNull(classroomEntity);
                reminderMinutes3 = reminderMinutes4;
                if (allClassrooms.isEmpty()) {
                    return Unit.INSTANCE;
                }
                this.cancelAlarm(context3, ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER, REQ_CODE_TC_ALARM);
                now = System.currentTimeMillis();
                calendar = Calendar.getInstance();
                calendar.setTimeInMillis(now);
                List classrooms4 = allClassrooms;
                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                it = classrooms4.iterator();
                while (it.hasNext()) {
                    classroom = (ClassroomEntity) it.next();
                    this.cancelSessionAlarm(context3, classroom);
                    todayDateStr = todayDateStr;
                    String todayDateStr5 = classroom.getStartTime();
                    startMins = this.parseTimeToMinutes(todayDateStr5);
                    if (startMins >= 0) {
                        ScheduleUtils scheduleUtils4 = ScheduleUtils.INSTANCE;
                        Intrinsics.checkNotNull(calendar);
                        scheduleUtils4.isDayInSchedule(calendar, classroom.getDays());
                        Calendar calendar5 = Calendar.getInstance();
                        calendar5.setTimeInMillis(now);
                        context2 = context3;
                        calendar5.set(11, startMins / 60);
                        calendar5.set(12, startMins % 60);
                        calendar5.set(13, 0);
                        calendar5.set(14, 0);
                        todayClassStartMs = calendar5.getTimeInMillis();
                        now2 = now;
                        todayReminderMs = todayClassStartMs - (((long) reminderMinutes3) * 60000);
                        handledToday = false;
                        if (todayReminderMs > now2) {
                            classroom2 = classroom;
                            c08182 = c08183;
                            $result = $result2;
                            context3 = context2;
                            now3 = now2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, todayReminderMs, reminderMinutes3);
                            handledToday = true;
                        } else {
                            c08182 = c08183;
                            $result = $result2;
                            now3 = now2;
                            classroom2 = classroom;
                            context3 = context2;
                            reminderNotificationHelper = this;
                            it2 = it;
                            if (now3 >= todayReminderMs) {
                                reminderNotificationHelper.postSessionReminderNotification(context3, classroom2, reminderMinutes3);
                                handledToday = true;
                                nextOccurrenceTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, todayClassStartMs);
                                if (nextOccurrenceTrigger != null) {
                                    reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextOccurrenceTrigger.longValue(), reminderMinutes3);
                                }
                            }
                        }
                        if (handledToday) {
                            nextTrigger = reminderNotificationHelper.calculateNextSessionReminderTime(classroom2, reminderMinutes3, now3);
                            if (nextTrigger != null) {
                                reminderNotificationHelper.scheduleSessionAlarm(context3, classroom2, nextTrigger.longValue(), reminderMinutes3);
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            } else {
                                it = it2;
                                now = now3;
                                $result2 = $result;
                                c08183 = c08182;
                            }
                        } else {
                            it = it2;
                            now = now3;
                            $result2 = $result;
                            c08183 = c08182;
                        }
                    } else {
                        now = now;
                        c08183 = c08183;
                    }
                }
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    public final void checkAndPostSessionReminder(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
        boolean isEnabled = prefs.getBoolean("remind_start_session", false);
        if (isEnabled) {
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C08151(context, null), 3, null);
        } else {
            cancelSessionReminder(context);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$checkAndPostSessionReminder$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$checkAndPostSessionReminder$1", f = "ReminderNotificationHelper.kt", i = {}, l = {461}, m = "invokeSuspend", n = {}, s = {})
    static final class C08151 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08151(Context context, Continuation<? super C08151> continuation) {
            super(2, continuation);
            this.$context = context;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C08151(this.$context, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08151) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (ReminderNotificationHelper.INSTANCE.rescheduleSessionRemindersSync(this.$context, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } catch (Exception e) {
                Log.e(ReminderNotificationHelper.TAG, "Error in checkAndPostSessionReminder", e);
            }
            return Unit.INSTANCE;
        }
    }

    public final void clearSessionReminderKeys(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
            SharedPreferences.Editor editor = prefs.edit();
            for (String key : prefs.getAll().keySet()) {
                Intrinsics.checkNotNull(key);
                if (StringsKt.startsWith$default(key, "last_session_reminded_key_", false, 2, (Object) null) || Intrinsics.areEqual(key, "last_session_reminded_date") || StringsKt.startsWith$default(key, "session_reminded_", false, 2, (Object) null)) {
                    editor.remove(key);
                }
            }
            editor.apply();
        } catch (Exception e) {
            Log.e(TAG, "Error clearing session reminder keys", e);
        }
    }

    public final void clearTaskReminderKeys(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
            SharedPreferences.Editor editor = prefs.edit();
            for (String key : prefs.getAll().keySet()) {
                Intrinsics.checkNotNull(key);
                if (StringsKt.startsWith$default(key, "task_reminded_", false, 2, (Object) null) || Intrinsics.areEqual(key, "task_deadline_dismissed_date")) {
                    editor.remove(key);
                }
            }
            editor.apply();
            Log.d(TAG, "Cleared task reminder keys");
        } catch (Exception e) {
            Log.e(TAG, "Error clearing task reminder keys", e);
        }
    }

    /* JADX WARN: Code duplicated, block: B:105:0x029f A[Catch: Exception -> 0x0381, TRY_LEAVE, TryCatch #9 {Exception -> 0x0381, blocks: (B:103:0x0299, B:105:0x029f, B:125:0x036e), top: B:154:0x0299 }] */
    /* JADX WARN: Code duplicated, block: B:112:0x02c7 A[Catch: Exception -> 0x033e, TryCatch #1 {Exception -> 0x033e, blocks: (B:110:0x02ad, B:112:0x02c7, B:114:0x02f9), top: B:139:0x02ad }] */
    /* JADX WARN: Code duplicated, block: B:113:0x02f5  */
    /* JADX WARN: Code duplicated, block: B:120:0x0355  */
    /* JADX WARN: Code duplicated, block: B:123:0x0368 A[Catch: Exception -> 0x0375, TRY_LEAVE, TryCatch #6 {Exception -> 0x0375, blocks: (B:121:0x0357, B:123:0x0368), top: B:149:0x0357 }] */
    /* JADX WARN: Code duplicated, block: B:127:0x0372  */
    /* JADX WARN: Code duplicated, block: B:143:0x019a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:145:0x02a7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:154:0x0299 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x01c1 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:73:0x01c2  */
    /* JADX WARN: Code duplicated, block: B:76:0x01c9 A[Catch: Exception -> 0x0289, TRY_LEAVE, TryCatch #3 {Exception -> 0x0289, blocks: (B:74:0x01c5, B:76:0x01c9, B:68:0x019a), top: B:143:0x019a }] */
    /* JADX WARN: Code duplicated, block: B:7:0x001e  */
    /* JADX WARN: Code duplicated, block: B:80:0x01f4 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:81:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:84:0x0207 A[Catch: Exception -> 0x0262, TryCatch #8 {Exception -> 0x0262, blocks: (B:82:0x0203, B:84:0x0207, B:86:0x0211, B:88:0x021b, B:90:0x0225), top: B:152:0x0203 }] */
    /* JADX WARN: Code duplicated, block: B:86:0x0211 A[Catch: Exception -> 0x0262, TryCatch #8 {Exception -> 0x0262, blocks: (B:82:0x0203, B:84:0x0207, B:86:0x0211, B:88:0x021b, B:90:0x0225), top: B:152:0x0203 }] */
    /* JADX WARN: Code duplicated, block: B:92:0x024d  */
    /* JADX WARN: Code duplicated, block: B:93:0x0258  */
    /* JADX WARN: Code duplicated, block: B:98:0x027a A[PHI: r2 r3 r5 r6 r10 r11 r12 r13 r14 r15 r32
      0x027a: PHI (r2v17 'context' android.content.Context) = (r2v9 'context' android.content.Context), (r2v19 'context' android.content.Context) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r3v10 'targetCid' java.lang.String) = (r3v5 'targetCid' java.lang.String), (r3v14 'targetCid' java.lang.String) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r5v17 com.example.data.db.ClassroomEntity) = (r5v8 com.example.data.db.ClassroomEntity), (r5v21 com.example.data.db.ClassroomEntity) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r6v16 'reminderMinutesExtra' int) = (r6v13 'reminderMinutesExtra' int), (r6v22 'reminderMinutesExtra' int) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r10v28 'reminderMinutes' int) = (r10v23 'reminderMinutes' int), (r10v34 'reminderMinutes' int) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r11v6 'isEnabled' boolean) = (r11v3 'isEnabled' boolean), (r11v10 'isEnabled' boolean) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r12v14 'prefs' android.content.SharedPreferences) = (r12v7 'prefs' android.content.SharedPreferences), (r12v17 'prefs' android.content.SharedPreferences) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r13v9 'db' com.example.data.db.CalisDatabase) = (r13v4 'db' com.example.data.db.CalisDatabase), (r13v13 'db' com.example.data.db.CalisDatabase) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r14v8 'classroomNameExtra' java.lang.String) = (r14v3 'classroomNameExtra' java.lang.String), (r14v14 'classroomNameExtra' java.lang.String) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r15v7 'targetCid' java.lang.String) = (r15v2 'targetCid' java.lang.String), (r15v13 'targetCid' java.lang.String) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]
      0x027a: PHI (r32v4 'intent' android.content.Intent) = (r32v2 'intent' android.content.Intent), (r32v7 'intent' android.content.Intent) binds: [B:67:0x0198, B:75:0x01c7] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Not initialized variable reg: 12, insn: 0x00d7: MOVE (r6 I:??[OBJECT, ARRAY] A[D('reminderMinutesExtra' int)]) = (r12 I:??[OBJECT, ARRAY] A[D('prefs' android.content.SharedPreferences)]), block:B:24:0x00d5 */
    /* JADX WARN: Not initialized variable reg: 17, insn: 0x00d8: MOVE (r4 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r17 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('reminderMinutes' int)]), block:B:24:0x00d5 */
    public final Object handleSessionReminderAlarmTrigger(Context context, Intent intent, Continuation<? super Unit> continuation) {
        C08171 c08171;
        int reminderMinutesExtra;
        SharedPreferences prefs;
        SharedPreferences prefs2;
        int reminderMinutes;
        int reminderMinutes2;
        Context context2;
        String classroomNameExtra;
        String classroomStartTimeExtra;
        boolean isEnabled;
        String lastPathSegment;
        Uri data;
        String targetCid;
        String stringExtra;
        int reminderMinutesExtra2;
        int reminderMinutes3;
        Context context3;
        Intent intent2;
        String targetCid2;
        String targetCid3;
        String classroomNameExtra2;
        CalisDatabase db;
        SharedPreferences prefs3;
        ClassroomEntity classroomEntity;
        Intent intent3;
        int reminderMinutes4;
        CalisDatabase db2;
        Object obj;
        String stringExtra2;
        Object activeBoundClassroomSync;
        Object obj2;
        String classroomStartTimeExtra2;
        String classroomNameExtra3;
        ClassroomEntity classroom;
        boolean isEnabled2;
        int reminderMinutesExtra3;
        int reminderMinutes5;
        Object anyClassroomSync;
        Object obj3;
        String targetCid4;
        CalisDatabase db3;
        Intent intent4;
        boolean posted;
        int startMins;
        long todayClassStartMs;
        Long nextTrigger;
        ClassroomEntity classroomEntity2;
        if (continuation instanceof C08171) {
            c08171 = (C08171) continuation;
            if ((c08171.label & Integer.MIN_VALUE) != 0) {
                c08171.label -= Integer.MIN_VALUE;
            } else {
                c08171 = new C08171(continuation);
            }
        } else {
            c08171 = new C08171(continuation);
        }
        C08171 c08172 = c08171;
        Object $result = c08172.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        try {
            switch (c08172.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    SharedPreferences prefs4 = context.getSharedPreferences("calis_auth_prefs", 0);
                    isEnabled = prefs4.getBoolean("remind_start_session", false);
                    if (!isEnabled) {
                        cancelSessionReminder(context);
                        return Unit.INSTANCE;
                    }
                    String str = "";
                    if (intent == null || (lastPathSegment = intent.getStringExtra(EXTRA_CLASSROOM_ID)) == null) {
                        lastPathSegment = (intent == null || (data = intent.getData()) == null) ? null : data.getLastPathSegment();
                        if (lastPathSegment == null) {
                            lastPathSegment = "";
                        }
                    }
                    targetCid = lastPathSegment;
                    if (intent == null || (stringExtra = intent.getStringExtra(EXTRA_CLASSROOM_NAME)) == null) {
                        stringExtra = "";
                    }
                    classroomNameExtra = stringExtra;
                    if (intent != null && (stringExtra2 = intent.getStringExtra(EXTRA_CLASSROOM_START_TIME)) != null) {
                        str = stringExtra2;
                    }
                    classroomStartTimeExtra = str;
                    reminderMinutesExtra2 = intent != null ? intent.getIntExtra(EXTRA_REMINDER_MINUTES, -1) : -1;
                    reminderMinutes3 = reminderMinutesExtra2 > 0 ? reminderMinutesExtra2 : prefs4.getInt("remind_start_session_minutes", 15);
                    try {
                        CalisDatabase db4 = CalisDatabase.INSTANCE.getDatabase(context);
                        if (StringsKt.isBlank(targetCid)) {
                            context3 = context;
                            intent2 = intent;
                            targetCid2 = targetCid;
                            targetCid3 = classroomNameExtra;
                            classroomNameExtra2 = classroomStartTimeExtra;
                            db = db4;
                            prefs3 = prefs4;
                            classroomEntity = null;
                        } else {
                            ClassroomDao classroomDao = db4.classroomDao();
                            c08172.L$0 = context;
                            c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent);
                            c08172.L$2 = prefs4;
                            c08172.L$3 = targetCid;
                            c08172.L$4 = classroomNameExtra;
                            c08172.L$5 = classroomStartTimeExtra;
                            c08172.L$6 = db4;
                            c08172.Z$0 = isEnabled;
                            c08172.I$0 = reminderMinutesExtra2;
                            c08172.I$1 = reminderMinutes3;
                            c08172.label = 1;
                            Object classroomById = classroomDao.getClassroomById(targetCid, c08172);
                            if (classroomById == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            intent3 = intent;
                            reminderMinutes4 = reminderMinutes3;
                            db2 = db4;
                            prefs3 = prefs4;
                            obj = classroomById;
                            context3 = context;
                            classroomEntity = (ClassroomEntity) obj;
                            intent2 = intent3;
                            targetCid2 = targetCid;
                            targetCid3 = classroomNameExtra;
                            classroomNameExtra2 = classroomStartTimeExtra;
                            db = db2;
                            reminderMinutes3 = reminderMinutes4;
                        }
                        if (classroomEntity == null) {
                            try {
                                ClassroomDao classroomDao2 = db.classroomDao();
                                c08172.L$0 = context3;
                                context2 = context3;
                                try {
                                    c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent2);
                                    c08172.L$2 = prefs3;
                                    c08172.L$3 = targetCid2;
                                    c08172.L$4 = targetCid3;
                                    c08172.L$5 = classroomNameExtra2;
                                    c08172.L$6 = db;
                                    c08172.Z$0 = isEnabled;
                                    c08172.I$0 = reminderMinutesExtra2;
                                    c08172.I$1 = reminderMinutes3;
                                    c08172.label = 2;
                                    activeBoundClassroomSync = classroomDao2.getActiveBoundClassroomSync(c08172);
                                    if (activeBoundClassroomSync == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    obj2 = activeBoundClassroomSync;
                                    context3 = context2;
                                    classroomEntity = (ClassroomEntity) obj2;
                                    if (classroomEntity == null) {
                                        ClassroomDao classroomDao3 = db.classroomDao();
                                        c08172.L$0 = context3;
                                        context2 = context3;
                                        c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent2);
                                        c08172.L$2 = prefs3;
                                        c08172.L$3 = targetCid2;
                                        c08172.L$4 = targetCid3;
                                        c08172.L$5 = classroomNameExtra2;
                                        c08172.L$6 = SpillingKt.nullOutSpilledVariable(db);
                                        c08172.Z$0 = isEnabled;
                                        c08172.I$0 = reminderMinutesExtra2;
                                        c08172.I$1 = reminderMinutes3;
                                        c08172.label = 3;
                                        anyClassroomSync = classroomDao3.getAnyClassroomSync(c08172);
                                        if (anyClassroomSync == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        obj3 = anyClassroomSync;
                                        targetCid4 = targetCid2;
                                        reminderMinutesExtra = reminderMinutesExtra2;
                                        prefs2 = prefs3;
                                        db3 = db;
                                        classroomStartTimeExtra2 = classroomNameExtra2;
                                        classroomNameExtra3 = targetCid3;
                                        context3 = context2;
                                        intent4 = intent2;
                                        try {
                                            classroomEntity2 = (ClassroomEntity) obj3;
                                            if (classroomEntity2 == null) {
                                                isEnabled2 = isEnabled;
                                                reminderMinutesExtra3 = reminderMinutesExtra;
                                                prefs3 = prefs2;
                                                reminderMinutes5 = reminderMinutes3;
                                                classroom = classroomEntity2;
                                            } else if (!StringsKt.isBlank(targetCid4) || StringsKt.isBlank(classroomNameExtra3) || StringsKt.isBlank(classroomStartTimeExtra2)) {
                                                isEnabled2 = isEnabled;
                                                reminderMinutesExtra3 = reminderMinutesExtra;
                                                prefs3 = prefs2;
                                                reminderMinutes5 = reminderMinutes3;
                                                classroom = null;
                                            } else {
                                                isEnabled2 = isEnabled;
                                                reminderMinutesExtra3 = reminderMinutesExtra;
                                                prefs3 = prefs2;
                                                reminderMinutes5 = reminderMinutes3;
                                                classroom = new ClassroomEntity(targetCid4, "", classroomNameExtra3, "", "", classroomStartTimeExtra2, "", "", false, false, null, 1792, null);
                                            }
                                        } catch (Exception e) {
                                            e = e;
                                            context2 = context3;
                                            reminderMinutes2 = reminderMinutes3;
                                            classroomNameExtra = classroomNameExtra3;
                                            classroomStartTimeExtra = classroomStartTimeExtra2;
                                            Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                                            return Unit.INSTANCE;
                                        }
                                    } else {
                                        classroomStartTimeExtra2 = classroomNameExtra2;
                                        classroomNameExtra3 = targetCid3;
                                        classroom = classroomEntity;
                                        isEnabled2 = isEnabled;
                                        reminderMinutesExtra3 = reminderMinutesExtra2;
                                        reminderMinutes5 = reminderMinutes3;
                                    }
                                } catch (Exception e2) {
                                    e = e2;
                                    reminderMinutesExtra = reminderMinutesExtra2;
                                    reminderMinutes2 = reminderMinutes3;
                                    prefs2 = prefs3;
                                    classroomStartTimeExtra = classroomNameExtra2;
                                    classroomNameExtra = targetCid3;
                                    Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                                    return Unit.INSTANCE;
                                }
                            } catch (Exception e3) {
                                e = e3;
                                context2 = context3;
                                reminderMinutesExtra = reminderMinutesExtra2;
                                reminderMinutes2 = reminderMinutes3;
                                prefs2 = prefs3;
                                classroomStartTimeExtra = classroomNameExtra2;
                                classroomNameExtra = targetCid3;
                                Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                                return Unit.INSTANCE;
                            }
                        } else {
                            classroomStartTimeExtra2 = classroomNameExtra2;
                            classroomNameExtra3 = targetCid3;
                            classroom = classroomEntity;
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra2;
                            reminderMinutes5 = reminderMinutes3;
                        }
                        if (classroom != null) {
                            try {
                                if (!classroom.isActiveSession()) {
                                    posted = postSessionReminderNotification(context3, classroom, reminderMinutes5);
                                    if (posted) {
                                        try {
                                            context2 = context3;
                                            try {
                                                String todayStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                                startMins = parseTimeToMinutes(classroom.getStartTime());
                                                if (startMins >= 0) {
                                                    Calendar calendar = Calendar.getInstance();
                                                    calendar.set(11, startMins / 60);
                                                    calendar.set(12, startMins % 60);
                                                    calendar.set(13, 0);
                                                    calendar.set(14, 0);
                                                    todayClassStartMs = calendar.getTimeInMillis();
                                                } else {
                                                    todayClassStartMs = 0;
                                                }
                                                String currentKey = todayStr + "_" + todayClassStartMs + "_" + reminderMinutes5;
                                                SharedPreferences.Editor editorEdit = prefs3.edit();
                                                String todayStr2 = classroom.getCid();
                                                editorEdit.putString("last_session_reminded_key_" + todayStr2, currentKey).apply();
                                            } catch (Exception e4) {
                                                e = e4;
                                                reminderMinutes2 = reminderMinutes5;
                                                reminderMinutesExtra = reminderMinutesExtra3;
                                                prefs2 = prefs3;
                                                isEnabled = isEnabled2;
                                                classroomNameExtra = classroomNameExtra3;
                                                classroomStartTimeExtra = classroomStartTimeExtra2;
                                                Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                                                return Unit.INSTANCE;
                                            }
                                        } catch (Exception e5) {
                                            e = e5;
                                            context2 = context3;
                                            reminderMinutes2 = reminderMinutes5;
                                            reminderMinutesExtra = reminderMinutesExtra3;
                                            prefs2 = prefs3;
                                            isEnabled = isEnabled2;
                                            classroomNameExtra = classroomNameExtra3;
                                            classroomStartTimeExtra = classroomStartTimeExtra2;
                                        }
                                    } else {
                                        context2 = context3;
                                    }
                                    try {
                                        long now = System.currentTimeMillis();
                                        nextTrigger = calculateNextSessionReminderTime(classroom, reminderMinutes5, now + 60000);
                                        if (nextTrigger != null) {
                                            context3 = context2;
                                            scheduleSessionAlarm(context3, classroom, nextTrigger.longValue(), reminderMinutes5);
                                            break;
                                        }
                                    } catch (Exception e6) {
                                        e = e6;
                                        reminderMinutes2 = reminderMinutes5;
                                        reminderMinutesExtra = reminderMinutesExtra3;
                                        prefs2 = prefs3;
                                        isEnabled = isEnabled2;
                                        classroomNameExtra = classroomNameExtra3;
                                        classroomStartTimeExtra = classroomStartTimeExtra2;
                                        Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                                    }
                                }
                            } catch (Exception e7) {
                                e = e7;
                                context2 = context3;
                                reminderMinutes2 = reminderMinutes5;
                                reminderMinutesExtra = reminderMinutesExtra3;
                                prefs2 = prefs3;
                                isEnabled = isEnabled2;
                                classroomNameExtra = classroomNameExtra3;
                                classroomStartTimeExtra = classroomStartTimeExtra2;
                            }
                        }
                        break;
                    } catch (Exception e8) {
                        e = e8;
                        int i = reminderMinutesExtra2;
                        prefs2 = prefs4;
                        reminderMinutesExtra = i;
                        context2 = context;
                        reminderMinutes2 = reminderMinutes3;
                        Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                        return Unit.INSTANCE;
                    }
                    return Unit.INSTANCE;
                case 1:
                    int reminderMinutes6 = c08172.I$1;
                    reminderMinutesExtra2 = c08172.I$0;
                    isEnabled = c08172.Z$0;
                    db2 = (CalisDatabase) c08172.L$6;
                    classroomStartTimeExtra = (String) c08172.L$5;
                    classroomNameExtra = (String) c08172.L$4;
                    targetCid = (String) c08172.L$3;
                    prefs3 = (SharedPreferences) c08172.L$2;
                    reminderMinutes4 = reminderMinutes6;
                    intent3 = (Intent) c08172.L$1;
                    context3 = (Context) c08172.L$0;
                    ResultKt.throwOnFailure($result);
                    obj = $result;
                    classroomEntity = (ClassroomEntity) obj;
                    intent2 = intent3;
                    targetCid2 = targetCid;
                    targetCid3 = classroomNameExtra;
                    classroomNameExtra2 = classroomStartTimeExtra;
                    db = db2;
                    reminderMinutes3 = reminderMinutes4;
                    if (classroomEntity == null) {
                        ClassroomDao classroomDao4 = db.classroomDao();
                        c08172.L$0 = context3;
                        context2 = context3;
                        c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent2);
                        c08172.L$2 = prefs3;
                        c08172.L$3 = targetCid2;
                        c08172.L$4 = targetCid3;
                        c08172.L$5 = classroomNameExtra2;
                        c08172.L$6 = db;
                        c08172.Z$0 = isEnabled;
                        c08172.I$0 = reminderMinutesExtra2;
                        c08172.I$1 = reminderMinutes3;
                        c08172.label = 2;
                        activeBoundClassroomSync = classroomDao4.getActiveBoundClassroomSync(c08172);
                        if (activeBoundClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        obj2 = activeBoundClassroomSync;
                        context3 = context2;
                        classroomEntity = (ClassroomEntity) obj2;
                        if (classroomEntity == null) {
                            ClassroomDao classroomDao5 = db.classroomDao();
                            c08172.L$0 = context3;
                            context2 = context3;
                            c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent2);
                            c08172.L$2 = prefs3;
                            c08172.L$3 = targetCid2;
                            c08172.L$4 = targetCid3;
                            c08172.L$5 = classroomNameExtra2;
                            c08172.L$6 = SpillingKt.nullOutSpilledVariable(db);
                            c08172.Z$0 = isEnabled;
                            c08172.I$0 = reminderMinutesExtra2;
                            c08172.I$1 = reminderMinutes3;
                            c08172.label = 3;
                            anyClassroomSync = classroomDao5.getAnyClassroomSync(c08172);
                            if (anyClassroomSync == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            obj3 = anyClassroomSync;
                            targetCid4 = targetCid2;
                            reminderMinutesExtra = reminderMinutesExtra2;
                            prefs2 = prefs3;
                            db3 = db;
                            classroomStartTimeExtra2 = classroomNameExtra2;
                            classroomNameExtra3 = targetCid3;
                            context3 = context2;
                            intent4 = intent2;
                            classroomEntity2 = (ClassroomEntity) obj3;
                            if (classroomEntity2 == null) {
                                isEnabled2 = isEnabled;
                                reminderMinutesExtra3 = reminderMinutesExtra;
                                prefs3 = prefs2;
                                reminderMinutes5 = reminderMinutes3;
                                classroom = classroomEntity2;
                            } else if (StringsKt.isBlank(targetCid4)) {
                                isEnabled2 = isEnabled;
                                reminderMinutesExtra3 = reminderMinutesExtra;
                                prefs3 = prefs2;
                                reminderMinutes5 = reminderMinutes3;
                                classroom = null;
                            } else {
                                isEnabled2 = isEnabled;
                                reminderMinutesExtra3 = reminderMinutesExtra;
                                prefs3 = prefs2;
                                reminderMinutes5 = reminderMinutes3;
                                classroom = null;
                            }
                        } else {
                            classroomStartTimeExtra2 = classroomNameExtra2;
                            classroomNameExtra3 = targetCid3;
                            classroom = classroomEntity;
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra2;
                            reminderMinutes5 = reminderMinutes3;
                        }
                    } else {
                        classroomStartTimeExtra2 = classroomNameExtra2;
                        classroomNameExtra3 = targetCid3;
                        classroom = classroomEntity;
                        isEnabled2 = isEnabled;
                        reminderMinutesExtra3 = reminderMinutesExtra2;
                        reminderMinutes5 = reminderMinutes3;
                    }
                    if (classroom != null) {
                        if (!classroom.isActiveSession()) {
                            posted = postSessionReminderNotification(context3, classroom, reminderMinutes5);
                            if (posted) {
                                context2 = context3;
                                String todayStr3 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                startMins = parseTimeToMinutes(classroom.getStartTime());
                                if (startMins >= 0) {
                                    Calendar calendar2 = Calendar.getInstance();
                                    calendar2.set(11, startMins / 60);
                                    calendar2.set(12, startMins % 60);
                                    calendar2.set(13, 0);
                                    calendar2.set(14, 0);
                                    todayClassStartMs = calendar2.getTimeInMillis();
                                } else {
                                    todayClassStartMs = 0;
                                }
                                String currentKey2 = todayStr3 + "_" + todayClassStartMs + "_" + reminderMinutes5;
                                SharedPreferences.Editor editorEdit2 = prefs3.edit();
                                String todayStr4 = classroom.getCid();
                                editorEdit2.putString("last_session_reminded_key_" + todayStr4, currentKey2).apply();
                            } else {
                                context2 = context3;
                            }
                            long now2 = System.currentTimeMillis();
                            nextTrigger = calculateNextSessionReminderTime(classroom, reminderMinutes5, now2 + 60000);
                            if (nextTrigger != null) {
                                context3 = context2;
                                scheduleSessionAlarm(context3, classroom, nextTrigger.longValue(), reminderMinutes5);
                                break;
                            }
                        }
                        break;
                    }
                    return Unit.INSTANCE;
                case 2:
                    int reminderMinutesExtra4 = c08172.I$1;
                    reminderMinutesExtra2 = c08172.I$0;
                    isEnabled = c08172.Z$0;
                    CalisDatabase db5 = (CalisDatabase) c08172.L$6;
                    String classroomStartTimeExtra3 = (String) c08172.L$5;
                    String classroomNameExtra4 = (String) c08172.L$4;
                    String targetCid5 = (String) c08172.L$3;
                    prefs3 = (SharedPreferences) c08172.L$2;
                    Intent intent5 = (Intent) c08172.L$1;
                    context3 = (Context) c08172.L$0;
                    ResultKt.throwOnFailure($result);
                    intent2 = intent5;
                    obj2 = $result;
                    targetCid2 = targetCid5;
                    targetCid3 = classroomNameExtra4;
                    classroomNameExtra2 = classroomStartTimeExtra3;
                    db = db5;
                    reminderMinutes3 = reminderMinutesExtra4;
                    classroomEntity = (ClassroomEntity) obj2;
                    if (classroomEntity == null) {
                        ClassroomDao classroomDao6 = db.classroomDao();
                        c08172.L$0 = context3;
                        context2 = context3;
                        c08172.L$1 = SpillingKt.nullOutSpilledVariable(intent2);
                        c08172.L$2 = prefs3;
                        c08172.L$3 = targetCid2;
                        c08172.L$4 = targetCid3;
                        c08172.L$5 = classroomNameExtra2;
                        c08172.L$6 = SpillingKt.nullOutSpilledVariable(db);
                        c08172.Z$0 = isEnabled;
                        c08172.I$0 = reminderMinutesExtra2;
                        c08172.I$1 = reminderMinutes3;
                        c08172.label = 3;
                        anyClassroomSync = classroomDao6.getAnyClassroomSync(c08172);
                        if (anyClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        obj3 = anyClassroomSync;
                        targetCid4 = targetCid2;
                        reminderMinutesExtra = reminderMinutesExtra2;
                        prefs2 = prefs3;
                        db3 = db;
                        classroomStartTimeExtra2 = classroomNameExtra2;
                        classroomNameExtra3 = targetCid3;
                        context3 = context2;
                        intent4 = intent2;
                        classroomEntity2 = (ClassroomEntity) obj3;
                        if (classroomEntity2 == null) {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = classroomEntity2;
                        } else if (StringsKt.isBlank(targetCid4)) {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = null;
                        } else {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = null;
                        }
                    } else {
                        classroomStartTimeExtra2 = classroomNameExtra2;
                        classroomNameExtra3 = targetCid3;
                        classroom = classroomEntity;
                        isEnabled2 = isEnabled;
                        reminderMinutesExtra3 = reminderMinutesExtra2;
                        reminderMinutes5 = reminderMinutes3;
                    }
                    if (classroom != null) {
                        if (!classroom.isActiveSession()) {
                            posted = postSessionReminderNotification(context3, classroom, reminderMinutes5);
                            if (posted) {
                                context2 = context3;
                                String todayStr5 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                startMins = parseTimeToMinutes(classroom.getStartTime());
                                if (startMins >= 0) {
                                    Calendar calendar3 = Calendar.getInstance();
                                    calendar3.set(11, startMins / 60);
                                    calendar3.set(12, startMins % 60);
                                    calendar3.set(13, 0);
                                    calendar3.set(14, 0);
                                    todayClassStartMs = calendar3.getTimeInMillis();
                                } else {
                                    todayClassStartMs = 0;
                                }
                                String currentKey3 = todayStr5 + "_" + todayClassStartMs + "_" + reminderMinutes5;
                                SharedPreferences.Editor editorEdit3 = prefs3.edit();
                                String todayStr6 = classroom.getCid();
                                editorEdit3.putString("last_session_reminded_key_" + todayStr6, currentKey3).apply();
                            } else {
                                context2 = context3;
                            }
                            long now3 = System.currentTimeMillis();
                            nextTrigger = calculateNextSessionReminderTime(classroom, reminderMinutes5, now3 + 60000);
                            if (nextTrigger != null) {
                                context3 = context2;
                                scheduleSessionAlarm(context3, classroom, nextTrigger.longValue(), reminderMinutes5);
                                break;
                            }
                        }
                        break;
                    }
                    return Unit.INSTANCE;
                case 3:
                    reminderMinutes2 = c08172.I$1;
                    reminderMinutesExtra = c08172.I$0;
                    isEnabled = c08172.Z$0;
                    db3 = (CalisDatabase) c08172.L$6;
                    classroomStartTimeExtra = (String) c08172.L$5;
                    classroomNameExtra = (String) c08172.L$4;
                    String targetCid6 = (String) c08172.L$3;
                    prefs2 = (SharedPreferences) c08172.L$2;
                    intent4 = (Intent) c08172.L$1;
                    context3 = (Context) c08172.L$0;
                    try {
                        ResultKt.throwOnFailure($result);
                        reminderMinutes3 = reminderMinutes2;
                        obj3 = $result;
                        classroomStartTimeExtra2 = classroomStartTimeExtra;
                        classroomNameExtra3 = classroomNameExtra;
                        targetCid4 = targetCid6;
                        classroomEntity2 = (ClassroomEntity) obj3;
                        if (classroomEntity2 == null) {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = classroomEntity2;
                        } else if (StringsKt.isBlank(targetCid4)) {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = null;
                        } else {
                            isEnabled2 = isEnabled;
                            reminderMinutesExtra3 = reminderMinutesExtra;
                            prefs3 = prefs2;
                            reminderMinutes5 = reminderMinutes3;
                            classroom = null;
                        }
                        if (classroom != null) {
                            if (!classroom.isActiveSession()) {
                                posted = postSessionReminderNotification(context3, classroom, reminderMinutes5);
                                if (posted) {
                                    context2 = context3;
                                    String todayStr7 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                    startMins = parseTimeToMinutes(classroom.getStartTime());
                                    if (startMins >= 0) {
                                        Calendar calendar4 = Calendar.getInstance();
                                        calendar4.set(11, startMins / 60);
                                        calendar4.set(12, startMins % 60);
                                        calendar4.set(13, 0);
                                        calendar4.set(14, 0);
                                        todayClassStartMs = calendar4.getTimeInMillis();
                                    } else {
                                        todayClassStartMs = 0;
                                    }
                                    String currentKey4 = todayStr7 + "_" + todayClassStartMs + "_" + reminderMinutes5;
                                    SharedPreferences.Editor editorEdit4 = prefs3.edit();
                                    String todayStr8 = classroom.getCid();
                                    editorEdit4.putString("last_session_reminded_key_" + todayStr8, currentKey4).apply();
                                } else {
                                    context2 = context3;
                                }
                                long now4 = System.currentTimeMillis();
                                nextTrigger = calculateNextSessionReminderTime(classroom, reminderMinutes5, now4 + 60000);
                                if (nextTrigger != null) {
                                    context3 = context2;
                                    scheduleSessionAlarm(context3, classroom, nextTrigger.longValue(), reminderMinutes5);
                                    break;
                                }
                            }
                        }
                        break;
                    } catch (Exception e9) {
                        e = e9;
                        context2 = context3;
                        Log.e(TAG, "Error in handleSessionReminderAlarmTrigger", e);
                        return Unit.INSTANCE;
                    }
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        } catch (Exception e10) {
            e = e10;
            reminderMinutesExtra = Integer.MIN_VALUE;
            prefs2 = prefs;
            reminderMinutes2 = reminderMinutes;
            context2 = context;
        }
    }

    public final boolean postSessionReminderNotification(Context context, ClassroomEntity classroom, int reminderMinutes) {
        String body;
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(classroom, "classroom");
        if (!BlePermissionUtils.INSTANCE.hasNotificationPermission(context)) {
            Log.w(TAG, "Cannot post session reminder notification: POST_NOTIFICATIONS permission not granted");
            return false;
        }
        SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
        String todayStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String reminderKey = "session_reminded_" + classroom.getCid() + "_" + todayStr;
        boolean alreadyReminded = prefs.getBoolean(reminderKey, false);
        if (alreadyReminded) {
            return false;
        }
        createNotificationChannel(context);
        if (!StringsKt.isBlank(classroom.getClassroomName()) && !StringsKt.isBlank(classroom.getStartTime())) {
            body = "Class \"" + classroom.getClassroomName() + "\" scheduled at " + classroom.getStartTime() + ". Starts in " + reminderMinutes + " min. Tap to open app and start session.";
        } else {
            body = "Classroom session starts in " + reminderMinutes + " minutes. Tap to open app and start session.";
        }
        Intent intent = new Intent(context, (Class<?>) MainActivity.class);
        intent.setFlags(872415232);
        int notifId = getSessionNotificationId(classroom.getCid());
        PendingIntent pendingIntent = PendingIntent.getActivity(context, notifId, intent, 201326592);
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_chat).setContentTitle("Start Session Reminder").setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 250, 500}).setFullScreenIntent(pendingIntent, true).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent).build();
        Intrinsics.checkNotNullExpressionValue(notification, "build(...)");
        Object systemService = context.getSystemService("notification");
        NotificationManager manager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
        if (manager == null) {
            return false;
        }
        manager.notify(notifId, notification);
        prefs.edit().putBoolean(reminderKey, true).apply();
        Log.i(TAG, "TC Session Reminder notification posted once for cid=" + classroom.getCid() + ": " + body);
        return true;
    }

    public final void cancelSessionReminder(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            Object systemService = context.getSystemService("notification");
            NotificationManager manager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
            if (manager != null) {
                manager.cancel(NOTIF_ID_SESSION_REMINDER);
            }
            Object systemService2 = context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            AlarmManager alarmManager = systemService2 instanceof AlarmManager ? (AlarmManager) systemService2 : null;
            if (alarmManager == null) {
                return;
            }
            Intent legacyIntent = new Intent(context, (Class<?>) ReminderAlarmReceiver.class);
            legacyIntent.setAction(ReminderAlarmReceiver.ACTION_TC_SESSION_REMINDER);
            PendingIntent legacyPending = PendingIntent.getBroadcast(context, REQ_CODE_TC_ALARM, legacyIntent, 603979776);
            if (legacyPending != null) {
                alarmManager.cancel(legacyPending);
                legacyPending.cancel();
            }
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new AnonymousClass1(context, manager, null), 3, null);
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel session reminder", e);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$cancelSessionReminder$1, reason: invalid class name */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$cancelSessionReminder$1", f = "ReminderNotificationHelper.kt", i = {0}, l = {653}, m = "invokeSuspend", n = {"db"}, s = {"L$0"})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        final /* synthetic */ NotificationManager $manager;
        Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Context context, NotificationManager notificationManager, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$context = context;
            this.$manager = notificationManager;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass1(this.$context, this.$manager, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object allClassroomsSync;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        CalisDatabase db = CalisDatabase.INSTANCE.getDatabase(this.$context);
                        this.L$0 = SpillingKt.nullOutSpilledVariable(db);
                        this.label = 1;
                        allClassroomsSync = db.classroomDao().getAllClassroomsSync(this);
                        if (allClassroomsSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        allClassroomsSync = $result;
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                List<ClassroomEntity> classrooms = (List) allClassroomsSync;
                for (ClassroomEntity c : classrooms) {
                    ReminderNotificationHelper.INSTANCE.cancelSessionAlarm(this.$context, c);
                    NotificationManager notificationManager = this.$manager;
                    if (notificationManager != null) {
                        notificationManager.cancel(ReminderNotificationHelper.INSTANCE.getSessionNotificationId(c.getCid()));
                    }
                }
            } catch (Exception e) {
                Log.e(ReminderNotificationHelper.TAG, "Failed to cancel all classroom alarms", e);
            }
            return Unit.INSTANCE;
        }
    }

    public final void checkAndPostTaskDeadlineReminder(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
        boolean isEnabled = prefs.getBoolean("remind_task_deadline", false);
        if (isEnabled) {
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C08161(context, prefs, null), 3, null);
        } else {
            cancelTaskDeadlineReminder(context);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$checkAndPostTaskDeadlineReminder$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$checkAndPostTaskDeadlineReminder$1", f = "ReminderNotificationHelper.kt", i = {0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, l = {678, 681, 697}, m = "invokeSuspend", n = {"db", "db", "studentProfile", "studentId", "db", "studentProfile", "studentId", "allTasks", "upcomingTasks", "pendingTasks", "task", "now", "days", "hour", "minute"}, s = {"L$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$7", "J$0", "I$0", "I$1", "I$2"})
    static final class C08161 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        final /* synthetic */ SharedPreferences $prefs;
        int I$0;
        int I$1;
        int I$2;
        long J$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08161(Context context, SharedPreferences sharedPreferences, Continuation<? super C08161> continuation) {
            super(2, continuation);
            this.$context = context;
            this.$prefs = sharedPreferences;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C08161(this.$context, this.$prefs, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08161) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:137:0x01e6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:49:0x0164 A[Catch: Exception -> 0x05c2, TryCatch #5 {Exception -> 0x05c2, blocks: (B:47:0x015a, B:49:0x0164, B:51:0x0176, B:67:0x01fc, B:69:0x0202, B:71:0x020c, B:72:0x021e, B:74:0x0224, B:76:0x0269, B:82:0x027c, B:85:0x0292, B:77:0x026f, B:87:0x02ad, B:89:0x02d1, B:90:0x02d5, B:91:0x02db, B:93:0x02e1, B:96:0x0320, B:98:0x032c, B:100:0x0365, B:105:0x03a6, B:108:0x04cf, B:110:0x04f9, B:111:0x04fc, B:103:0x037f, B:104:0x0393, B:115:0x0558, B:117:0x056d, B:119:0x057b, B:120:0x058c, B:122:0x0592, B:125:0x05a9, B:126:0x05b9, B:127:0x05be), top: B:145:0x015a }] */
        /* JADX WARN: Code duplicated, block: B:51:0x0176 A[Catch: Exception -> 0x05c2, TRY_LEAVE, TryCatch #5 {Exception -> 0x05c2, blocks: (B:47:0x015a, B:49:0x0164, B:51:0x0176, B:67:0x01fc, B:69:0x0202, B:71:0x020c, B:72:0x021e, B:74:0x0224, B:76:0x0269, B:82:0x027c, B:85:0x0292, B:77:0x026f, B:87:0x02ad, B:89:0x02d1, B:90:0x02d5, B:91:0x02db, B:93:0x02e1, B:96:0x0320, B:98:0x032c, B:100:0x0365, B:105:0x03a6, B:108:0x04cf, B:110:0x04f9, B:111:0x04fc, B:103:0x037f, B:104:0x0393, B:115:0x0558, B:117:0x056d, B:119:0x057b, B:120:0x058c, B:122:0x0592, B:125:0x05a9, B:126:0x05b9, B:127:0x05be), top: B:145:0x015a }] */
        /* JADX WARN: Code duplicated, block: B:53:0x01b8 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:54:0x01b9  */
        /* JADX WARN: Code duplicated, block: B:59:0x01d9  */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:54:0x01b9 -> B:141:0x01c8). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:59:0x01d9 -> B:60:0x01e4). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r49) {
            /*
                Method dump skipped, instruction units count: 1530
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.util.ReminderNotificationHelper.C08161.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final long invokeSuspend$toMillis(long timestamp) {
            return timestamp > 100000000000L ? timestamp : 1000 * timestamp;
        }
    }

    public final void cancelTaskNotification(Context context, String tkid) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(tkid, "tkid");
        try {
            Object systemService = context.getSystemService("notification");
            NotificationManager manager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
            if (manager != null) {
                manager.cancel(getTaskNotificationId(tkid));
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel notification for task " + tkid, e);
        }
    }

    public final void cancelTaskDeadlineReminder(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        try {
            Object systemService = context.getSystemService("notification");
            NotificationManager manager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
            if (manager != null) {
                manager.cancel(NOTIF_ID_TASK_DEADLINE);
            }
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C08131(context, manager, null), 3, null);
            cancelAlarm(context, ReminderAlarmReceiver.ACTION_ST_TASK_REMINDER, REQ_CODE_ST_ALARM);
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel task deadline reminder", e);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$cancelTaskDeadlineReminder$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$cancelTaskDeadlineReminder$1", f = "ReminderNotificationHelper.kt", i = {0}, l = {837}, m = "invokeSuspend", n = {"db"}, s = {"L$0"})
    static final class C08131 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        final /* synthetic */ NotificationManager $manager;
        Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08131(Context context, NotificationManager notificationManager, Continuation<? super C08131> continuation) {
            super(2, continuation);
            this.$context = context;
            this.$manager = notificationManager;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C08131(this.$context, this.$manager, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08131) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object allTasksSync;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        CalisDatabase db = CalisDatabase.INSTANCE.getDatabase(this.$context);
                        this.L$0 = SpillingKt.nullOutSpilledVariable(db);
                        this.label = 1;
                        allTasksSync = db.taskDao().getAllTasksSync(this);
                        if (allTasksSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        allTasksSync = $result;
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                List<TaskEntity> tasks = (List) allTasksSync;
                for (TaskEntity t : tasks) {
                    NotificationManager notificationManager = this.$manager;
                    if (notificationManager != null) {
                        notificationManager.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId(t.getTkid()));
                    }
                }
            } catch (Exception e) {
                Log.e(ReminderNotificationHelper.TAG, "Failed to cancel individual task notifications", e);
            }
            return Unit.INSTANCE;
        }
    }

    public final void checkAndPostCheckInReminder(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
        boolean isEnabled = prefs.getBoolean("remind_check_in", false);
        if (isEnabled) {
            BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C08141(context, prefs, null), 3, null);
        }
    }

    /* JADX INFO: renamed from: com.example.util.ReminderNotificationHelper$checkAndPostCheckInReminder$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ReminderNotificationHelper.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.util.ReminderNotificationHelper$checkAndPostCheckInReminder$1", f = "ReminderNotificationHelper.kt", i = {0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, l = {859, 861, 862, 879}, m = "invokeSuspend", n = {"db", "db", "studentProfile", "studentId", "db", "studentProfile", "studentId", "db", "studentProfile", "studentId", "classroom", "todayCal", "todayDateStr", "todayDateStrMdy", "now", "startMins", "graceMins"}, s = {"L$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "J$0", "I$0", "I$1"})
    static final class C08141 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        final /* synthetic */ SharedPreferences $prefs;
        int I$0;
        int I$1;
        long J$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08141(Context context, SharedPreferences sharedPreferences, Continuation<? super C08141> continuation) {
            super(2, continuation);
            this.$context = context;
            this.$prefs = sharedPreferences;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C08141(this.$context, this.$prefs, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08141) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:103:0x0293  */
        /* JADX WARN: Code duplicated, block: B:106:0x02a0 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:107:0x02a4  */
        /* JADX WARN: Code duplicated, block: B:109:0x02a7 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:111:0x02c7 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:112:0x02c9 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:117:0x035f A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:119:0x038f  */
        /* JADX WARN: Code duplicated, block: B:121:0x0399 A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:123:0x039c A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:125:0x03c1 A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:126:0x03c4  */
        /* JADX WARN: Code duplicated, block: B:128:0x03c7 A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:130:0x03ca A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:132:0x03ce A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:134:0x03f4 A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:138:0x0502 A[ADDED_TO_REGION, REMOVE] */
        /* JADX WARN: Code duplicated, block: B:139:0x0507  */
        /* JADX WARN: Code duplicated, block: B:141:0x050d A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:143:0x0533 A[Catch: Exception -> 0x062f, TryCatch #0 {Exception -> 0x062f, blocks: (B:115:0x0359, B:117:0x035f, B:121:0x0399, B:123:0x039c, B:125:0x03c1, B:128:0x03c7, B:130:0x03ca, B:132:0x03ce, B:134:0x03f4, B:136:0x03fe, B:141:0x050d, B:143:0x0533, B:145:0x053d), top: B:156:0x0250 }] */
        /* JADX WARN: Code duplicated, block: B:168:0x023c A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:169:0x0233 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:28:0x00af  */
        /* JADX WARN: Code duplicated, block: B:31:0x00ca A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:32:0x00cb  */
        /* JADX WARN: Code duplicated, block: B:35:0x00d4 A[Catch: Exception -> 0x0635, TryCatch #3 {Exception -> 0x0635, blocks: (B:12:0x0064, B:38:0x00ee, B:40:0x00f2, B:42:0x00f5, B:44:0x0128, B:46:0x0137, B:48:0x013a, B:15:0x0077, B:33:0x00d0, B:35:0x00d4, B:18:0x0081, B:24:0x00a5, B:26:0x00a9, B:29:0x00b1, B:21:0x008b), top: B:161:0x000f }] */
        /* JADX WARN: Code duplicated, block: B:37:0x00ed A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:40:0x00f2 A[Catch: Exception -> 0x0635, TryCatch #3 {Exception -> 0x0635, blocks: (B:12:0x0064, B:38:0x00ee, B:40:0x00f2, B:42:0x00f5, B:44:0x0128, B:46:0x0137, B:48:0x013a, B:15:0x0077, B:33:0x00d0, B:35:0x00d4, B:18:0x0081, B:24:0x00a5, B:26:0x00a9, B:29:0x00b1, B:21:0x008b), top: B:161:0x000f }] */
        /* JADX WARN: Code duplicated, block: B:42:0x00f5 A[Catch: Exception -> 0x0635, PHI: r2 r9 r10 r11
          0x00f5: PHI (r2v11 'studentId' java.lang.String) = (r2v8 'studentId' java.lang.String), (r2v14 'studentId' java.lang.String) binds: [B:34:0x00d2, B:39:0x00f0] A[DONT_GENERATE, DONT_INLINE]
          0x00f5: PHI (r9v9 'studentProfile' com.example.data.db.StudentProfileEntity) = 
          (r9v6 'studentProfile' com.example.data.db.StudentProfileEntity)
          (r9v22 'studentProfile' com.example.data.db.StudentProfileEntity)
         binds: [B:34:0x00d2, B:39:0x00f0] A[DONT_GENERATE, DONT_INLINE]
          0x00f5: PHI (r10v9 'db' com.example.data.db.CalisDatabase) = (r10v6 'db' com.example.data.db.CalisDatabase), (r10v11 'db' com.example.data.db.CalisDatabase) binds: [B:34:0x00d2, B:39:0x00f0] A[DONT_GENERATE, DONT_INLINE]
          0x00f5: PHI (r11v7 com.example.data.db.ClassroomEntity) = (r11v3 com.example.data.db.ClassroomEntity), (r11v9 com.example.data.db.ClassroomEntity) binds: [B:34:0x00d2, B:39:0x00f0] A[DONT_GENERATE, DONT_INLINE], TryCatch #3 {Exception -> 0x0635, blocks: (B:12:0x0064, B:38:0x00ee, B:40:0x00f2, B:42:0x00f5, B:44:0x0128, B:46:0x0137, B:48:0x013a, B:15:0x0077, B:33:0x00d0, B:35:0x00d4, B:18:0x0081, B:24:0x00a5, B:26:0x00a9, B:29:0x00b1, B:21:0x008b), top: B:161:0x000f }] */
        /* JADX WARN: Code duplicated, block: B:44:0x0128 A[Catch: Exception -> 0x0635, TryCatch #3 {Exception -> 0x0635, blocks: (B:12:0x0064, B:38:0x00ee, B:40:0x00f2, B:42:0x00f5, B:44:0x0128, B:46:0x0137, B:48:0x013a, B:15:0x0077, B:33:0x00d0, B:35:0x00d4, B:18:0x0081, B:24:0x00a5, B:26:0x00a9, B:29:0x00b1, B:21:0x008b), top: B:161:0x000f }] */
        /* JADX WARN: Code duplicated, block: B:46:0x0137 A[Catch: Exception -> 0x0635, TryCatch #3 {Exception -> 0x0635, blocks: (B:12:0x0064, B:38:0x00ee, B:40:0x00f2, B:42:0x00f5, B:44:0x0128, B:46:0x0137, B:48:0x013a, B:15:0x0077, B:33:0x00d0, B:35:0x00d4, B:18:0x0081, B:24:0x00a5, B:26:0x00a9, B:29:0x00b1, B:21:0x008b), top: B:161:0x000f }] */
        /* JADX WARN: Code duplicated, block: B:52:0x0166  */
        /* JADX WARN: Code duplicated, block: B:58:0x019d A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:59:0x019e  */
        /* JADX WARN: Code duplicated, block: B:73:0x01c0 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:75:0x01f0 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:77:0x0202 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:79:0x020f A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:82:0x0216  */
        /* JADX WARN: Code duplicated, block: B:85:0x0223 A[Catch: Exception -> 0x0631, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:88:0x022e A[PHI: r19
          0x022e: PHI (r19v5 java.util.Iterator) = (r19v3 java.util.Iterator), (r19v6 java.util.Iterator) binds: [B:86:0x022b, B:80:0x0213] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Code duplicated, block: B:92:0x0234 A[LOOP:0: B:71:0x01b8->B:92:0x0234, LOOP_END] */
        /* JADX WARN: Code duplicated, block: B:97:0x0252 A[Catch: Exception -> 0x0631, TRY_ENTER, TryCatch #5 {Exception -> 0x0631, blocks: (B:70:0x01b0, B:71:0x01b8, B:73:0x01c0, B:75:0x01f0, B:77:0x0202, B:79:0x020f, B:94:0x0240, B:97:0x0252, B:104:0x0295, B:106:0x02a0, B:109:0x02a7, B:112:0x02c9, B:113:0x02e7, B:83:0x021a, B:85:0x0223, B:69:0x01ac), top: B:164:0x01ac }] */
        /* JADX WARN: Code duplicated, block: B:99:0x028b A[ADDED_TO_REGION] */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r6v1 */
        /* JADX WARN: Type inference failed for: r6v12 */
        /* JADX WARN: Type inference failed for: r6v16, types: [com.example.data.db.AttendanceEntity] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String str;
            CalisDatabase db;
            Object studentProfileOnce;
            StudentProfileEntity studentProfile;
            String studentId;
            Object activeBoundClassroomSync;
            CalisDatabase db2;
            String studentId2;
            ClassroomEntity classroomEntity;
            Object anyClassroomSync;
            ClassroomEntity classroom;
            long now;
            Calendar todayCal;
            String todayDateStr;
            String todayDateStrMdy;
            int startMins;
            int graceMins;
            String str2;
            String studentId3;
            int graceMins2;
            Object attendanceForClassroomSync;
            ScheduleUtils scheduleUtils;
            List attendanceList;
            Iterator it;
            Object next;
            int startMins2;
            String str3;
            int currentMinutes;
            int remindMinutes;
            Object systemService;
            NotificationManager notifManager;
            String lateKey;
            String remindKey;
            int checkInMinutes;
            boolean isCheckedInBeforeGrace;
            Object systemService2;
            NotificationManager notifManager2;
            AttendanceEntity attendanceEntity;
            String str4;
            List attendanceList2;
            Iterator it2;
            boolean z;
            String date;
            String date2;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            String str5 = "yyyy-MM-dd";
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        db = CalisDatabase.INSTANCE.getDatabase(this.$context);
                        this.L$0 = db;
                        this.label = 1;
                        studentProfileOnce = db.studentProfileDao().getStudentProfileOnce(this);
                        if (studentProfileOnce == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        studentProfile = (StudentProfileEntity) studentProfileOnce;
                        if (studentProfile != null || (studentId = studentProfile.getSid()) == null) {
                            studentId = "";
                        }
                        this.L$0 = db;
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile);
                        this.L$2 = studentId;
                        this.label = 2;
                        activeBoundClassroomSync = db.classroomDao().getActiveBoundClassroomSync(this);
                        if (activeBoundClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        String str6 = studentId;
                        db2 = db;
                        studentId2 = str6;
                        classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                        try {
                            try {
                                if (classroomEntity != null) {
                                    StudentProfileEntity studentProfile2 = studentProfile;
                                    CalisDatabase db3 = db2;
                                    classroom = classroomEntity;
                                    now = System.currentTimeMillis();
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.setTimeInMillis(now);
                                    todayCal = calendar;
                                    todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                                    if (!StringsKt.isBlank(classroom.getDays())) {
                                        scheduleUtils = ScheduleUtils.INSTANCE;
                                        Intrinsics.checkNotNull(todayCal);
                                        if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                            return Unit.INSTANCE;
                                        }
                                    }
                                    todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                                    startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                                    graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                                    if (graceMins < 0) {
                                        graceMins = startMins + 15;
                                    }
                                    AttendanceDao attendanceDao = db3.attendanceDao();
                                    String cid = classroom.getCid();
                                    C08141 c08141 = this;
                                    str2 = ReminderNotificationHelper.TAG;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(db3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile2);
                                    this.L$2 = studentId2;
                                    this.L$3 = classroom;
                                    this.L$4 = todayCal;
                                    this.L$5 = todayDateStr;
                                    this.L$6 = todayDateStrMdy;
                                    this.J$0 = now;
                                    this.I$0 = startMins;
                                    this.I$1 = graceMins;
                                    this.label = 4;
                                    attendanceForClassroomSync = attendanceDao.getAttendanceForClassroomSync(cid, c08141);
                                    if (attendanceForClassroomSync == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    studentId3 = studentId2;
                                    graceMins2 = graceMins;
                                    attendanceList = (List) attendanceForClassroomSync;
                                    it = attendanceList.iterator();
                                    while (true) {
                                        if (it.hasNext()) {
                                            next = it.next();
                                            attendanceEntity = (AttendanceEntity) next;
                                            str4 = str5;
                                            attendanceList2 = attendanceList;
                                            String str7 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                            if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                it2 = it;
                                            } else {
                                                date = attendanceEntity.getDate();
                                                Intrinsics.checkNotNull(todayDateStr);
                                                it2 = it;
                                                if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                                    date2 = attendanceEntity.getDate();
                                                    Intrinsics.checkNotNull(todayDateStrMdy);
                                                    if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                                    }
                                                }
                                                if (z) {
                                                    it = it2;
                                                    str5 = str4;
                                                    attendanceList = attendanceList2;
                                                }
                                            }
                                            if (StringsKt.isBlank(studentId3)) {
                                            }
                                            z = true;
                                            if (z) {
                                                it = it2;
                                                str5 = str4;
                                                attendanceList = attendanceList2;
                                            }
                                        } else {
                                            next = null;
                                        }
                                    }
                                    str = (AttendanceEntity) next;
                                    if (str != 0) {
                                        Calendar calendar2 = Calendar.getInstance();
                                        calendar2.setTimeInMillis(str.getTimestamp() * 1000);
                                        checkInMinutes = (calendar2.get(11) * 60) + calendar2.get(12);
                                        if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                            isCheckedInBeforeGrace = true;
                                        } else {
                                            isCheckedInBeforeGrace = true;
                                        }
                                        systemService2 = this.$context.getSystemService("notification");
                                        if (systemService2 instanceof NotificationManager) {
                                            notifManager2 = (NotificationManager) systemService2;
                                        } else {
                                            notifManager2 = null;
                                        }
                                        if (notifManager2 != null) {
                                            notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                                        }
                                        if (!isCheckedInBeforeGrace) {
                                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                            return Unit.INSTANCE;
                                        }
                                        if (notifManager2 != null) {
                                            notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                                        }
                                        this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                        Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                                        return Unit.INSTANCE;
                                    }
                                    startMins2 = startMins;
                                    str3 = str2;
                                    if (startMins2 < 0) {
                                        return Unit.INSTANCE;
                                    }
                                    currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                                    remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                                    systemService = this.$context.getSystemService("notification");
                                    if (systemService instanceof NotificationManager) {
                                        notifManager = (NotificationManager) systemService;
                                    } else {
                                        notifManager = null;
                                    }
                                    if (notifManager == null) {
                                        return Unit.INSTANCE;
                                    }
                                    if (currentMinutes >= startMins2 + remindMinutes) {
                                        remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                        if (this.$prefs.getBoolean(remindKey, false)) {
                                        }
                                    }
                                    if (currentMinutes >= graceMins2) {
                                        lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                        if (!this.$prefs.getBoolean(lateKey, false)) {
                                            ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                            String body = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                            Intent intent = new Intent(this.$context, (Class<?>) MainActivity.class);
                                            intent.setFlags(872415232);
                                            int notifId = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                            PendingIntent pendingIntent = PendingIntent.getActivity(this.$context, notifId, intent, 201326592);
                                            Notification notification = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent).build();
                                            Intrinsics.checkNotNullExpressionValue(notification, "build(...)");
                                            notifManager.notify(notifId, notification);
                                            this.$prefs.edit().putBoolean(lateKey, true).apply();
                                            Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                                        }
                                    }
                                    return Unit.INSTANCE;
                                }
                                this.L$0 = db2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile);
                                this.L$2 = studentId2;
                                this.label = 3;
                                anyClassroomSync = db2.classroomDao().getAnyClassroomSync(this);
                                if (anyClassroomSync == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                classroomEntity = (ClassroomEntity) anyClassroomSync;
                                if (classroomEntity == null) {
                                    return Unit.INSTANCE;
                                }
                                StudentProfileEntity studentProfile3 = studentProfile;
                                CalisDatabase db4 = db2;
                                classroom = classroomEntity;
                                now = System.currentTimeMillis();
                                Calendar calendar3 = Calendar.getInstance();
                                calendar3.setTimeInMillis(now);
                                todayCal = calendar3;
                                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                                if (!StringsKt.isBlank(classroom.getDays())) {
                                    scheduleUtils = ScheduleUtils.INSTANCE;
                                    Intrinsics.checkNotNull(todayCal);
                                    if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                        return Unit.INSTANCE;
                                    }
                                }
                                todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                                startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                                graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                                if (graceMins < 0) {
                                    graceMins = startMins + 15;
                                }
                                try {
                                    AttendanceDao attendanceDao2 = db4.attendanceDao();
                                    String cid2 = classroom.getCid();
                                    C08141 c08142 = this;
                                    str2 = ReminderNotificationHelper.TAG;
                                    try {
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(db4);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile3);
                                        this.L$2 = studentId2;
                                        this.L$3 = classroom;
                                        this.L$4 = todayCal;
                                        this.L$5 = todayDateStr;
                                        this.L$6 = todayDateStrMdy;
                                        this.J$0 = now;
                                        this.I$0 = startMins;
                                        this.I$1 = graceMins;
                                        this.label = 4;
                                        attendanceForClassroomSync = attendanceDao2.getAttendanceForClassroomSync(cid2, c08142);
                                        if (attendanceForClassroomSync == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        studentId3 = studentId2;
                                        graceMins2 = graceMins;
                                        try {
                                            attendanceList = (List) attendanceForClassroomSync;
                                            while (true) {
                                                if (it.hasNext()) {
                                                    next = it.next();
                                                    attendanceEntity = (AttendanceEntity) next;
                                                    str4 = str5;
                                                    attendanceList2 = attendanceList;
                                                    String str8 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                        date = attendanceEntity.getDate();
                                                        Intrinsics.checkNotNull(todayDateStr);
                                                        it2 = it;
                                                        if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                                            date2 = attendanceEntity.getDate();
                                                            Intrinsics.checkNotNull(todayDateStrMdy);
                                                            if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null) && !Intrinsics.areEqual(str8, todayDateStr)) {
                                                                z = false;
                                                            }
                                                        }
                                                        if (z) {
                                                            it = it2;
                                                            str5 = str4;
                                                            attendanceList = attendanceList2;
                                                        }
                                                    } else {
                                                        it2 = it;
                                                    }
                                                    if (!StringsKt.isBlank(studentId3) || Intrinsics.areEqual(attendanceEntity.getStudentId(), studentId3)) {
                                                        z = true;
                                                    } else {
                                                        z = false;
                                                    }
                                                    if (z) {
                                                        it = it2;
                                                        str5 = str4;
                                                        attendanceList = attendanceList2;
                                                    }
                                                } else {
                                                    next = null;
                                                }
                                            }
                                        } catch (Exception e) {
                                            attendanceList = CollectionsKt.emptyList();
                                        }
                                        it = attendanceList.iterator();
                                        str = (AttendanceEntity) next;
                                        if (str != 0) {
                                            Calendar calendar4 = Calendar.getInstance();
                                            calendar4.setTimeInMillis(str.getTimestamp() * 1000);
                                            checkInMinutes = (calendar4.get(11) * 60) + calendar4.get(12);
                                            if (StringsKt.equals(str.getStatus(), "PRESENT", true) || (graceMins2 >= 0 && checkInMinutes <= graceMins2)) {
                                                isCheckedInBeforeGrace = true;
                                            } else {
                                                isCheckedInBeforeGrace = false;
                                            }
                                            systemService2 = this.$context.getSystemService("notification");
                                            if (systemService2 instanceof NotificationManager) {
                                                notifManager2 = (NotificationManager) systemService2;
                                            } else {
                                                notifManager2 = null;
                                            }
                                            if (notifManager2 != null) {
                                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                                            }
                                            if (!isCheckedInBeforeGrace) {
                                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                                return Unit.INSTANCE;
                                            }
                                            if (notifManager2 != null) {
                                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                                            }
                                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                                            return Unit.INSTANCE;
                                        }
                                        startMins2 = startMins;
                                        str3 = str2;
                                        if (startMins2 < 0) {
                                            return Unit.INSTANCE;
                                        }
                                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                                        systemService = this.$context.getSystemService("notification");
                                        if (systemService instanceof NotificationManager) {
                                            notifManager = (NotificationManager) systemService;
                                        } else {
                                            notifManager = null;
                                        }
                                        if (notifManager == null) {
                                            return Unit.INSTANCE;
                                        }
                                        if (currentMinutes >= startMins2 + remindMinutes) {
                                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                            if (this.$prefs.getBoolean(remindKey, false) && BlePermissionUtils.INSTANCE.hasNotificationPermission(this.$context)) {
                                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                                String body2 = "Class \"" + classroom.getClassroomName() + "\" scheduled at " + classroom.getStartTime() + ". You haven't checked in yet. Tap to open app and check in.";
                                                Intent intent2 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                                intent2.setFlags(872415232);
                                                int notifId2 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid());
                                                PendingIntent pendingIntent2 = PendingIntent.getActivity(this.$context, notifId2, intent2, 201326592);
                                                Notification notification2 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_chat).setContentTitle("Check-In Reminder").setContentText(body2).setStyle(new NotificationCompat.BigTextStyle().bigText(body2)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 250, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent2).build();
                                                Intrinsics.checkNotNullExpressionValue(notification2, "build(...)");
                                                notifManager.notify(notifId2, notification2);
                                                this.$prefs.edit().putBoolean(remindKey, true).apply();
                                                Log.d(str3, "Check-in reminder posted for classroom " + classroom.getCid());
                                            }
                                        }
                                        if (currentMinutes >= graceMins2) {
                                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                            if (!this.$prefs.getBoolean(lateKey, false) && BlePermissionUtils.INSTANCE.hasNotificationPermission(this.$context)) {
                                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                                String body3 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                                Intent intent3 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                                intent3.setFlags(872415232);
                                                int notifId3 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                                PendingIntent pendingIntent3 = PendingIntent.getActivity(this.$context, notifId3, intent3, 201326592);
                                                Notification notification3 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body3).setStyle(new NotificationCompat.BigTextStyle().bigText(body3)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent3).build();
                                                Intrinsics.checkNotNullExpressionValue(notification3, "build(...)");
                                                notifManager.notify(notifId3, notification3);
                                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                                            }
                                        }
                                        return Unit.INSTANCE;
                                    } catch (Exception e2) {
                                        studentId3 = studentId2;
                                        graceMins2 = graceMins;
                                    }
                                } catch (Exception e3) {
                                    str2 = ReminderNotificationHelper.TAG;
                                }
                                if (str != 0) {
                                    Calendar calendar5 = Calendar.getInstance();
                                    calendar5.setTimeInMillis(str.getTimestamp() * 1000);
                                    checkInMinutes = (calendar5.get(11) * 60) + calendar5.get(12);
                                    if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                        isCheckedInBeforeGrace = true;
                                    } else {
                                        isCheckedInBeforeGrace = true;
                                    }
                                    systemService2 = this.$context.getSystemService("notification");
                                    if (systemService2 instanceof NotificationManager) {
                                        notifManager2 = (NotificationManager) systemService2;
                                    } else {
                                        notifManager2 = null;
                                    }
                                    if (notifManager2 != null) {
                                        notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                                    }
                                    if (!isCheckedInBeforeGrace) {
                                        this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                        return Unit.INSTANCE;
                                    }
                                    if (notifManager2 != null) {
                                        notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                                    }
                                    this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                    Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                                    return Unit.INSTANCE;
                                }
                                startMins2 = startMins;
                                str3 = str2;
                                if (startMins2 < 0) {
                                    return Unit.INSTANCE;
                                }
                                currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                                remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                                systemService = this.$context.getSystemService("notification");
                                if (systemService instanceof NotificationManager) {
                                    notifManager = (NotificationManager) systemService;
                                } else {
                                    notifManager = null;
                                }
                                if (notifManager == null) {
                                    return Unit.INSTANCE;
                                }
                                if (currentMinutes >= startMins2 + remindMinutes) {
                                    remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                    if (this.$prefs.getBoolean(remindKey, false)) {
                                    }
                                }
                                if (currentMinutes >= graceMins2) {
                                    lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                    if (!this.$prefs.getBoolean(lateKey, false)) {
                                        ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                        String body4 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                        Intent intent4 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                        intent4.setFlags(872415232);
                                        int notifId4 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                        PendingIntent pendingIntent4 = PendingIntent.getActivity(this.$context, notifId4, intent4, 201326592);
                                        Notification notification4 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body4).setStyle(new NotificationCompat.BigTextStyle().bigText(body4)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent4).build();
                                        Intrinsics.checkNotNullExpressionValue(notification4, "build(...)");
                                        notifManager.notify(notifId4, notification4);
                                        this.$prefs.edit().putBoolean(lateKey, true).apply();
                                        Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                                    }
                                }
                                return Unit.INSTANCE;
                            } catch (Exception e4) {
                                e = e4;
                                Log.e(str, "Error in checkAndPostCheckInReminder", e);
                            }
                            attendanceList = CollectionsKt.emptyList();
                            it = attendanceList.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    next = it.next();
                                    attendanceEntity = (AttendanceEntity) next;
                                    str4 = str5;
                                    attendanceList2 = attendanceList;
                                    String str9 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr);
                                        it2 = it;
                                        if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStrMdy);
                                            if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                            }
                                        }
                                        if (z) {
                                            it = it2;
                                            str5 = str4;
                                            attendanceList = attendanceList2;
                                        }
                                    } else {
                                        it2 = it;
                                    }
                                    if (StringsKt.isBlank(studentId3)) {
                                    }
                                    z = true;
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    next = null;
                                }
                            }
                            str = (AttendanceEntity) next;
                        } catch (Exception e5) {
                            e = e5;
                            str = str2;
                            Log.e(str, "Error in checkAndPostCheckInReminder", e);
                            return Unit.INSTANCE;
                        }
                        break;
                    case 1:
                        db = (CalisDatabase) this.L$0;
                        ResultKt.throwOnFailure($result);
                        studentProfileOnce = $result;
                        studentProfile = (StudentProfileEntity) studentProfileOnce;
                        if (studentProfile != null) {
                            studentId = "";
                        } else {
                            studentId = "";
                        }
                        this.L$0 = db;
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile);
                        this.L$2 = studentId;
                        this.label = 2;
                        activeBoundClassroomSync = db.classroomDao().getActiveBoundClassroomSync(this);
                        if (activeBoundClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        String str10 = studentId;
                        db2 = db;
                        studentId2 = str10;
                        classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                        if (classroomEntity != null) {
                            StudentProfileEntity studentProfile4 = studentProfile;
                            CalisDatabase db5 = db2;
                            classroom = classroomEntity;
                            now = System.currentTimeMillis();
                            Calendar calendar6 = Calendar.getInstance();
                            calendar6.setTimeInMillis(now);
                            todayCal = calendar6;
                            todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                            if (!StringsKt.isBlank(classroom.getDays())) {
                                scheduleUtils = ScheduleUtils.INSTANCE;
                                Intrinsics.checkNotNull(todayCal);
                                if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                    return Unit.INSTANCE;
                                }
                            }
                            todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                            startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                            graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                            if (graceMins < 0) {
                                graceMins = startMins + 15;
                            }
                            AttendanceDao attendanceDao3 = db5.attendanceDao();
                            String cid3 = classroom.getCid();
                            C08141 c08143 = this;
                            str2 = ReminderNotificationHelper.TAG;
                            this.L$0 = SpillingKt.nullOutSpilledVariable(db5);
                            this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile4);
                            this.L$2 = studentId2;
                            this.L$3 = classroom;
                            this.L$4 = todayCal;
                            this.L$5 = todayDateStr;
                            this.L$6 = todayDateStrMdy;
                            this.J$0 = now;
                            this.I$0 = startMins;
                            this.I$1 = graceMins;
                            this.label = 4;
                            attendanceForClassroomSync = attendanceDao3.getAttendanceForClassroomSync(cid3, c08143);
                            if (attendanceForClassroomSync == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            studentId3 = studentId2;
                            graceMins2 = graceMins;
                            attendanceList = (List) attendanceForClassroomSync;
                            it = attendanceList.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    next = it.next();
                                    attendanceEntity = (AttendanceEntity) next;
                                    str4 = str5;
                                    attendanceList2 = attendanceList;
                                    String str11 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr);
                                        it2 = it;
                                        if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStrMdy);
                                            if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                            }
                                        }
                                        if (z) {
                                            it = it2;
                                            str5 = str4;
                                            attendanceList = attendanceList2;
                                        }
                                    } else {
                                        it2 = it;
                                    }
                                    if (StringsKt.isBlank(studentId3)) {
                                    }
                                    z = true;
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    next = null;
                                }
                            }
                            str = (AttendanceEntity) next;
                            if (str != 0) {
                                Calendar calendar7 = Calendar.getInstance();
                                calendar7.setTimeInMillis(str.getTimestamp() * 1000);
                                checkInMinutes = (calendar7.get(11) * 60) + calendar7.get(12);
                                if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                    isCheckedInBeforeGrace = true;
                                } else {
                                    isCheckedInBeforeGrace = true;
                                }
                                systemService2 = this.$context.getSystemService("notification");
                                if (systemService2 instanceof NotificationManager) {
                                    notifManager2 = (NotificationManager) systemService2;
                                } else {
                                    notifManager2 = null;
                                }
                                if (notifManager2 != null) {
                                    notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                                }
                                if (!isCheckedInBeforeGrace) {
                                    this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                    return Unit.INSTANCE;
                                }
                                if (notifManager2 != null) {
                                    notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                                }
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                                return Unit.INSTANCE;
                            }
                            startMins2 = startMins;
                            str3 = str2;
                            if (startMins2 < 0) {
                                return Unit.INSTANCE;
                            }
                            currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                            remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                            systemService = this.$context.getSystemService("notification");
                            if (systemService instanceof NotificationManager) {
                                notifManager = (NotificationManager) systemService;
                            } else {
                                notifManager = null;
                            }
                            if (notifManager == null) {
                                return Unit.INSTANCE;
                            }
                            if (currentMinutes >= startMins2 + remindMinutes) {
                                remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                if (this.$prefs.getBoolean(remindKey, false)) {
                                }
                            }
                            if (currentMinutes >= graceMins2) {
                                lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                if (!this.$prefs.getBoolean(lateKey, false)) {
                                    ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                    String body5 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                    Intent intent5 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                    intent5.setFlags(872415232);
                                    int notifId5 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                    PendingIntent pendingIntent5 = PendingIntent.getActivity(this.$context, notifId5, intent5, 201326592);
                                    Notification notification5 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body5).setStyle(new NotificationCompat.BigTextStyle().bigText(body5)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent5).build();
                                    Intrinsics.checkNotNullExpressionValue(notification5, "build(...)");
                                    notifManager.notify(notifId5, notification5);
                                    this.$prefs.edit().putBoolean(lateKey, true).apply();
                                    Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                                }
                            }
                            return Unit.INSTANCE;
                        }
                        this.L$0 = db2;
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile);
                        this.L$2 = studentId2;
                        this.label = 3;
                        anyClassroomSync = db2.classroomDao().getAnyClassroomSync(this);
                        if (anyClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        classroomEntity = (ClassroomEntity) anyClassroomSync;
                        if (classroomEntity == null) {
                            return Unit.INSTANCE;
                        }
                        StudentProfileEntity studentProfile5 = studentProfile;
                        CalisDatabase db6 = db2;
                        classroom = classroomEntity;
                        now = System.currentTimeMillis();
                        Calendar calendar8 = Calendar.getInstance();
                        calendar8.setTimeInMillis(now);
                        todayCal = calendar8;
                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                        if (!StringsKt.isBlank(classroom.getDays())) {
                            scheduleUtils = ScheduleUtils.INSTANCE;
                            Intrinsics.checkNotNull(todayCal);
                            if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                return Unit.INSTANCE;
                            }
                        }
                        todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                        startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                        graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                        if (graceMins < 0) {
                            graceMins = startMins + 15;
                        }
                        AttendanceDao attendanceDao4 = db6.attendanceDao();
                        String cid4 = classroom.getCid();
                        C08141 c08144 = this;
                        str2 = ReminderNotificationHelper.TAG;
                        this.L$0 = SpillingKt.nullOutSpilledVariable(db6);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile5);
                        this.L$2 = studentId2;
                        this.L$3 = classroom;
                        this.L$4 = todayCal;
                        this.L$5 = todayDateStr;
                        this.L$6 = todayDateStrMdy;
                        this.J$0 = now;
                        this.I$0 = startMins;
                        this.I$1 = graceMins;
                        this.label = 4;
                        attendanceForClassroomSync = attendanceDao4.getAttendanceForClassroomSync(cid4, c08144);
                        if (attendanceForClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        studentId3 = studentId2;
                        graceMins2 = graceMins;
                        attendanceList = (List) attendanceForClassroomSync;
                        it = attendanceList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                next = it.next();
                                attendanceEntity = (AttendanceEntity) next;
                                str4 = str5;
                                attendanceList2 = attendanceList;
                                String str12 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStr);
                                    it2 = it;
                                    if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy);
                                        if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                        }
                                    }
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    it2 = it;
                                }
                                if (StringsKt.isBlank(studentId3)) {
                                }
                                z = true;
                                if (z) {
                                    it = it2;
                                    str5 = str4;
                                    attendanceList = attendanceList2;
                                }
                            } else {
                                next = null;
                            }
                        }
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar9 = Calendar.getInstance();
                            calendar9.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar9.get(11) * 60) + calendar9.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body6 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent6 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent6.setFlags(872415232);
                                int notifId6 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent6 = PendingIntent.getActivity(this.$context, notifId6, intent6, 201326592);
                                Notification notification6 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body6).setStyle(new NotificationCompat.BigTextStyle().bigText(body6)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent6).build();
                                Intrinsics.checkNotNullExpressionValue(notification6, "build(...)");
                                notifManager.notify(notifId6, notification6);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                        attendanceList = CollectionsKt.emptyList();
                        it = attendanceList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                next = it.next();
                                attendanceEntity = (AttendanceEntity) next;
                                str4 = str5;
                                attendanceList2 = attendanceList;
                                String str13 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStr);
                                    it2 = it;
                                    if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy);
                                        if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                        }
                                    }
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    it2 = it;
                                }
                                if (StringsKt.isBlank(studentId3)) {
                                }
                                z = true;
                                if (z) {
                                    it = it2;
                                    str5 = str4;
                                    attendanceList = attendanceList2;
                                }
                            } else {
                                next = null;
                            }
                        }
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar10 = Calendar.getInstance();
                            calendar10.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar10.get(11) * 60) + calendar10.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body7 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent7 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent7.setFlags(872415232);
                                int notifId7 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent7 = PendingIntent.getActivity(this.$context, notifId7, intent7, 201326592);
                                Notification notification7 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body7).setStyle(new NotificationCompat.BigTextStyle().bigText(body7)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent7).build();
                                Intrinsics.checkNotNullExpressionValue(notification7, "build(...)");
                                notifManager.notify(notifId7, notification7);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                    case 2:
                        studentId2 = (String) this.L$2;
                        studentProfile = (StudentProfileEntity) this.L$1;
                        db2 = (CalisDatabase) this.L$0;
                        ResultKt.throwOnFailure($result);
                        activeBoundClassroomSync = $result;
                        classroomEntity = (ClassroomEntity) activeBoundClassroomSync;
                        if (classroomEntity != null) {
                            StudentProfileEntity studentProfile6 = studentProfile;
                            CalisDatabase db7 = db2;
                            classroom = classroomEntity;
                            now = System.currentTimeMillis();
                            Calendar calendar11 = Calendar.getInstance();
                            calendar11.setTimeInMillis(now);
                            todayCal = calendar11;
                            todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                            if (!StringsKt.isBlank(classroom.getDays())) {
                                scheduleUtils = ScheduleUtils.INSTANCE;
                                Intrinsics.checkNotNull(todayCal);
                                if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                    return Unit.INSTANCE;
                                }
                            }
                            todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                            startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                            graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                            if (graceMins < 0) {
                                graceMins = startMins + 15;
                            }
                            AttendanceDao attendanceDao5 = db7.attendanceDao();
                            String cid5 = classroom.getCid();
                            C08141 c08145 = this;
                            str2 = ReminderNotificationHelper.TAG;
                            this.L$0 = SpillingKt.nullOutSpilledVariable(db7);
                            this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile6);
                            this.L$2 = studentId2;
                            this.L$3 = classroom;
                            this.L$4 = todayCal;
                            this.L$5 = todayDateStr;
                            this.L$6 = todayDateStrMdy;
                            this.J$0 = now;
                            this.I$0 = startMins;
                            this.I$1 = graceMins;
                            this.label = 4;
                            attendanceForClassroomSync = attendanceDao5.getAttendanceForClassroomSync(cid5, c08145);
                            if (attendanceForClassroomSync == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            studentId3 = studentId2;
                            graceMins2 = graceMins;
                            attendanceList = (List) attendanceForClassroomSync;
                            it = attendanceList.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    next = it.next();
                                    attendanceEntity = (AttendanceEntity) next;
                                    str4 = str5;
                                    attendanceList2 = attendanceList;
                                    String str14 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr);
                                        it2 = it;
                                        if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStrMdy);
                                            if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                            }
                                        }
                                        if (z) {
                                            it = it2;
                                            str5 = str4;
                                            attendanceList = attendanceList2;
                                        }
                                    } else {
                                        it2 = it;
                                    }
                                    if (StringsKt.isBlank(studentId3)) {
                                    }
                                    z = true;
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    next = null;
                                }
                            }
                            str = (AttendanceEntity) next;
                            if (str != 0) {
                                Calendar calendar12 = Calendar.getInstance();
                                calendar12.setTimeInMillis(str.getTimestamp() * 1000);
                                checkInMinutes = (calendar12.get(11) * 60) + calendar12.get(12);
                                if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                    isCheckedInBeforeGrace = true;
                                } else {
                                    isCheckedInBeforeGrace = true;
                                }
                                systemService2 = this.$context.getSystemService("notification");
                                if (systemService2 instanceof NotificationManager) {
                                    notifManager2 = (NotificationManager) systemService2;
                                } else {
                                    notifManager2 = null;
                                }
                                if (notifManager2 != null) {
                                    notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                                }
                                if (!isCheckedInBeforeGrace) {
                                    this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                    return Unit.INSTANCE;
                                }
                                if (notifManager2 != null) {
                                    notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                                }
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                                return Unit.INSTANCE;
                            }
                            startMins2 = startMins;
                            str3 = str2;
                            if (startMins2 < 0) {
                                return Unit.INSTANCE;
                            }
                            currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                            remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                            systemService = this.$context.getSystemService("notification");
                            if (systemService instanceof NotificationManager) {
                                notifManager = (NotificationManager) systemService;
                            } else {
                                notifManager = null;
                            }
                            if (notifManager == null) {
                                return Unit.INSTANCE;
                            }
                            if (currentMinutes >= startMins2 + remindMinutes) {
                                remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                if (this.$prefs.getBoolean(remindKey, false)) {
                                }
                            }
                            if (currentMinutes >= graceMins2) {
                                lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                                if (!this.$prefs.getBoolean(lateKey, false)) {
                                    ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                    String body8 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                    Intent intent8 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                    intent8.setFlags(872415232);
                                    int notifId8 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                    PendingIntent pendingIntent8 = PendingIntent.getActivity(this.$context, notifId8, intent8, 201326592);
                                    Notification notification8 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body8).setStyle(new NotificationCompat.BigTextStyle().bigText(body8)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent8).build();
                                    Intrinsics.checkNotNullExpressionValue(notification8, "build(...)");
                                    notifManager.notify(notifId8, notification8);
                                    this.$prefs.edit().putBoolean(lateKey, true).apply();
                                    Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                                }
                            }
                            return Unit.INSTANCE;
                        }
                        this.L$0 = db2;
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile);
                        this.L$2 = studentId2;
                        this.label = 3;
                        anyClassroomSync = db2.classroomDao().getAnyClassroomSync(this);
                        if (anyClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        classroomEntity = (ClassroomEntity) anyClassroomSync;
                        if (classroomEntity == null) {
                            return Unit.INSTANCE;
                        }
                        StudentProfileEntity studentProfile7 = studentProfile;
                        CalisDatabase db8 = db2;
                        classroom = classroomEntity;
                        now = System.currentTimeMillis();
                        Calendar calendar13 = Calendar.getInstance();
                        calendar13.setTimeInMillis(now);
                        todayCal = calendar13;
                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                        if (!StringsKt.isBlank(classroom.getDays())) {
                            scheduleUtils = ScheduleUtils.INSTANCE;
                            Intrinsics.checkNotNull(todayCal);
                            if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                return Unit.INSTANCE;
                            }
                        }
                        todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                        startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                        graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                        if (graceMins < 0) {
                            graceMins = startMins + 15;
                        }
                        AttendanceDao attendanceDao6 = db8.attendanceDao();
                        String cid6 = classroom.getCid();
                        C08141 c08146 = this;
                        str2 = ReminderNotificationHelper.TAG;
                        this.L$0 = SpillingKt.nullOutSpilledVariable(db8);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile7);
                        this.L$2 = studentId2;
                        this.L$3 = classroom;
                        this.L$4 = todayCal;
                        this.L$5 = todayDateStr;
                        this.L$6 = todayDateStrMdy;
                        this.J$0 = now;
                        this.I$0 = startMins;
                        this.I$1 = graceMins;
                        this.label = 4;
                        attendanceForClassroomSync = attendanceDao6.getAttendanceForClassroomSync(cid6, c08146);
                        if (attendanceForClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        studentId3 = studentId2;
                        graceMins2 = graceMins;
                        attendanceList = (List) attendanceForClassroomSync;
                        it = attendanceList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                next = it.next();
                                attendanceEntity = (AttendanceEntity) next;
                                str4 = str5;
                                attendanceList2 = attendanceList;
                                String str15 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStr);
                                    it2 = it;
                                    if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy);
                                        if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                        }
                                    }
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    it2 = it;
                                }
                                if (StringsKt.isBlank(studentId3)) {
                                }
                                z = true;
                                if (z) {
                                    it = it2;
                                    str5 = str4;
                                    attendanceList = attendanceList2;
                                }
                            } else {
                                next = null;
                            }
                        }
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar14 = Calendar.getInstance();
                            calendar14.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar14.get(11) * 60) + calendar14.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body9 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent9 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent9.setFlags(872415232);
                                int notifId9 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent9 = PendingIntent.getActivity(this.$context, notifId9, intent9, 201326592);
                                Notification notification9 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body9).setStyle(new NotificationCompat.BigTextStyle().bigText(body9)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent9).build();
                                Intrinsics.checkNotNullExpressionValue(notification9, "build(...)");
                                notifManager.notify(notifId9, notification9);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                        attendanceList = CollectionsKt.emptyList();
                        it = attendanceList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                next = it.next();
                                attendanceEntity = (AttendanceEntity) next;
                                str4 = str5;
                                attendanceList2 = attendanceList;
                                String str16 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStr);
                                    it2 = it;
                                    if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy);
                                        if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                        }
                                    }
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    it2 = it;
                                }
                                if (StringsKt.isBlank(studentId3)) {
                                }
                                z = true;
                                if (z) {
                                    it = it2;
                                    str5 = str4;
                                    attendanceList = attendanceList2;
                                }
                            } else {
                                next = null;
                            }
                        }
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar15 = Calendar.getInstance();
                            calendar15.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar15.get(11) * 60) + calendar15.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body10 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent10 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent10.setFlags(872415232);
                                int notifId10 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent10 = PendingIntent.getActivity(this.$context, notifId10, intent10, 201326592);
                                Notification notification10 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body10).setStyle(new NotificationCompat.BigTextStyle().bigText(body10)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent10).build();
                                Intrinsics.checkNotNullExpressionValue(notification10, "build(...)");
                                notifManager.notify(notifId10, notification10);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                    case 3:
                        studentId2 = (String) this.L$2;
                        studentProfile = (StudentProfileEntity) this.L$1;
                        db2 = (CalisDatabase) this.L$0;
                        ResultKt.throwOnFailure($result);
                        anyClassroomSync = $result;
                        classroomEntity = (ClassroomEntity) anyClassroomSync;
                        if (classroomEntity == null) {
                            return Unit.INSTANCE;
                        }
                        StudentProfileEntity studentProfile8 = studentProfile;
                        CalisDatabase db9 = db2;
                        classroom = classroomEntity;
                        now = System.currentTimeMillis();
                        Calendar calendar16 = Calendar.getInstance();
                        calendar16.setTimeInMillis(now);
                        todayCal = calendar16;
                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(now));
                        if (!StringsKt.isBlank(classroom.getDays())) {
                            scheduleUtils = ScheduleUtils.INSTANCE;
                            Intrinsics.checkNotNull(todayCal);
                            if (!scheduleUtils.isDayInSchedule(todayCal, classroom.getDays())) {
                                return Unit.INSTANCE;
                            }
                        }
                        todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(now));
                        startMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getStartTime());
                        graceMins = ReminderNotificationHelper.INSTANCE.parseTimeToMinutes(classroom.getGraceTime());
                        if (graceMins < 0) {
                            graceMins = startMins + 15;
                        }
                        AttendanceDao attendanceDao7 = db9.attendanceDao();
                        String cid7 = classroom.getCid();
                        C08141 c08147 = this;
                        str2 = ReminderNotificationHelper.TAG;
                        this.L$0 = SpillingKt.nullOutSpilledVariable(db9);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(studentProfile8);
                        this.L$2 = studentId2;
                        this.L$3 = classroom;
                        this.L$4 = todayCal;
                        this.L$5 = todayDateStr;
                        this.L$6 = todayDateStrMdy;
                        this.J$0 = now;
                        this.I$0 = startMins;
                        this.I$1 = graceMins;
                        this.label = 4;
                        attendanceForClassroomSync = attendanceDao7.getAttendanceForClassroomSync(cid7, c08147);
                        if (attendanceForClassroomSync == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        studentId3 = studentId2;
                        graceMins2 = graceMins;
                        attendanceList = (List) attendanceForClassroomSync;
                        it = attendanceList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                next = it.next();
                                attendanceEntity = (AttendanceEntity) next;
                                str4 = str5;
                                attendanceList2 = attendanceList;
                                String str17 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStr);
                                    it2 = it;
                                    if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy);
                                        if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                        }
                                    }
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    it2 = it;
                                }
                                if (StringsKt.isBlank(studentId3)) {
                                }
                                z = true;
                                if (z) {
                                    it = it2;
                                    str5 = str4;
                                    attendanceList = attendanceList2;
                                }
                            } else {
                                next = null;
                            }
                        }
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar17 = Calendar.getInstance();
                            calendar17.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar17.get(11) * 60) + calendar17.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body11 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent11 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent11.setFlags(872415232);
                                int notifId11 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent11 = PendingIntent.getActivity(this.$context, notifId11, intent11, 201326592);
                                Notification notification11 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body11).setStyle(new NotificationCompat.BigTextStyle().bigText(body11)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent11).build();
                                Intrinsics.checkNotNullExpressionValue(notification11, "build(...)");
                                notifManager.notify(notifId11, notification11);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                    case 4:
                        graceMins2 = this.I$1;
                        startMins = this.I$0;
                        now = this.J$0;
                        todayDateStrMdy = (String) this.L$6;
                        todayDateStr = (String) this.L$5;
                        todayCal = (Calendar) this.L$4;
                        classroom = (ClassroomEntity) this.L$3;
                        String studentId4 = (String) this.L$2;
                        try {
                            ResultKt.throwOnFailure($result);
                            attendanceForClassroomSync = $result;
                            str2 = ReminderNotificationHelper.TAG;
                            studentId3 = studentId4;
                            attendanceList = (List) attendanceForClassroomSync;
                            while (true) {
                                if (it.hasNext()) {
                                    next = it.next();
                                    attendanceEntity = (AttendanceEntity) next;
                                    str4 = str5;
                                    attendanceList2 = attendanceList;
                                    String str18 = new SimpleDateFormat(str5, Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000));
                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr);
                                        it2 = it;
                                        if (!StringsKt.startsWith$default(date, todayDateStr, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStrMdy);
                                            if (StringsKt.startsWith$default(date2, todayDateStrMdy, false, 2, (Object) null)) {
                                            }
                                        }
                                        if (z) {
                                            it = it2;
                                            str5 = str4;
                                            attendanceList = attendanceList2;
                                        }
                                    } else {
                                        it2 = it;
                                    }
                                    if (StringsKt.isBlank(studentId3)) {
                                    }
                                    z = true;
                                    if (z) {
                                        it = it2;
                                        str5 = str4;
                                        attendanceList = attendanceList2;
                                    }
                                } else {
                                    next = null;
                                }
                            }
                        } catch (Exception e6) {
                            str2 = ReminderNotificationHelper.TAG;
                            studentId3 = studentId4;
                            break;
                        }
                        it = attendanceList.iterator();
                        str = (AttendanceEntity) next;
                        if (str != 0) {
                            Calendar calendar18 = Calendar.getInstance();
                            calendar18.setTimeInMillis(str.getTimestamp() * 1000);
                            checkInMinutes = (calendar18.get(11) * 60) + calendar18.get(12);
                            if (StringsKt.equals(str.getStatus(), "PRESENT", true)) {
                                isCheckedInBeforeGrace = true;
                            } else {
                                isCheckedInBeforeGrace = true;
                            }
                            systemService2 = this.$context.getSystemService("notification");
                            if (systemService2 instanceof NotificationManager) {
                                notifManager2 = (NotificationManager) systemService2;
                            } else {
                                notifManager2 = null;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("check_in_" + classroom.getCid()));
                            }
                            if (!isCheckedInBeforeGrace) {
                                this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                                return Unit.INSTANCE;
                            }
                            if (notifManager2 != null) {
                                notifManager2.cancel(ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid()));
                            }
                            this.$prefs.edit().putBoolean("check_in_reminded_" + classroom.getCid() + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr, true).apply();
                            Log.d(str2, "Student already checked in before grace period (" + checkInMinutes + " <= " + graceMins2 + "). Suppressed late & check-in reminders.");
                            return Unit.INSTANCE;
                        }
                        startMins2 = startMins;
                        str3 = str2;
                        if (startMins2 < 0) {
                            return Unit.INSTANCE;
                        }
                        currentMinutes = (todayCal.get(11) * 60) + todayCal.get(12);
                        remindMinutes = this.$prefs.getInt("remind_check_in_minutes", 15);
                        systemService = this.$context.getSystemService("notification");
                        if (systemService instanceof NotificationManager) {
                            notifManager = (NotificationManager) systemService;
                        } else {
                            notifManager = null;
                        }
                        if (notifManager == null) {
                            return Unit.INSTANCE;
                        }
                        if (currentMinutes >= startMins2 + remindMinutes) {
                            remindKey = "check_in_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (this.$prefs.getBoolean(remindKey, false)) {
                            }
                        }
                        if (currentMinutes >= graceMins2) {
                            lateKey = "late_warn_reminded_" + classroom.getCid() + "_" + todayDateStr;
                            if (!this.$prefs.getBoolean(lateKey, false)) {
                                ReminderNotificationHelper.INSTANCE.createNotificationChannel(this.$context);
                                String body12 = "You missed the grace period for \"" + classroom.getClassroomName() + "\" (grace period was " + classroom.getGraceTime() + "). Please check in immediately!";
                                Intent intent12 = new Intent(this.$context, (Class<?>) MainActivity.class);
                                intent12.setFlags(872415232);
                                int notifId12 = ReminderNotificationHelper.INSTANCE.getTaskNotificationId("late_" + classroom.getCid());
                                PendingIntent pendingIntent12 = PendingIntent.getActivity(this.$context, notifId12, intent12, 201326592);
                                Notification notification12 = new NotificationCompat.Builder(this.$context, ReminderNotificationHelper.CHANNEL_ID).setSmallIcon(R.drawable.stat_notify_error).setContentTitle("Late Attendance Warning").setContentText(body12).setStyle(new NotificationCompat.BigTextStyle().bigText(body12)).setPriority(1).setDefaults(3).setVibrate(new long[]{0, 500, 500, 500}).setAutoCancel(true).setVisibility(1).setContentIntent(pendingIntent12).build();
                                Intrinsics.checkNotNullExpressionValue(notification12, "build(...)");
                                notifManager.notify(notifId12, notification12);
                                this.$prefs.edit().putBoolean(lateKey, true).apply();
                                Log.d(str3, "Late warning reminder posted for classroom " + classroom.getCid());
                            }
                        }
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } catch (Exception e7) {
                e = e7;
                str = ReminderNotificationHelper.TAG;
            }
        }
    }

    public final void cancelCheckInAndLateNotifications(Context context, String classroomId) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(classroomId, "classroomId");
        try {
            Object systemService = context.getSystemService("notification");
            NotificationManager notifManager = systemService instanceof NotificationManager ? (NotificationManager) systemService : null;
            if (notifManager != null) {
                notifManager.cancel(getTaskNotificationId("check_in_" + classroomId));
            }
            if (notifManager != null) {
                notifManager.cancel(getTaskNotificationId("late_" + classroomId));
            }
            String todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            SharedPreferences prefs = context.getSharedPreferences("calis_auth_prefs", 0);
            prefs.edit().putBoolean("check_in_reminded_" + classroomId + "_" + todayDateStr, true).putBoolean("late_warn_reminded_" + classroomId + "_" + todayDateStr, true).apply();
        } catch (Exception e) {
            Log.e(TAG, "Error cancelling check-in and late notifications: " + e.getMessage());
        }
    }
}
