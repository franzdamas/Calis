package com.example.util;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;

/* JADX INFO: compiled from: IdGenerator.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0006\u0010\t\u001a\u00020\u0005J\u0006\u0010\n\u001a\u00020\u0005J\u0006\u0010\u000b\u001a\u00020\u0005J\u0006\u0010\f\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Lcom/example/util/IdGenerator;", "", "<init>", "()V", "HEX_CHARS", "", "generateRandomHex", "length", "", "generateTID", "generateSID", "generateCID", "generateTKID", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class IdGenerator {
    public static final int $stable = 0;
    private static final String HEX_CHARS = "0123456789ABCDEF";
    public static final IdGenerator INSTANCE = new IdGenerator();

    private IdGenerator() {
    }

    private final String generateRandomHex(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(HEX_CHARS.charAt(Random.INSTANCE.nextInt(16)));
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    public final String generateTID() {
        return "TC" + generateRandomHex(5);
    }

    public final String generateSID() {
        return "ST" + generateRandomHex(5);
    }

    public final String generateCID() {
        return "CLS" + generateRandomHex(5);
    }

    public final String generateTKID() {
        return "TK" + generateRandomHex(5);
    }
}
