package com.example.util;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AttendanceLabels.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u000b\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\u0007\"\u0004\b\f\u0010\tR\u001a\u0010\r\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u0007\"\u0004\b\u000f\u0010\t¨\u0006\u0010"}, d2 = {"Lcom/example/util/AttendanceLabels;", "", "<init>", "()V", "present", "", "getPresent", "()Ljava/lang/String;", "setPresent", "(Ljava/lang/String;)V", "absent", "getAbsent", "setAbsent", "late", "getLate", "setLate", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AttendanceLabels {
    public static final AttendanceLabels INSTANCE = new AttendanceLabels();
    private static String present = "Present";
    private static String absent = "Absent";
    private static String late = "Late";
    public static final int $stable = 8;

    private AttendanceLabels() {
    }

    public final String getPresent() {
        return present;
    }

    public final void setPresent(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        present = str;
    }

    public final String getAbsent() {
        return absent;
    }

    public final void setAbsent(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        absent = str;
    }

    public final String getLate() {
        return late;
    }

    public final void setLate(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        late = str;
    }
}
