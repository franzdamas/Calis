package com.example.ui.screens;

import androidx.compose.runtime.Composer;
import io.ktor.http.LinkHeader;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: TeacherMainScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0017\b\u0082\b\u0018\u00002\u00020\u0001B@\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0015\b\u0002\u0010\t\u001a\u000f\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n¢\u0006\u0002\b\f¢\u0006\u0004\b\r\u0010\u000eJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\bHÆ\u0003J\u001b\u0010\u001c\u001a\u000f\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n¢\u0006\u0002\b\fHÆ\u0003¢\u0006\u0002\u0010\u0016JM\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\u0015\b\u0002\u0010\t\u001a\u000f\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n¢\u0006\u0002\b\fHÆ\u0001¢\u0006\u0002\u0010\u001eJ\u0013\u0010\u001f\u001a\u00020\b2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\u0003HÖ\u0001J\t\u0010\"\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0014R \u0010\t\u001a\u000f\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n¢\u0006\u0002\b\f¢\u0006\n\n\u0002\u0010\u0017\u001a\u0004\b\u0015\u0010\u0016¨\u0006#"}, d2 = {"Lcom/example/ui/screens/TeacherStepItem;", "", "stepNum", "", LinkHeader.Parameters.Title, "", "description", "isCompleted", "", "actionButton", "Lkotlin/Function0;", "", "Landroidx/compose/runtime/Composable;", "<init>", "(ILjava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function2;)V", "getStepNum", "()I", "getTitle", "()Ljava/lang/String;", "getDescription", "()Z", "getActionButton", "()Lkotlin/jvm/functions/Function2;", "Lkotlin/jvm/functions/Function2;", "component1", "component2", "component3", "component4", "component5", "copy", "(ILjava/lang/String;Ljava/lang/String;ZLkotlin/jvm/functions/Function2;)Lcom/example/ui/screens/TeacherStepItem;", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
final /* data */ class TeacherStepItem {
    private final Function2<Composer, Integer, Unit> actionButton;
    private final String description;
    private final boolean isCompleted;
    private final int stepNum;
    private final String title;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ TeacherStepItem copy$default(TeacherStepItem teacherStepItem, int i, String str, String str2, boolean z, Function2 function2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = teacherStepItem.stepNum;
        }
        if ((i2 & 2) != 0) {
            str = teacherStepItem.title;
        }
        if ((i2 & 4) != 0) {
            str2 = teacherStepItem.description;
        }
        if ((i2 & 8) != 0) {
            z = teacherStepItem.isCompleted;
        }
        if ((i2 & 16) != 0) {
            function2 = teacherStepItem.actionButton;
        }
        Function2 function3 = function2;
        String str3 = str2;
        return teacherStepItem.copy(i, str, str3, z, function3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getStepNum() {
        return this.stepNum;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getDescription() {
        return this.description;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final boolean getIsCompleted() {
        return this.isCompleted;
    }

    public final Function2<Composer, Integer, Unit> component5() {
        return this.actionButton;
    }

    public final TeacherStepItem copy(int stepNum, String title, String description, boolean isCompleted, Function2<? super Composer, ? super Integer, Unit> actionButton) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(description, "description");
        return new TeacherStepItem(stepNum, title, description, isCompleted, actionButton);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TeacherStepItem)) {
            return false;
        }
        TeacherStepItem teacherStepItem = (TeacherStepItem) other;
        return this.stepNum == teacherStepItem.stepNum && Intrinsics.areEqual(this.title, teacherStepItem.title) && Intrinsics.areEqual(this.description, teacherStepItem.description) && this.isCompleted == teacherStepItem.isCompleted && Intrinsics.areEqual(this.actionButton, teacherStepItem.actionButton);
    }

    public int hashCode() {
        return (((((((Integer.hashCode(this.stepNum) * 31) + this.title.hashCode()) * 31) + this.description.hashCode()) * 31) + Boolean.hashCode(this.isCompleted)) * 31) + (this.actionButton == null ? 0 : this.actionButton.hashCode());
    }

    public String toString() {
        return "TeacherStepItem(stepNum=" + this.stepNum + ", title=" + this.title + ", description=" + this.description + ", isCompleted=" + this.isCompleted + ", actionButton=" + this.actionButton + ")";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public TeacherStepItem(int stepNum, String title, String description, boolean isCompleted, Function2<? super Composer, ? super Integer, Unit> function2) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(description, "description");
        this.stepNum = stepNum;
        this.title = title;
        this.description = description;
        this.isCompleted = isCompleted;
        this.actionButton = function2;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ TeacherStepItem(int i, String str, String str2, boolean z, Function2 function2, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        Function2 function3;
        i = (i2 & 1) != 0 ? 0 : i;
        if ((i2 & 16) == 0) {
            function3 = function2;
        } else {
            function3 = null;
        }
        this(i, str, str2, z, function3);
    }

    public final int getStepNum() {
        return this.stepNum;
    }

    public final String getTitle() {
        return this.title;
    }

    public final String getDescription() {
        return this.description;
    }

    public final boolean isCompleted() {
        return this.isCompleted;
    }

    public final Function2<Composer, Integer, Unit> getActionButton() {
        return this.actionButton;
    }
}
