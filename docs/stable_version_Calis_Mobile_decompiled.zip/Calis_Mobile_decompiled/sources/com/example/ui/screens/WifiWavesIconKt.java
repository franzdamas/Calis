package com.example.ui.screens;

import androidx.compose.animation.SingleValueAnimationKt;
import androidx.compose.animation.core.AnimationSpecKt;
import androidx.compose.foundation.CanvasKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.State;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Size;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.StrokeCap;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.Stroke;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: WifiWavesIcon.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a!\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0004\b\u0006\u0010\u0007¨\u0006\b²\u0006\n\u0010\t\u001a\u00020\u0003X\u008a\u0084\u0002"}, d2 = {"WifiWavesIcon", "", "color", "Landroidx/compose/ui/graphics/Color;", "modifier", "Landroidx/compose/ui/Modifier;", "WifiWavesIcon-3J-VO9M", "(JLandroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app", "animatedColor"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class WifiWavesIconKt {
    static final Unit WifiWavesIcon_3J_VO9M$lambda$3(long j, Modifier modifier, int i, int i2, Composer composer, int i3) {
        m7057WifiWavesIcon3JVO9M(j, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: WifiWavesIcon-3J-VO9M, reason: not valid java name */
    public static final void m7057WifiWavesIcon3JVO9M(final long color, Modifier modifier, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        final Modifier modifier3;
        Object obj;
        Composer $composer2 = $composer.startRestartGroup(-1599286764);
        ComposerKt.sourceInformation($composer2, "C(WifiWavesIcon)P(0:c#ui.graphics.Color)21@713L141,26@899L1712,26@859L1752:WifiWavesIcon.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changed(color) ? 4 : 2;
        }
        int i2 = i & 2;
        if (i2 != 0) {
            $dirty |= 48;
            modifier2 = modifier;
        } else if (($changed & 48) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 32 : 16;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 19) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            modifier3 = modifier2;
        } else {
            modifier3 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1599286764, $dirty2, -1, "com.example.ui.screens.WifiWavesIcon (WifiWavesIcon.kt:20)");
            }
            final State<Color> stateM104animateColorAsStateeuL9pac = SingleValueAnimationKt.m104animateColorAsStateeuL9pac(color, AnimationSpecKt.tween$default(800, 0, null, 6, null), "WifiWavesColor", null, $composer2, ($dirty2 & 14) | 432, 8);
            Modifier modifierM715size3ABfNKs = SizeKt.m715size3ABfNKs(modifier3, Dp.m6622constructorimpl(24));
            ComposerKt.sourceInformationMarkerStart($composer2, 683723012, "CC(remember):WifiWavesIcon.kt#9igjgp");
            boolean zChanged = $composer2.changed(stateM104animateColorAsStateeuL9pac);
            Object objRememberedValue = $composer2.rememberedValue();
            if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function1() { // from class: com.example.ui.screens.WifiWavesIconKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return WifiWavesIconKt.WifiWavesIcon_3J_VO9M$lambda$2$lambda$1(stateM104animateColorAsStateeuL9pac, (DrawScope) obj2);
                    }
                };
                $composer2.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            CanvasKt.Canvas(modifierM715size3ABfNKs, (Function1) obj, $composer2, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.screens.WifiWavesIconKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return WifiWavesIconKt.WifiWavesIcon_3J_VO9M$lambda$3(color, modifier3, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    private static final long WifiWavesIcon_3J_VO9M$lambda$0(State<Color> state) {
        return ((Color) state.getValue()).m4169unboximpl();
    }

    static final Unit WifiWavesIcon_3J_VO9M$lambda$2$lambda$1(State $animatedColor$delegate, DrawScope Canvas) {
        Intrinsics.checkNotNullParameter(Canvas, "$this$Canvas");
        float strokeWidth = Canvas.mo362toPx0680j_4(Dp.m6622constructorimpl((float) 2.5d));
        float cx = Size.m3987getWidthimpl(Canvas.mo4709getSizeNHjbRc());
        float cy = Size.m3984getHeightimpl(Canvas.mo4709getSizeNHjbRc()) / 2.0f;
        float rSmall = Size.m3987getWidthimpl(Canvas.mo4709getSizeNHjbRc()) * 0.25f;
        float rMedium = Size.m3987getWidthimpl(Canvas.mo4709getSizeNHjbRc()) * 0.6f;
        float rLarge = Size.m3987getWidthimpl(Canvas.mo4709getSizeNHjbRc()) * 0.95f;
        DrawScope.m4688drawArcyD3GUKo$default(Canvas, WifiWavesIcon_3J_VO9M$lambda$0($animatedColor$delegate), 135.0f, 90.0f, false, OffsetKt.Offset(cx - rSmall, cy - rSmall), androidx.compose.ui.geometry.SizeKt.Size(rSmall * 2.0f, rSmall * 2.0f), 0.0f, new Stroke(strokeWidth, 0.0f, StrokeCap.INSTANCE.m4512getRoundKaPHkGw(), 0, null, 26, null), null, 0, 832, null);
        DrawScope.m4688drawArcyD3GUKo$default(Canvas, WifiWavesIcon_3J_VO9M$lambda$0($animatedColor$delegate), 135.0f, 90.0f, false, OffsetKt.Offset(cx - rMedium, cy - rMedium), androidx.compose.ui.geometry.SizeKt.Size(rMedium * 2.0f, rMedium * 2.0f), 0.0f, new Stroke(strokeWidth, 0.0f, StrokeCap.INSTANCE.m4512getRoundKaPHkGw(), 0, null, 26, null), null, 0, 832, null);
        DrawScope.m4688drawArcyD3GUKo$default(Canvas, WifiWavesIcon_3J_VO9M$lambda$0($animatedColor$delegate), 135.0f, 90.0f, false, OffsetKt.Offset(cx - rLarge, cy - rLarge), androidx.compose.ui.geometry.SizeKt.Size(rLarge * 2.0f, rLarge * 2.0f), 0.0f, new Stroke(strokeWidth, 0.0f, StrokeCap.INSTANCE.m4512getRoundKaPHkGw(), 0, null, 26, null), null, 0, 832, null);
        return Unit.INSTANCE;
    }
}
