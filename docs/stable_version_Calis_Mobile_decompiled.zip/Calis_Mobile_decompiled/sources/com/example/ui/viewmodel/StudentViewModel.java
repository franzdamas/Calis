package com.example.ui.viewmodel;

import android.app.Application;
import android.util.Log;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModelKt;
import com.example.ble.BleManager;
import com.example.ble.BlePacket;
import com.example.ble.DeviceState;
import com.example.data.db.ApprovedStudentEntity;
import com.example.data.db.AttendanceEntity;
import com.example.data.db.CalisDatabase;
import com.example.data.db.ClassroomEntity;
import com.example.data.db.StudentProfileEntity;
import com.example.data.db.TaskEntity;
import com.example.data.db.TaskSubmissionEntity;
import com.example.data.db.TeacherEntity;
import com.example.data.repository.CalisRepository;
import com.example.util.ReminderNotificationHelper;
import com.google.android.gms.common.Scopes;
import io.ktor.sse.ServerSentEventKt;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharedFlow;
import kotlinx.coroutines.flow.SharedFlowKt;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import okhttp3.internal.http.StatusLine;

/* JADX INFO: compiled from: StudentViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000Ì\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b&\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u00100\u001a\u000201J\u0006\u0010V\u001a\u000201J\u0006\u0010{\u001a\u000201J\u0007\u0010\u0090\u0001\u001a\u000201J\t\u0010\u0091\u0001\u001a\u000201H\u0002J\u0007\u0010\u0092\u0001\u001a\u000201J\t\u0010\u0093\u0001\u001a\u000201H\u0002J\t\u0010\u0094\u0001\u001a\u000201H\u0002J\u0012\u0010\u0095\u0001\u001a\u0002012\t\b\u0002\u0010\u0096\u0001\u001a\u00020$J\u0007\u0010\u0098\u0001\u001a\u000201J\u0010\u0010\u0099\u0001\u001a\u0002012\u0007\u0010\u009a\u0001\u001a\u00020\u001cJ\u0007\u0010\u009b\u0001\u001a\u000201J\u0007\u0010\u009c\u0001\u001a\u000201J\u0019\u0010\u009d\u0001\u001a\u0002012\u0007\u0010\u009a\u0001\u001a\u00020\u001c2\u0007\u0010\u009e\u0001\u001a\u00020\u001cJ\u0012\u0010\u009f\u0001\u001a\u0002012\t\b\u0002\u0010 \u0001\u001a\u00020\u001cJ\u0007\u0010¡\u0001\u001a\u000201J\u0007\u0010¢\u0001\u001a\u000201J\u0007\u0010£\u0001\u001a\u000201J\u0007\u0010¤\u0001\u001a\u000201J\u0007\u0010¥\u0001\u001a\u000201J\u001a\u0010¦\u0001\u001a\u0002012\u0007\u0010§\u0001\u001a\u00020\u001c2\b\u0010¨\u0001\u001a\u00030\u008a\u0001J\u001a\u0010©\u0001\u001a\u0002012\u0007\u0010ª\u0001\u001a\u0002032\b\u0010¨\u0001\u001a\u00030\u008a\u0001J\u0007\u0010«\u0001\u001a\u000201J\u0007\u0010¬\u0001\u001a\u000201J\t\u0010\u00ad\u0001\u001a\u000201H\u0002J\u0013\u0010®\u0001\u001a\u00030\u008a\u00012\u0007\u0010¯\u0001\u001a\u00020\u001cH\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0019\u0010\f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\r¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0017\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00150\r¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0010R\u001d\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\u00180\r¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0010R\u0017\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0010R\u0016\u0010\u001e\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010 0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010!\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010 0\r¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0010R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u0010R\u0014\u0010&\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010'\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0010R\u0016\u0010)\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010*\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u0010R\u0010\u0010,\u001a\u0004\u0018\u00010-X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020/X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u00102\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030\u00180\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u00104\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030\u00180\r¢\u0006\b\n\u0000\u001a\u0004\b5\u0010\u0010R\u0014\u00106\u001a\b\u0012\u0004\u0012\u0002070\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00108\u001a\b\u0012\u0004\u0012\u0002070\r¢\u0006\b\n\u0000\u001a\u0004\b9\u0010\u0010R\u0014\u0010:\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010;\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\b<\u0010\u0010R\u0014\u0010=\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010>\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\b?\u0010\u0010R\u0014\u0010@\u001a\b\u0012\u0004\u0012\u00020A0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010B\u001a\b\u0012\u0004\u0012\u00020A0\r¢\u0006\b\n\u0000\u001a\u0004\bC\u0010\u0010R\u0014\u0010D\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010E\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\bF\u0010\u0010R\u0014\u0010G\u001a\b\u0012\u0004\u0012\u00020\u00150\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010H\u001a\b\u0012\u0004\u0012\u00020\u00150\r¢\u0006\b\n\u0000\u001a\u0004\bI\u0010\u0010R\u0014\u0010J\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010K\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\bK\u0010\u0010R\u0014\u0010L\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010M\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\bN\u0010\u0010R\u0014\u0010O\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010P\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\bP\u0010\u0010R\u0014\u0010Q\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010R\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\bR\u0010\u0010R\u0014\u0010S\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010T\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\bU\u0010\u0010R\u0010\u0010W\u001a\u0004\u0018\u00010-X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010X\u001a\u0004\u0018\u00010-X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010Y\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Z0\u00180\r¢\u0006\b\n\u0000\u001a\u0004\b[\u0010\u0010R\u0017\u0010\\\u001a\b\u0012\u0004\u0012\u00020$0\r¢\u0006\b\n\u0000\u001a\u0004\b]\u0010\u0010R\u001d\u0010^\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020_0\u00180\r¢\u0006\b\n\u0000\u001a\u0004\b`\u0010\u0010R\u001d\u0010a\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020b0\u00180\r¢\u0006\b\n\u0000\u001a\u0004\bc\u0010\u0010R\u001d\u0010d\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Z0\u00180\r¢\u0006\b\n\u0000\u001a\u0004\be\u0010\u0010R\u001d\u0010f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030\u00180\r¢\u0006\b\n\u0000\u001a\u0004\bg\u0010\u0010R\u0014\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001c0iX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010j\u001a\b\u0012\u0004\u0012\u00020\u001c0k¢\u0006\b\n\u0000\u001a\u0004\bl\u0010mR\u0014\u0010n\u001a\b\u0012\u0004\u0012\u00020o0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010p\u001a\b\u0012\u0004\u0012\u00020o0\r¢\u0006\b\n\u0000\u001a\u0004\bq\u0010\u0010R\u0014\u0010r\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010s\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\b\n\u0000\u001a\u0004\bt\u0010\u0010R\u001a\u0010u\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030\u00180\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010v\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030\u00180\r¢\u0006\b\n\u0000\u001a\u0004\bw\u0010\u0010R\u001a\u0010x\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001c0\u00180\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010y\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001c0\u00180\r¢\u0006\b\n\u0000\u001a\u0004\bz\u0010\u0010R\u0014\u0010|\u001a\b\u0012\u0004\u0012\u00020}0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010~\u001a\b\u0012\u0004\u0012\u00020}0\r¢\u0006\b\n\u0000\u001a\u0004\b\u007f\u0010\u0010R\u0015\u0010\u0080\u0001\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0081\u0001\u001a\b\u0012\u0004\u0012\u00020\u001c0\r¢\u0006\t\n\u0000\u001a\u0005\b\u0082\u0001\u0010\u0010R\u001b\u0010\u0083\u0001\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001c0\u00180\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001f\u0010\u0084\u0001\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001c0\u00180\r¢\u0006\t\n\u0000\u001a\u0005\b\u0085\u0001\u0010\u0010R\u0017\u0010\u0086\u0001\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001030\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u0087\u0001\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001030\r¢\u0006\t\n\u0000\u001a\u0005\b\u0088\u0001\u0010\u0010R\u0016\u0010\u0089\u0001\u001a\t\u0012\u0005\u0012\u00030\u008a\u00010\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u008b\u0001\u001a\t\u0012\u0005\u0012\u00030\u008a\u00010\r¢\u0006\t\n\u0000\u001a\u0005\b\u008c\u0001\u0010\u0010R\u0017\u0010\u008d\u0001\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u008e\u0001\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/0\r¢\u0006\t\n\u0000\u001a\u0005\b\u008f\u0001\u0010\u0010R\u000f\u0010\u0097\u0001\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006°\u0001"}, d2 = {"Lcom/example/ui/viewmodel/StudentViewModel;", "Landroidx/lifecycle/AndroidViewModel;", "application", "Landroid/app/Application;", "<init>", "(Landroid/app/Application;)V", "repository", "Lcom/example/data/repository/CalisRepository;", "bleManager", "Lcom/example/ble/BleManager;", "getBleManager", "()Lcom/example/ble/BleManager;", "currentProfile", "Lkotlinx/coroutines/flow/StateFlow;", "Lcom/example/data/db/StudentProfileEntity;", "getCurrentProfile", "()Lkotlinx/coroutines/flow/StateFlow;", "connectionState", "Lcom/example/ble/BleManager$ConnectionState;", "getConnectionState", "deviceState", "Lcom/example/ble/DeviceState;", "getDeviceState", "scannedDevices", "", "Lcom/example/ble/BleManager$ScannedDevice;", "getScannedDevices", "lastTxResponse", "", "getLastTxResponse", "_registeredClassroom", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/example/data/db/ClassroomEntity;", "registeredClassroom", "getRegisteredClassroom", "_isClassroomLoaded", "", "isClassroomLoaded", "_registrationStatus", "registrationStatus", "getRegistrationStatus", "_joinErrorMessage", "joinErrorMessage", "getJoinErrorMessage", "joinTimeoutJob", "Lkotlinx/coroutines/Job;", "joinConnectionStartTime", "", "clearJoinErrorMessage", "", "_registrationTasks", "Lcom/example/data/db/TaskEntity;", "registrationTasks", "getRegistrationTasks", "_regDialogStep", "Lcom/example/ui/viewmodel/StudentRegDialogStep;", "regDialogStep", "getRegDialogStep", "_registrationDeviceAddress", "registrationDeviceAddress", "getRegistrationDeviceAddress", "_registrationDeviceName", "registrationDeviceName", "getRegistrationDeviceName", "_syncState", "Lcom/example/ui/viewmodel/StudentSyncState;", "syncState", "getSyncState", "_syncMessage", "syncMessage", "getSyncMessage", "_registeredDeviceState", "registeredDeviceState", "getRegisteredDeviceState", "_isRegisteredDeviceInRange", "isRegisteredDeviceInRange", "_registeredDeviceRawHex", "registeredDeviceRawHex", "getRegisteredDeviceRawHex", "_isRegisteredSessionActive", "isRegisteredSessionActive", "_isClassroomExpired", "isClassroomExpired", "_showClassroomExpiredDialog", "showClassroomExpiredDialog", "getShowClassroomExpiredDialog", "dismissClassroomExpired", "syncScanJob", "backgroundScanJob", "myAttendanceLogs", "Lcom/example/data/db/AttendanceEntity;", "getMyAttendanceLogs", "hasCheckedInToday", "getHasCheckedInToday", "mySubmissions", "Lcom/example/data/db/TaskSubmissionEntity;", "getMySubmissions", "classroomApprovedStudents", "Lcom/example/data/db/ApprovedStudentEntity;", "getClassroomApprovedStudents", "classroomAttendanceLogs", "getClassroomAttendanceLogs", "classroomTasks", "getClassroomTasks", "_userMessage", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "userMessage", "Lkotlinx/coroutines/flow/SharedFlow;", "getUserMessage", "()Lkotlinx/coroutines/flow/SharedFlow;", "_checkInState", "Lcom/example/ui/viewmodel/StudentCheckInState;", "checkInState", "getCheckInState", "_checkInMessage", "checkInMessage", "getCheckInMessage", "_checkInTasks", "checkInTasks", "getCheckInTasks", "_checkInLogs", "checkInLogs", "getCheckInLogs", "resetCheckInState", "_taskSubmitState", "Lcom/example/ui/viewmodel/StudentTaskSubmitState;", "taskSubmitState", "getTaskSubmitState", "_taskSubmitMessage", "taskSubmitMessage", "getTaskSubmitMessage", "_taskSubmitLogs", "taskSubmitLogs", "getTaskSubmitLogs", "_taskSubmitTargetTask", "taskSubmitTargetTask", "getTaskSubmitTargetTask", "_taskSubmitScore", "", "taskSubmitScore", "getTaskSubmitScore", "_taskSubmitMarkedTimestamp", "taskSubmitMarkedTimestamp", "getTaskSubmitMarkedTimestamp", "resetTaskSubmitState", "startContinuousScanning", "triggerManualRefresh", "observeRegisteredDeviceAvailability", "observeConnectionState", "startBleScan", "forceRestart", "isManualConnectAllowed", "stopBleScan", "connectToDevice", "address", "disconnectDevice", "startJoinDialog", "initiateJoinClassroom", "name", "handleJoinConnectionFailure", "errorMessage", "stopRegistrationFlow", "registerToClassroom", "resetRegistrationState", "resetAllState", "checkIn", "submitTaskScore", "taskId", "score", "submitTaskScoreBle", "task", "manualRefresh", "dismissSyncBanner", "observeIncomingPackets", "parseTimeToMinutes", "raw", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class StudentViewModel extends AndroidViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<List<String>> _checkInLogs;
    private final MutableStateFlow<String> _checkInMessage;
    private final MutableStateFlow<StudentCheckInState> _checkInState;
    private final MutableStateFlow<List<TaskEntity>> _checkInTasks;
    private final MutableStateFlow<Boolean> _isClassroomExpired;
    private final MutableStateFlow<Boolean> _isClassroomLoaded;
    private final MutableStateFlow<Boolean> _isRegisteredDeviceInRange;
    private final MutableStateFlow<Boolean> _isRegisteredSessionActive;
    private final MutableStateFlow<String> _joinErrorMessage;
    private final MutableStateFlow<StudentRegDialogStep> _regDialogStep;
    private final MutableStateFlow<ClassroomEntity> _registeredClassroom;
    private final MutableStateFlow<String> _registeredDeviceRawHex;
    private final MutableStateFlow<DeviceState> _registeredDeviceState;
    private final MutableStateFlow<String> _registrationDeviceAddress;
    private final MutableStateFlow<String> _registrationDeviceName;
    private final MutableStateFlow<String> _registrationStatus;
    private final MutableStateFlow<List<TaskEntity>> _registrationTasks;
    private final MutableStateFlow<Boolean> _showClassroomExpiredDialog;
    private final MutableStateFlow<String> _syncMessage;
    private final MutableStateFlow<StudentSyncState> _syncState;
    private final MutableStateFlow<List<String>> _taskSubmitLogs;
    private final MutableStateFlow<Long> _taskSubmitMarkedTimestamp;
    private final MutableStateFlow<String> _taskSubmitMessage;
    private final MutableStateFlow<Integer> _taskSubmitScore;
    private final MutableStateFlow<StudentTaskSubmitState> _taskSubmitState;
    private final MutableStateFlow<TaskEntity> _taskSubmitTargetTask;
    private final MutableSharedFlow<String> _userMessage;
    private Job backgroundScanJob;
    private final BleManager bleManager;
    private final StateFlow<List<String>> checkInLogs;
    private final StateFlow<String> checkInMessage;
    private final StateFlow<StudentCheckInState> checkInState;
    private final StateFlow<List<TaskEntity>> checkInTasks;
    private final StateFlow<List<ApprovedStudentEntity>> classroomApprovedStudents;
    private final StateFlow<List<AttendanceEntity>> classroomAttendanceLogs;
    private final StateFlow<List<TaskEntity>> classroomTasks;
    private final StateFlow<BleManager.ConnectionState> connectionState;
    private final StateFlow<StudentProfileEntity> currentProfile;
    private final StateFlow<DeviceState> deviceState;
    private final StateFlow<Boolean> hasCheckedInToday;
    private final StateFlow<Boolean> isClassroomExpired;
    private final StateFlow<Boolean> isClassroomLoaded;
    private boolean isManualConnectAllowed;
    private final StateFlow<Boolean> isRegisteredDeviceInRange;
    private final StateFlow<Boolean> isRegisteredSessionActive;
    private long joinConnectionStartTime;
    private final StateFlow<String> joinErrorMessage;
    private Job joinTimeoutJob;
    private final StateFlow<String> lastTxResponse;
    private final StateFlow<List<AttendanceEntity>> myAttendanceLogs;
    private final StateFlow<List<TaskSubmissionEntity>> mySubmissions;
    private final StateFlow<StudentRegDialogStep> regDialogStep;
    private final StateFlow<ClassroomEntity> registeredClassroom;
    private final StateFlow<String> registeredDeviceRawHex;
    private final StateFlow<DeviceState> registeredDeviceState;
    private final StateFlow<String> registrationDeviceAddress;
    private final StateFlow<String> registrationDeviceName;
    private final StateFlow<String> registrationStatus;
    private final StateFlow<List<TaskEntity>> registrationTasks;
    private final CalisRepository repository;
    private final StateFlow<List<BleManager.ScannedDevice>> scannedDevices;
    private final StateFlow<Boolean> showClassroomExpiredDialog;
    private final StateFlow<String> syncMessage;
    private Job syncScanJob;
    private final StateFlow<StudentSyncState> syncState;
    private final StateFlow<List<String>> taskSubmitLogs;
    private final StateFlow<Long> taskSubmitMarkedTimestamp;
    private final StateFlow<String> taskSubmitMessage;
    private final StateFlow<Integer> taskSubmitScore;
    private final StateFlow<StudentTaskSubmitState> taskSubmitState;
    private final StateFlow<TaskEntity> taskSubmitTargetTask;
    private final SharedFlow<String> userMessage;

    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[DeviceState.values().length];
            try {
                iArr[DeviceState.SESSION_INACTIVE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[DeviceState.AUTHENTICATE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[DeviceState.SESSION_ACTIVE_BUSY.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[DeviceState.REGISTERING.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[DeviceState.FACTORY_MODE.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StudentViewModel(Application application) {
        super(application);
        Intrinsics.checkNotNullParameter(application, "application");
        this.bleManager = BleManager.INSTANCE.getInstance(application);
        this.connectionState = this.bleManager.getConnectionState();
        this.deviceState = this.bleManager.getDeviceState();
        this.scannedDevices = this.bleManager.getScannedDevices();
        this.lastTxResponse = this.bleManager.getLastTxResponse();
        this._registeredClassroom = StateFlowKt.MutableStateFlow(null);
        this.registeredClassroom = FlowKt.asStateFlow(this._registeredClassroom);
        this._isClassroomLoaded = StateFlowKt.MutableStateFlow(false);
        this.isClassroomLoaded = FlowKt.asStateFlow(this._isClassroomLoaded);
        this._registrationStatus = StateFlowKt.MutableStateFlow("NOT_REGISTERED");
        this.registrationStatus = FlowKt.asStateFlow(this._registrationStatus);
        this._joinErrorMessage = StateFlowKt.MutableStateFlow(null);
        this.joinErrorMessage = FlowKt.asStateFlow(this._joinErrorMessage);
        this._registrationTasks = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
        this.registrationTasks = FlowKt.asStateFlow(this._registrationTasks);
        this._regDialogStep = StateFlowKt.MutableStateFlow(StudentRegDialogStep.DISCOVERING);
        this.regDialogStep = FlowKt.asStateFlow(this._regDialogStep);
        this._registrationDeviceAddress = StateFlowKt.MutableStateFlow("");
        this.registrationDeviceAddress = FlowKt.asStateFlow(this._registrationDeviceAddress);
        this._registrationDeviceName = StateFlowKt.MutableStateFlow("");
        this.registrationDeviceName = FlowKt.asStateFlow(this._registrationDeviceName);
        this._syncState = StateFlowKt.MutableStateFlow(StudentSyncState.IDLE);
        this.syncState = FlowKt.asStateFlow(this._syncState);
        this._syncMessage = StateFlowKt.MutableStateFlow("");
        this.syncMessage = FlowKt.asStateFlow(this._syncMessage);
        this._registeredDeviceState = StateFlowKt.MutableStateFlow(DeviceState.UNKNOWN);
        this.registeredDeviceState = FlowKt.asStateFlow(this._registeredDeviceState);
        this._isRegisteredDeviceInRange = StateFlowKt.MutableStateFlow(false);
        this.isRegisteredDeviceInRange = FlowKt.asStateFlow(this._isRegisteredDeviceInRange);
        this._registeredDeviceRawHex = StateFlowKt.MutableStateFlow("");
        this.registeredDeviceRawHex = FlowKt.asStateFlow(this._registeredDeviceRawHex);
        this._isRegisteredSessionActive = StateFlowKt.MutableStateFlow(false);
        this.isRegisteredSessionActive = FlowKt.asStateFlow(this._isRegisteredSessionActive);
        this._isClassroomExpired = StateFlowKt.MutableStateFlow(false);
        this.isClassroomExpired = FlowKt.asStateFlow(this._isClassroomExpired);
        this._showClassroomExpiredDialog = StateFlowKt.MutableStateFlow(false);
        this.showClassroomExpiredDialog = FlowKt.asStateFlow(this._showClassroomExpiredDialog);
        this._userMessage = SharedFlowKt.MutableSharedFlow$default(0, 0, null, 7, null);
        this.userMessage = FlowKt.asSharedFlow(this._userMessage);
        this._checkInState = StateFlowKt.MutableStateFlow(StudentCheckInState.IDLE);
        this.checkInState = FlowKt.asStateFlow(this._checkInState);
        this._checkInMessage = StateFlowKt.MutableStateFlow("");
        this.checkInMessage = FlowKt.asStateFlow(this._checkInMessage);
        this._checkInTasks = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
        this.checkInTasks = FlowKt.asStateFlow(this._checkInTasks);
        this._checkInLogs = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
        this.checkInLogs = FlowKt.asStateFlow(this._checkInLogs);
        this._taskSubmitState = StateFlowKt.MutableStateFlow(StudentTaskSubmitState.IDLE);
        this.taskSubmitState = FlowKt.asStateFlow(this._taskSubmitState);
        this._taskSubmitMessage = StateFlowKt.MutableStateFlow("");
        this.taskSubmitMessage = FlowKt.asStateFlow(this._taskSubmitMessage);
        this._taskSubmitLogs = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
        this.taskSubmitLogs = FlowKt.asStateFlow(this._taskSubmitLogs);
        this._taskSubmitTargetTask = StateFlowKt.MutableStateFlow(null);
        this.taskSubmitTargetTask = FlowKt.asStateFlow(this._taskSubmitTargetTask);
        this._taskSubmitScore = StateFlowKt.MutableStateFlow(0);
        this.taskSubmitScore = FlowKt.asStateFlow(this._taskSubmitScore);
        this._taskSubmitMarkedTimestamp = StateFlowKt.MutableStateFlow(null);
        this.taskSubmitMarkedTimestamp = FlowKt.asStateFlow(this._taskSubmitMarkedTimestamp);
        this.bleManager.resetBleStateOnStartup(false);
        CalisDatabase db = CalisDatabase.INSTANCE.getDatabase(application);
        this.repository = new CalisRepository(db, db.teacherDao(), db.studentProfileDao(), db.classroomDao(), db.approvedStudentDao(), db.pendingRegistrationDao(), db.attendanceDao(), db.taskDao(), db.taskSubmissionDao(), db.syncRecordDao());
        this.currentProfile = FlowKt.stateIn(this.repository.getCurrentStudentProfile(), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), null);
        this.myAttendanceLogs = FlowKt.stateIn(FlowKt.transformLatest(this.currentProfile, new StudentViewModel$special$$inlined$flatMapLatest$1(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        final Flow flow = this.myAttendanceLogs;
        this.hasCheckedInToday = FlowKt.stateIn(new Flow<Boolean>() { // from class: com.example.ui.viewmodel.StudentViewModel$special$$inlined$map$1
            @Override // kotlinx.coroutines.flow.Flow
            public Object collect(FlowCollector<? super Boolean> flowCollector, Continuation $completion) {
                Object objCollect = flow.collect(new AnonymousClass2(flowCollector), $completion);
                return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$special$$inlined$map$1$2, reason: invalid class name */
            /* JADX INFO: compiled from: Emitters.kt */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class AnonymousClass2<T> implements FlowCollector {
                final /* synthetic */ FlowCollector $this_unsafeFlow;

                /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$special$$inlined$map$1$2$1, reason: invalid class name */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$special$$inlined$map$1$2", f = "StudentViewModel.kt", i = {0, 0, 0, 0, 0}, l = {50}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"})
                public static final class AnonymousClass1 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    public AnonymousClass1(Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Code duplicated, block: B:33:0x00fc A[LOOP:0: B:19:0x009c->B:33:0x00fc, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:42:0x00fa A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object emit(Object value, Continuation $completion) {
                    AnonymousClass1 anonymousClass1;
                    Object value2;
                    Continuation $completion2;
                    boolean z;
                    boolean z2;
                    if ($completion instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) $completion;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1($completion);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1($completion);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                            Continuation $completion3 = anonymousClass1;
                            Object value3 = value;
                            String str = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                            String str2 = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
                            Iterable iterable = (List) value3;
                            if ((iterable instanceof Collection) && ((Collection) iterable).isEmpty()) {
                                value2 = value3;
                                $completion2 = $completion3;
                                z = false;
                            } else {
                                Iterator<T> it = iterable.iterator();
                                while (true) {
                                    if (it.hasNext()) {
                                        AttendanceEntity attendanceEntity = (AttendanceEntity) it.next();
                                        Object $result2 = $result;
                                        value2 = value3;
                                        $completion2 = $completion3;
                                        if (!Intrinsics.areEqual(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000)), str)) {
                                            String date = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(str);
                                            if (!StringsKt.startsWith$default(date, str, false, 2, (Object) null)) {
                                                String date2 = attendanceEntity.getDate();
                                                Intrinsics.checkNotNull(str2);
                                                if (!StringsKt.startsWith$default(date2, str2, false, 2, (Object) null)) {
                                                    z2 = false;
                                                }
                                            }
                                            if (z2) {
                                                z = true;
                                            } else {
                                                $result = $result2;
                                                $completion3 = $completion2;
                                                value3 = value2;
                                            }
                                        }
                                        z2 = true;
                                        if (z2) {
                                            z = true;
                                        } else {
                                            $result = $result2;
                                            $completion3 = $completion2;
                                            value3 = value2;
                                        }
                                    } else {
                                        value2 = value3;
                                        $completion2 = $completion3;
                                        z = false;
                                    }
                                }
                            }
                            Boolean boolBoxBoolean = Boxing.boxBoolean(z);
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                            anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                            anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value2);
                            anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                            anonymousClass1.I$0 = 0;
                            anonymousClass1.label = 1;
                            if ($this$map_u24lambda_u245.emit(boolBoxBoolean, anonymousClass1) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            int i = anonymousClass1.I$0;
                            Object obj = anonymousClass1.L$2;
                            Object obj2 = anonymousClass1.L$0;
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }
        }, ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), false);
        this.mySubmissions = FlowKt.stateIn(FlowKt.transformLatest(this.currentProfile, new StudentViewModel$special$$inlined$flatMapLatest$2(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.classroomApprovedStudents = FlowKt.stateIn(FlowKt.transformLatest(this._registeredClassroom, new StudentViewModel$special$$inlined$flatMapLatest$3(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.classroomAttendanceLogs = FlowKt.stateIn(FlowKt.transformLatest(this._registeredClassroom, new StudentViewModel$special$$inlined$flatMapLatest$4(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.classroomTasks = FlowKt.stateIn(FlowKt.transformLatest(this._registeredClassroom, new StudentViewModel$special$$inlined$flatMapLatest$5(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass7(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass8(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass9(null), 3, null);
        observeIncomingPackets();
        observeConnectionState();
        startContinuousScanning();
        observeRegisteredDeviceAvailability();
    }

    public final BleManager getBleManager() {
        return this.bleManager;
    }

    public final StateFlow<StudentProfileEntity> getCurrentProfile() {
        return this.currentProfile;
    }

    public final StateFlow<BleManager.ConnectionState> getConnectionState() {
        return this.connectionState;
    }

    public final StateFlow<DeviceState> getDeviceState() {
        return this.deviceState;
    }

    public final StateFlow<List<BleManager.ScannedDevice>> getScannedDevices() {
        return this.scannedDevices;
    }

    public final StateFlow<String> getLastTxResponse() {
        return this.lastTxResponse;
    }

    public final StateFlow<ClassroomEntity> getRegisteredClassroom() {
        return this.registeredClassroom;
    }

    public final StateFlow<Boolean> isClassroomLoaded() {
        return this.isClassroomLoaded;
    }

    public final StateFlow<String> getRegistrationStatus() {
        return this.registrationStatus;
    }

    public final StateFlow<String> getJoinErrorMessage() {
        return this.joinErrorMessage;
    }

    public final void clearJoinErrorMessage() {
        this._joinErrorMessage.setValue(null);
    }

    public final StateFlow<List<TaskEntity>> getRegistrationTasks() {
        return this.registrationTasks;
    }

    public final StateFlow<StudentRegDialogStep> getRegDialogStep() {
        return this.regDialogStep;
    }

    public final StateFlow<String> getRegistrationDeviceAddress() {
        return this.registrationDeviceAddress;
    }

    public final StateFlow<String> getRegistrationDeviceName() {
        return this.registrationDeviceName;
    }

    public final StateFlow<StudentSyncState> getSyncState() {
        return this.syncState;
    }

    public final StateFlow<String> getSyncMessage() {
        return this.syncMessage;
    }

    public final StateFlow<DeviceState> getRegisteredDeviceState() {
        return this.registeredDeviceState;
    }

    public final StateFlow<Boolean> isRegisteredDeviceInRange() {
        return this.isRegisteredDeviceInRange;
    }

    public final StateFlow<String> getRegisteredDeviceRawHex() {
        return this.registeredDeviceRawHex;
    }

    public final StateFlow<Boolean> isRegisteredSessionActive() {
        return this.isRegisteredSessionActive;
    }

    public final StateFlow<Boolean> isClassroomExpired() {
        return this.isClassroomExpired;
    }

    public final StateFlow<Boolean> getShowClassroomExpiredDialog() {
        return this.showClassroomExpiredDialog;
    }

    public final void dismissClassroomExpired() {
        this._showClassroomExpiredDialog.setValue(false);
    }

    public final StateFlow<List<AttendanceEntity>> getMyAttendanceLogs() {
        return this.myAttendanceLogs;
    }

    public final StateFlow<Boolean> getHasCheckedInToday() {
        return this.hasCheckedInToday;
    }

    public final StateFlow<List<TaskSubmissionEntity>> getMySubmissions() {
        return this.mySubmissions;
    }

    public final StateFlow<List<ApprovedStudentEntity>> getClassroomApprovedStudents() {
        return this.classroomApprovedStudents;
    }

    public final StateFlow<List<AttendanceEntity>> getClassroomAttendanceLogs() {
        return this.classroomAttendanceLogs;
    }

    public final StateFlow<List<TaskEntity>> getClassroomTasks() {
        return this.classroomTasks;
    }

    public final SharedFlow<String> getUserMessage() {
        return this.userMessage;
    }

    public final StateFlow<StudentCheckInState> getCheckInState() {
        return this.checkInState;
    }

    public final StateFlow<String> getCheckInMessage() {
        return this.checkInMessage;
    }

    public final StateFlow<List<TaskEntity>> getCheckInTasks() {
        return this.checkInTasks;
    }

    public final StateFlow<List<String>> getCheckInLogs() {
        return this.checkInLogs;
    }

    public final void resetCheckInState() {
        this._checkInState.setValue(StudentCheckInState.IDLE);
        this._checkInMessage.setValue("");
        this._checkInTasks.setValue(CollectionsKt.emptyList());
        this._checkInLogs.setValue(CollectionsKt.emptyList());
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    public final StateFlow<StudentTaskSubmitState> getTaskSubmitState() {
        return this.taskSubmitState;
    }

    public final StateFlow<String> getTaskSubmitMessage() {
        return this.taskSubmitMessage;
    }

    public final StateFlow<List<String>> getTaskSubmitLogs() {
        return this.taskSubmitLogs;
    }

    public final StateFlow<TaskEntity> getTaskSubmitTargetTask() {
        return this.taskSubmitTargetTask;
    }

    public final StateFlow<Integer> getTaskSubmitScore() {
        return this.taskSubmitScore;
    }

    public final StateFlow<Long> getTaskSubmitMarkedTimestamp() {
        return this.taskSubmitMarkedTimestamp;
    }

    public final void resetTaskSubmitState() {
        this._taskSubmitState.setValue(StudentTaskSubmitState.IDLE);
        this._taskSubmitMessage.setValue("");
        this._taskSubmitLogs.setValue(CollectionsKt.emptyList());
        this._taskSubmitTargetTask.setValue(null);
        this._taskSubmitScore.setValue(0);
        this._taskSubmitMarkedTimestamp.setValue(null);
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$7, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$7", f = "StudentViewModel.kt", i = {}, l = {279}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass7 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass7(Continuation<? super AnonymousClass7> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass7(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass7) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<ClassroomEntity> activeBoundClassroom = StudentViewModel.this.repository.getActiveBoundClassroom();
                    final StudentViewModel studentViewModel = StudentViewModel.this;
                    this.label = 1;
                    if (activeBoundClassroom.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.StudentViewModel.7.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((ClassroomEntity) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(ClassroomEntity classroom, Continuation<? super Unit> continuation) {
                            studentViewModel._registeredClassroom.setValue(classroom);
                            studentViewModel._isClassroomLoaded.setValue(Boxing.boxBoolean(true));
                            StudentViewModel studentViewModel2 = studentViewModel;
                            if (classroom != null) {
                                studentViewModel2._isClassroomExpired.setValue(Boxing.boxBoolean(false));
                                studentViewModel._showClassroomExpiredDialog.setValue(Boxing.boxBoolean(false));
                                if (Intrinsics.areEqual(studentViewModel._registrationStatus.getValue(), "NOT_REGISTERED")) {
                                    studentViewModel._registrationStatus.setValue("APPROVED");
                                }
                            } else {
                                studentViewModel2._registeredClassroom.setValue(null);
                                studentViewModel._registrationStatus.setValue("NOT_REGISTERED");
                                studentViewModel._registrationTasks.setValue(CollectionsKt.emptyList());
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$8, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$8", f = "StudentViewModel.kt", i = {}, l = {297}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass8 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass8(Continuation<? super AnonymousClass8> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass8(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass8) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<StudentProfileEntity> currentStudentProfile = StudentViewModel.this.repository.getCurrentStudentProfile();
                    final StudentViewModel studentViewModel = StudentViewModel.this;
                    this.label = 1;
                    if (currentStudentProfile.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.StudentViewModel.8.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((StudentProfileEntity) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(StudentProfileEntity profile, Continuation<? super Unit> continuation) {
                            if (profile == null) {
                                studentViewModel._registeredClassroom.setValue(null);
                                studentViewModel._registrationStatus.setValue("NOT_REGISTERED");
                                studentViewModel._registrationTasks.setValue(CollectionsKt.emptyList());
                                studentViewModel._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$9, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$9", f = "StudentViewModel.kt", i = {}, l = {StatusLine.HTTP_PERM_REDIRECT}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass9 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass9(Continuation<? super AnonymousClass9> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass9(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass9) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<String> lastTxResponse = StudentViewModel.this.getBleManager().getLastTxResponse();
                    final StudentViewModel studentViewModel = StudentViewModel.this;
                    this.label = 1;
                    if (lastTxResponse.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.StudentViewModel.9.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((String) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(String payload, Continuation<? super Unit> continuation) {
                            if (!StringsKt.isBlank(payload)) {
                                List currentLogs = (List) studentViewModel._checkInLogs.getValue();
                                if (currentLogs.isEmpty() || !Intrinsics.areEqual(CollectionsKt.last(currentLogs), payload)) {
                                    studentViewModel._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) currentLogs, payload));
                                }
                                if (studentViewModel._taskSubmitState.getValue() != StudentTaskSubmitState.IDLE) {
                                    List submitLogs = (List) studentViewModel._taskSubmitLogs.getValue();
                                    if (submitLogs.isEmpty() || !Intrinsics.areEqual(CollectionsKt.last(submitLogs), payload)) {
                                        studentViewModel._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) submitLogs, payload));
                                    }
                                }
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$startContinuousScanning$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$startContinuousScanning$1", f = "StudentViewModel.kt", i = {0}, l = {346}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    static final class C07881 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        int label;

        C07881(Continuation<? super C07881> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            C07881 c07881 = StudentViewModel.this.new C07881(continuation);
            c07881.L$0 = obj;
            return c07881;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07881) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            CoroutineScope $this$launch = (CoroutineScope) this.L$0;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            while (CoroutineScopeKt.isActive($this$launch)) {
                if (StudentViewModel.this.getBleManager().isBluetoothEnabled()) {
                    BleManager.ConnectionState conn = StudentViewModel.this.getBleManager().getConnectionState().getValue();
                    if (!(conn instanceof BleManager.ConnectionState.Connected) && !(conn instanceof BleManager.ConnectionState.Connecting) && !(conn instanceof BleManager.ConnectionState.Disconnecting) && StudentViewModel.this._regDialogStep.getValue() != StudentRegDialogStep.CONNECTING && StudentViewModel.this._checkInState.getValue() != StudentCheckInState.CONNECTING && StudentViewModel.this._taskSubmitState.getValue() != StudentTaskSubmitState.CONNECTING && StudentViewModel.this._syncState.getValue() != StudentSyncState.CONNECTING) {
                        BleManager.startScan$default(StudentViewModel.this.getBleManager(), false, 1, null);
                    }
                }
                this.L$0 = $this$launch;
                this.label = 1;
                if (DelayKt.delay(2000L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }
    }

    private final void startContinuousScanning() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07881(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$triggerManualRefresh$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$triggerManualRefresh$1", f = "StudentViewModel.kt", i = {}, l = {355}, m = "invokeSuspend", n = {}, s = {})
    static final class C07941 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07941(Continuation<? super C07941> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07941(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07941) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    if (StudentViewModel.this.getBleManager().isBluetoothEnabled()) {
                        StudentViewModel.this.getBleManager().stopScan();
                        this.label = 1;
                        if (DelayKt.delay(300L, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        BleManager.startScan$default(StudentViewModel.this.getBleManager(), false, 1, null);
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    BleManager.startScan$default(StudentViewModel.this.getBleManager(), false, 1, null);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void triggerManualRefresh() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07941(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeRegisteredDeviceAvailability$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeRegisteredDeviceAvailability$1", f = "StudentViewModel.kt", i = {}, l = {363}, m = "invokeSuspend", n = {}, s = {})
    static final class C07871 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07871(Continuation<? super C07871> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07871(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07871) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeRegisteredDeviceAvailability$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: StudentViewModel.kt */
        @Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\n"}, d2 = {"<anonymous>", "", "devices", "", "Lcom/example/ble/BleManager$ScannedDevice;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeRegisteredDeviceAvailability$1$1", f = "StudentViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class C01681 extends SuspendLambda implements Function2<List<? extends BleManager.ScannedDevice>, Continuation<? super Unit>, Object> {
            /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ StudentViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C01681(StudentViewModel studentViewModel, Continuation<? super C01681> continuation) {
                super(2, continuation);
                this.this$0 = studentViewModel;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                C01681 c01681 = new C01681(this.this$0, continuation);
                c01681.L$0 = obj;
                return c01681;
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(List<? extends BleManager.ScannedDevice> list, Continuation<? super Unit> continuation) {
                return invoke2((List<BleManager.ScannedDevice>) list, continuation);
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final Object invoke2(List<BleManager.ScannedDevice> list, Continuation<? super Unit> continuation) {
                return ((C01681) create(list, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            /* JADX WARN: Code duplicated, block: B:100:0x01c5  */
            /* JADX WARN: Code duplicated, block: B:102:0x01cd  */
            /* JADX WARN: Code duplicated, block: B:104:0x01e7  */
            /* JADX WARN: Code duplicated, block: B:111:0x0197 A[SYNTHETIC] */
            /* JADX WARN: Code duplicated, block: B:114:? A[LOOP:1: B:70:0x014e->B:114:?, LOOP_END, SYNTHETIC] */
            /* JADX WARN: Code duplicated, block: B:30:0x006d  */
            /* JADX WARN: Code duplicated, block: B:35:0x007f  */
            /* JADX WARN: Code duplicated, block: B:38:0x0088  */
            /* JADX WARN: Code duplicated, block: B:39:0x008a  */
            /* JADX WARN: Code duplicated, block: B:44:0x00ab  */
            /* JADX WARN: Code duplicated, block: B:46:0x00bd  */
            /* JADX WARN: Code duplicated, block: B:49:0x00e9  */
            /* JADX WARN: Code duplicated, block: B:69:0x0147  */
            /* JADX WARN: Code duplicated, block: B:72:0x0154  */
            /* JADX WARN: Code duplicated, block: B:78:0x016a  */
            /* JADX WARN: Code duplicated, block: B:82:0x0177  */
            /* JADX WARN: Code duplicated, block: B:84:0x017c  */
            /* JADX WARN: Code duplicated, block: B:88:0x0185  */
            /* JADX WARN: Code duplicated, block: B:90:0x0188  */
            /* JADX WARN: Code duplicated, block: B:92:0x0192  */
            /* JADX WARN: Code duplicated, block: B:98:0x019f  */
            /*  JADX ERROR: JadxRuntimeException in pass: IfRegionVisitor
                jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v14 java.lang.Object, still in use, count: 2, list:
                  (r8v14 java.lang.Object) from 0x0068: PHI (r8 I:??) = (r8v6 java.lang.Object), (r8v14 java.lang.Object) binds: [B:27:0x0067, B:108:0x0068] A[DONT_GENERATE, DONT_INLINE]
                  (r8v14 java.lang.Object) from 0x0059: CHECK_CAST (com.example.ble.BleManager$ScannedDevice) (r8v14 java.lang.Object)
                	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:164)
                	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:129)
                	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:93)
                	at jadx.core.dex.visitors.regions.TernaryMod.makeTernaryInsn(TernaryMod.java:132)
                	at jadx.core.dex.visitors.regions.TernaryMod.processRegion(TernaryMod.java:67)
                	at jadx.core.dex.visitors.regions.TernaryMod.enterRegion(TernaryMod.java:50)
                	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:96)
                	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:27)
                	at jadx.core.dex.visitors.regions.TernaryMod.process(TernaryMod.java:36)
                	at jadx.core.dex.visitors.regions.IfRegionVisitor.process(IfRegionVisitor.java:44)
                	at jadx.core.dex.visitors.regions.IfRegionVisitor.visit(IfRegionVisitor.java:30)
                */
            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object invokeSuspend(java.lang.Object r14) {
                /*
                    Method dump skipped, instruction units count: 540
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.StudentViewModel.C07871.C01681.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (FlowKt.collectLatest(StudentViewModel.this.getBleManager().getScannedDevices(), new C01681(StudentViewModel.this, null), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void observeRegisteredDeviceAvailability() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07871(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1", f = "StudentViewModel.kt", i = {}, l = {417}, m = "invokeSuspend", n = {}, s = {})
    static final class C07851 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07851(Continuation<? super C07851> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07851(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07851) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<BleManager.ConnectionState> connectionState = StudentViewModel.this.getBleManager().getConnectionState();
                    final StudentViewModel studentViewModel = StudentViewModel.this;
                    this.label = 1;
                    if (connectionState.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.StudentViewModel.observeConnectionState.1.1

                        /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1, reason: invalid class name and collision with other inner class name */
                        /* JADX INFO: compiled from: StudentViewModel.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1", f = "StudentViewModel.kt", i = {2, 3}, l = {443, 466, 505, 520}, m = "invokeSuspend", n = {"elapsed", "elapsed"}, s = {"J$0", "J$0"})
                        static final class C01641 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ BleManager.ConnectionState $conn;
                            long J$0;
                            int label;
                            final /* synthetic */ StudentViewModel this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            C01641(BleManager.ConnectionState connectionState, StudentViewModel studentViewModel, Continuation<? super C01641> continuation) {
                                super(2, continuation);
                                this.$conn = connectionState;
                                this.this$0 = studentViewModel;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new C01641(this.$conn, this.this$0, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                return ((C01641) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            /* JADX WARN: Code duplicated, block: B:34:0x019f  */
                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Object invokeSuspend(Object $result) {
                                StudentProfileEntity profile;
                                StudentProfileEntity profile2;
                                TaskEntity targetTask;
                                int score;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        Log.d("CALIS", "StudentViewModel connectionState observed concurrently: " + this.$conn + ", regDialogStep=" + this.this$0._regDialogStep.getValue() + ", syncState=" + this.this$0._syncState.getValue());
                                        if (this.$conn instanceof BleManager.ConnectionState.Connected) {
                                            Job job = this.this$0.joinTimeoutJob;
                                            if (job != null) {
                                                Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                                            }
                                            Object value = this.this$0._regDialogStep.getValue();
                                            StudentRegDialogStep studentRegDialogStep = StudentRegDialogStep.CONNECTING;
                                            StudentViewModel studentViewModel = this.this$0;
                                            if (value == studentRegDialogStep) {
                                                studentViewModel._regDialogStep.setValue(StudentRegDialogStep.REGISTERING);
                                                this.this$0.registerToClassroom();
                                            } else {
                                                Object value2 = studentViewModel._syncState.getValue();
                                                StudentSyncState studentSyncState = StudentSyncState.CONNECTING;
                                                StudentViewModel studentViewModel2 = this.this$0;
                                                if (value2 == studentSyncState) {
                                                    studentViewModel2._syncState.setValue(StudentSyncState.SYNCING);
                                                    MutableStateFlow mutableStateFlow = this.this$0._syncMessage;
                                                    StudentProfileEntity value3 = this.this$0.getCurrentProfile().getValue();
                                                    mutableStateFlow.setValue("Connected. Transmitting REQ_UPD|" + (value3 != null ? value3.getSid() : null) + "...");
                                                    StudentProfileEntity profile3 = this.this$0.getCurrentProfile().getValue();
                                                    if (profile3 != null) {
                                                        BlePacket.RequestUpdateRequest reqPacket = new BlePacket.RequestUpdateRequest(profile3.getSid(), 0, 2, null);
                                                        final StudentViewModel studentViewModel3 = this.this$0;
                                                        this.this$0.getBleManager().sendPacket(reqPacket, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1$$ExternalSyntheticLambda0
                                                            @Override // kotlin.jvm.functions.Function1
                                                            public final Object invoke(Object obj) {
                                                                return StudentViewModel.C07851.C01631.C01641.invokeSuspend$lambda$0(studentViewModel3, ((Boolean) obj).booleanValue());
                                                            }
                                                        });
                                                    }
                                                } else {
                                                    Object value4 = studentViewModel2._checkInState.getValue();
                                                    StudentCheckInState studentCheckInState = StudentCheckInState.CONNECTING;
                                                    StudentViewModel studentViewModel4 = this.this$0;
                                                    if (value4 == studentCheckInState) {
                                                        studentViewModel4._checkInState.setValue(StudentCheckInState.CHECKING_IN);
                                                        this.this$0._checkInMessage.setValue("Requesting MTU 255 & enabling RX/TX notifications...");
                                                        this.this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._checkInLogs.getValue(), "GATT: Requesting MTU 255 & enabling RX/TX notifications..."));
                                                        this.label = 1;
                                                        if (DelayKt.delay(600L, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        this.this$0._checkInMessage.setValue("Connected. Sending Check-In request...");
                                                        this.this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._checkInLogs.getValue(), "GATT: Connected successfully."));
                                                        profile = this.this$0.getCurrentProfile().getValue();
                                                        if (profile != null) {
                                                            BlePacket.CheckInRequest chkInPacket = new BlePacket.CheckInRequest(profile.getSid(), 0, 2, null);
                                                            this.this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._checkInLogs.getValue(), "RX <- Transmitting packet: " + chkInPacket.encodeForDevice()));
                                                            final StudentViewModel studentViewModel5 = this.this$0;
                                                            this.this$0.getBleManager().sendPacket(chkInPacket, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1$$ExternalSyntheticLambda1
                                                                @Override // kotlin.jvm.functions.Function1
                                                                public final Object invoke(Object obj) {
                                                                    return StudentViewModel.C07851.C01631.C01641.invokeSuspend$lambda$1(studentViewModel5, ((Boolean) obj).booleanValue());
                                                                }
                                                            });
                                                        }
                                                    } else if (studentViewModel4._taskSubmitState.getValue() == StudentTaskSubmitState.CONNECTING) {
                                                        this.this$0._taskSubmitState.setValue(StudentTaskSubmitState.SUBMITTING);
                                                        this.this$0._taskSubmitMessage.setValue("Requesting MTU 255 & enabling RX/TX notifications...");
                                                        this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "GATT: Requesting MTU 255 & enabling RX/TX notifications..."));
                                                        this.label = 2;
                                                        if (DelayKt.delay(600L, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        this.this$0._taskSubmitMessage.setValue("Connected. Sending Task Submission (TK_SBM)...");
                                                        this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "GATT: Connected successfully."));
                                                        profile2 = this.this$0.getCurrentProfile().getValue();
                                                        targetTask = (TaskEntity) this.this$0._taskSubmitTargetTask.getValue();
                                                        score = ((Number) this.this$0._taskSubmitScore.getValue()).intValue();
                                                        if (profile2 != null && targetTask != null) {
                                                            BlePacket.TaskSubmissionRequest tkSbmPacket = new BlePacket.TaskSubmissionRequest(profile2.getSid(), targetTask.getTkid(), String.valueOf(score), 0, 8, null);
                                                            String packetStr = tkSbmPacket.encodeForDevice();
                                                            this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "RX <- Transmitting packet: " + packetStr));
                                                            final StudentViewModel studentViewModel6 = this.this$0;
                                                            this.this$0.getBleManager().sendPacket(tkSbmPacket, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1$$ExternalSyntheticLambda2
                                                                @Override // kotlin.jvm.functions.Function1
                                                                public final Object invoke(Object obj) {
                                                                    return StudentViewModel.C07851.C01631.C01641.invokeSuspend$lambda$2(studentViewModel6, ((Boolean) obj).booleanValue());
                                                                }
                                                            });
                                                        }
                                                    }
                                                }
                                            }
                                        } else if (this.$conn instanceof BleManager.ConnectionState.Error) {
                                            if (this.this$0._taskSubmitState.getValue() == StudentTaskSubmitState.SUBMITTING) {
                                                this.this$0._taskSubmitState.setValue(StudentTaskSubmitState.FAILED);
                                                this.this$0._taskSubmitMessage.setValue("Failed to communicate with classroom device. Try again later.");
                                                this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "Error: BLE Connection error."));
                                                this.this$0.getBleManager().clearBleObject();
                                            }
                                            if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING) {
                                                long elapsed = System.currentTimeMillis() - this.this$0.joinConnectionStartTime;
                                                if (elapsed >= 10000) {
                                                    this.this$0.handleJoinConnectionFailure("Failed to connect. Try again later.");
                                                } else {
                                                    this.J$0 = elapsed;
                                                    this.label = 3;
                                                    if (DelayKt.delay(1000L, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING && Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "NOT_REGISTERED") && !StringsKt.isBlank((CharSequence) this.this$0._registrationDeviceAddress.getValue())) {
                                                        this.this$0.getBleManager().connect((String) this.this$0._registrationDeviceAddress.getValue());
                                                    }
                                                }
                                            }
                                        } else if (this.$conn instanceof BleManager.ConnectionState.Disconnected) {
                                            if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING) {
                                                long elapsed2 = System.currentTimeMillis() - this.this$0.joinConnectionStartTime;
                                                if (elapsed2 >= 10000) {
                                                    this.this$0.handleJoinConnectionFailure("Failed to connect. Try again later.");
                                                } else {
                                                    this.J$0 = elapsed2;
                                                    this.label = 4;
                                                    if (DelayKt.delay(1000L, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING && Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "NOT_REGISTERED") && !StringsKt.isBlank((CharSequence) this.this$0._registrationDeviceAddress.getValue())) {
                                                        this.this$0.getBleManager().connect((String) this.this$0._registrationDeviceAddress.getValue());
                                                    }
                                                }
                                            } else if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.REGISTERING || Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "PENDING")) {
                                                this.this$0.handleJoinConnectionFailure("Disconnected from classroom device. Registration not completed.");
                                            } else if (this.this$0.getBleManager().isBluetoothEnabled() && this.this$0._registeredClassroom.getValue() != null) {
                                                BleManager.startScan$default(this.this$0.getBleManager(), false, 1, null);
                                            }
                                        }
                                        return Unit.INSTANCE;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        this.this$0._checkInMessage.setValue("Connected. Sending Check-In request...");
                                        this.this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._checkInLogs.getValue(), "GATT: Connected successfully."));
                                        profile = this.this$0.getCurrentProfile().getValue();
                                        if (profile != null) {
                                            BlePacket.CheckInRequest chkInPacket2 = new BlePacket.CheckInRequest(profile.getSid(), 0, 2, null);
                                            this.this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._checkInLogs.getValue(), "RX <- Transmitting packet: " + chkInPacket2.encodeForDevice()));
                                            final StudentViewModel studentViewModel7 = this.this$0;
                                            this.this$0.getBleManager().sendPacket(chkInPacket2, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1$$ExternalSyntheticLambda1
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj) {
                                                    return StudentViewModel.C07851.C01631.C01641.invokeSuspend$lambda$1(studentViewModel7, ((Boolean) obj).booleanValue());
                                                }
                                            });
                                        }
                                        return Unit.INSTANCE;
                                    case 2:
                                        ResultKt.throwOnFailure($result);
                                        this.this$0._taskSubmitMessage.setValue("Connected. Sending Task Submission (TK_SBM)...");
                                        this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "GATT: Connected successfully."));
                                        profile2 = this.this$0.getCurrentProfile().getValue();
                                        targetTask = (TaskEntity) this.this$0._taskSubmitTargetTask.getValue();
                                        score = ((Number) this.this$0._taskSubmitScore.getValue()).intValue();
                                        if (profile2 != null) {
                                            BlePacket.TaskSubmissionRequest tkSbmPacket2 = new BlePacket.TaskSubmissionRequest(profile2.getSid(), targetTask.getTkid(), String.valueOf(score), 0, 8, null);
                                            String packetStr2 = tkSbmPacket2.encodeForDevice();
                                            this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "RX <- Transmitting packet: " + packetStr2));
                                            final StudentViewModel studentViewModel8 = this.this$0;
                                            this.this$0.getBleManager().sendPacket(tkSbmPacket2, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$observeConnectionState$1$1$1$$ExternalSyntheticLambda2
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj) {
                                                    return StudentViewModel.C07851.C01631.C01641.invokeSuspend$lambda$2(studentViewModel8, ((Boolean) obj).booleanValue());
                                                }
                                            });
                                        }
                                        return Unit.INSTANCE;
                                    case 3:
                                        long elapsed3 = this.J$0;
                                        ResultKt.throwOnFailure($result);
                                        if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING) {
                                            this.this$0.getBleManager().connect((String) this.this$0._registrationDeviceAddress.getValue());
                                        }
                                        return Unit.INSTANCE;
                                    case 4:
                                        long j = this.J$0;
                                        ResultKt.throwOnFailure($result);
                                        if (this.this$0._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING) {
                                            this.this$0.getBleManager().connect((String) this.this$0._registrationDeviceAddress.getValue());
                                        }
                                        return Unit.INSTANCE;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            }

                            static final Unit invokeSuspend$lambda$0(StudentViewModel this$0, boolean success) {
                                if (success) {
                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new StudentViewModel$observeConnectionState$1$1$1$1$1(this$0, null), 3, null);
                                }
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$1(StudentViewModel this$0, boolean success) {
                                if (success) {
                                    this$0._checkInState.setValue(StudentCheckInState.WAITING_FOR_ACCEPT);
                                    this$0._checkInMessage.setValue("Check-In request sent. Waiting for confirmation...");
                                    this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this$0._checkInLogs.getValue(), "RX -> Packet transmitted. Waiting for TX notifications..."));
                                } else {
                                    this$0._checkInState.setValue(StudentCheckInState.FAILED);
                                    this$0._checkInMessage.setValue("Failed to send check-in packet.");
                                    this$0._checkInLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this$0._checkInLogs.getValue(), "Error: Failed to transmit packet on RX."));
                                }
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$2(StudentViewModel this$0, boolean success) {
                                if (success) {
                                    this$0._taskSubmitState.setValue(StudentTaskSubmitState.WAITING_FOR_MARKED);
                                    this$0._taskSubmitMessage.setValue("TK_SBM packet sent. Waiting for Teacher's evaluation...");
                                    this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this$0._taskSubmitLogs.getValue(), "RX -> Packet transmitted. Waiting for TX notifications..."));
                                } else {
                                    this$0._taskSubmitState.setValue(StudentTaskSubmitState.FAILED);
                                    this$0._taskSubmitMessage.setValue("Failed to send TK_SBM packet.");
                                    this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this$0._taskSubmitLogs.getValue(), "Error: Failed to transmit packet on RX."));
                                }
                                return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((BleManager.ConnectionState) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(BleManager.ConnectionState conn, Continuation<? super Unit> continuation) {
                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(studentViewModel), null, null, new C01641(conn, studentViewModel, null), 3, null);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    private final void observeConnectionState() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07851(null), 3, null);
    }

    public static /* synthetic */ void startBleScan$default(StudentViewModel studentViewModel, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        studentViewModel.startBleScan(z);
    }

    public final void startBleScan(boolean forceRestart) {
        this.bleManager.startScan(forceRestart);
    }

    public final void stopBleScan() {
        this.bleManager.stopScan();
    }

    public final void connectToDevice(String address) {
        Intrinsics.checkNotNullParameter(address, "address");
        if (!this.isManualConnectAllowed) {
            Log.e("CALIS", "Automatic connection attempt blocked! Connection only allowed via manual refresh.");
        } else {
            this.bleManager.connect(address);
            this.isManualConnectAllowed = false;
        }
    }

    public final void disconnectDevice() {
        Job job = this.syncScanJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._syncState.setValue(StudentSyncState.IDLE);
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    public final void startJoinDialog() {
        this._joinErrorMessage.setValue(null);
        if (this._registeredClassroom.getValue() == null) {
            this._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
            this._registrationStatus.setValue("NOT_REGISTERED");
            this._registrationDeviceAddress.setValue("");
            this._registrationDeviceName.setValue("");
            this._registrationTasks.setValue(CollectionsKt.emptyList());
        }
        startBleScan$default(this, false, 1, null);
    }

    public final void initiateJoinClassroom(String address, String name) {
        Intrinsics.checkNotNullParameter(address, "address");
        Intrinsics.checkNotNullParameter(name, "name");
        Job job = this.joinTimeoutJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._joinErrorMessage.setValue(null);
        this.joinConnectionStartTime = System.currentTimeMillis();
        this._registrationDeviceAddress.setValue(address);
        this._registrationDeviceName.setValue(name);
        this._regDialogStep.setValue(StudentRegDialogStep.CONNECTING);
        this._registrationStatus.setValue("NOT_REGISTERED");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        this.bleManager.stopScan();
        this.bleManager.connect(address);
        this.joinTimeoutJob = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07801(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$initiateJoinClassroom$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$initiateJoinClassroom$1", f = "StudentViewModel.kt", i = {}, l = {594}, m = "invokeSuspend", n = {}, s = {})
    static final class C07801 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07801(Continuation<? super C07801> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07801(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07801) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (DelayKt.delay(10000L, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            if (StudentViewModel.this._regDialogStep.getValue() == StudentRegDialogStep.CONNECTING && Intrinsics.areEqual(StudentViewModel.this._registrationStatus.getValue(), "NOT_REGISTERED")) {
                Log.w("CALIS", "Join classroom connection timed out after 10s");
                StudentViewModel.this.handleJoinConnectionFailure("Failed to connect. Try again later.");
            }
            return Unit.INSTANCE;
        }
    }

    public static /* synthetic */ void handleJoinConnectionFailure$default(StudentViewModel studentViewModel, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "Failed to connect. Try again later.";
        }
        studentViewModel.handleJoinConnectionFailure(str);
    }

    public final void handleJoinConnectionFailure(String errorMessage) {
        Intrinsics.checkNotNullParameter(errorMessage, "errorMessage");
        Job job = this.joinTimeoutJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._joinErrorMessage.setValue(errorMessage);
        this._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
        this._registrationStatus.setValue("NOT_REGISTERED");
        this._registrationDeviceAddress.setValue("");
        this._registrationDeviceName.setValue("");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        this.bleManager.clearBleObject();
        startBleScan$default(this, false, 1, null);
    }

    public final void stopRegistrationFlow() {
        Job job = this.joinTimeoutJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._joinErrorMessage.setValue(null);
        this._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
        this._registrationStatus.setValue("NOT_REGISTERED");
        this._registrationDeviceAddress.setValue("");
        this._registrationDeviceName.setValue("");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    public final void registerToClassroom() {
        Log.d("CALIS", "registerToClassroom called, profile: " + this.currentProfile.getValue() + ", status: " + ((Object) this._registrationStatus.getValue()));
        if (!Intrinsics.areEqual(this._registrationStatus.getValue(), "NOT_REGISTERED")) {
            Log.d("CALIS", "registerToClassroom skipped: registration already in progress (" + ((Object) this._registrationStatus.getValue()) + ")");
            return;
        }
        StudentProfileEntity profile = this.currentProfile.getValue();
        if (profile == null) {
            return;
        }
        this._registrationStatus.setValue("PENDING");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        BlePacket.StudentRegRequest regPacket = new BlePacket.StudentRegRequest(profile.getSid(), profile.getFullName(), profile.getSex(), profile.getLrn(), profile.getBirth(), 0, 32, null);
        this.bleManager.sendPacket(regPacket, new Function1() { // from class: com.example.ui.viewmodel.StudentViewModel$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return StudentViewModel.registerToClassroom$lambda$7(this.f$0, ((Boolean) obj).booleanValue());
            }
        });
    }

    static final Unit registerToClassroom$lambda$7(StudentViewModel this$0, boolean success) {
        if (success) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new StudentViewModel$registerToClassroom$1$1(this$0, null), 3, null);
        } else {
            this$0._registrationStatus.setValue("NOT_REGISTERED");
        }
        return Unit.INSTANCE;
    }

    public final void resetRegistrationState() {
        Job job = this.joinTimeoutJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._joinErrorMessage.setValue(null);
        this._registrationStatus.setValue("NOT_REGISTERED");
        this._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
        this._registrationDeviceAddress.setValue("");
        this._registrationDeviceName.setValue("");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    public final void resetAllState() {
        Job job = this.joinTimeoutJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this._joinErrorMessage.setValue(null);
        this._registeredClassroom.setValue(null);
        this._registrationStatus.setValue("NOT_REGISTERED");
        this._registrationTasks.setValue(CollectionsKt.emptyList());
        this._regDialogStep.setValue(StudentRegDialogStep.DISCOVERING);
        this._registrationDeviceAddress.setValue("");
        this._registrationDeviceName.setValue("");
        this._syncState.setValue(StudentSyncState.IDLE);
        this._syncMessage.setValue("");
        Job job2 = this.syncScanJob;
        if (job2 != null) {
            Job.DefaultImpls.cancel$default(job2, (CancellationException) null, 1, (Object) null);
        }
        this.bleManager.stopScan();
        this.bleManager.clearBleObject();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x00aa  */
    public final void checkIn() {
        boolean alreadyCheckedIn;
        boolean z;
        ClassroomEntity classroom = this._registeredClassroom.getValue();
        StudentProfileEntity profile = this.currentProfile.getValue();
        if (classroom == null || profile == null) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass1(null), 3, null);
            return;
        }
        String todayYmd = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String todayMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
        Iterable value = this.myAttendanceLogs.getValue();
        if (!(value instanceof Collection) || !((Collection) value).isEmpty()) {
            Iterator it = value.iterator();
            while (true) {
                if (it.hasNext()) {
                    AttendanceEntity attendanceEntity = (AttendanceEntity) it.next();
                    if (Intrinsics.areEqual(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(attendanceEntity.getTimestamp() * 1000)), todayYmd)) {
                        z = true;
                    } else {
                        String date = attendanceEntity.getDate();
                        Intrinsics.checkNotNull(todayYmd);
                        if (StringsKt.startsWith$default(date, todayYmd, false, 2, (Object) null)) {
                            z = true;
                        } else {
                            String date2 = attendanceEntity.getDate();
                            Intrinsics.checkNotNull(todayMdy);
                            if (StringsKt.startsWith$default(date2, todayMdy, false, 2, (Object) null)) {
                                z = true;
                            } else {
                                z = false;
                            }
                        }
                    }
                    if (z) {
                        alreadyCheckedIn = true;
                        break;
                    }
                } else {
                    alreadyCheckedIn = false;
                    break;
                }
            }
        } else {
            alreadyCheckedIn = false;
        }
        if (alreadyCheckedIn || this.hasCheckedInToday.getValue().booleanValue()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass2(null), 3, null);
            return;
        }
        if (!this.bleManager.isBluetoothEnabled()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass3(null), 3, null);
            return;
        }
        this._checkInTasks.setValue(CollectionsKt.emptyList());
        this._checkInState.setValue(StudentCheckInState.DISCOVERING);
        this._checkInMessage.setValue("Searching for classroom: " + classroom.getClassroomName() + "...");
        this.bleManager.stopScan();
        BleManager.startScan$default(this.bleManager, false, 1, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass4(classroom, this, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$checkIn$1, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$checkIn$1", f = "StudentViewModel.kt", i = {}, l = {688}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Join a classroom first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$checkIn$2, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$checkIn$2", f = "StudentViewModel.kt", i = {}, l = {701}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("You have already checked-in for today", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$checkIn$3, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$checkIn$3", f = "StudentViewModel.kt", i = {}, l = {708}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass3(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Enable Bluetooth first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$checkIn$4, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$checkIn$4", f = "StudentViewModel.kt", i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4}, l = {738, 754, 764, 775, 786}, m = "invokeSuspend", n = {"targetMac", "targetName", "devices", "found", "startTime", "targetMac", "targetName", "foundAddress", "startTime", "connected", "attempt", "targetMac", "targetName", "foundAddress", "startTime", "connected", "attempt", "connStart", "targetMac", "targetName", "foundAddress", "startTime", "connected", "chkStart", "targetMac", "targetName", "foundAddress", "startTime", "connected"}, s = {"L$0", "L$1", "L$2", "L$3", "J$0", "L$0", "L$1", "L$2", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "J$0", "I$0", "I$1", "J$1", "L$0", "L$1", "L$2", "J$0", "I$0", "J$1", "L$0", "L$1", "L$2", "J$0", "I$0"})
    static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        int I$0;
        int I$1;
        long J$0;
        long J$1;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        final /* synthetic */ StudentViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass4(ClassroomEntity classroomEntity, StudentViewModel studentViewModel, Continuation<? super AnonymousClass4> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
            this.this$0 = studentViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass4(this.$classroom, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:120:0x0151 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:122:0x014e A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:14:0x00db  */
        /* JADX WARN: Code duplicated, block: B:19:0x0106  */
        /* JADX WARN: Code duplicated, block: B:21:0x0118  */
        /* JADX WARN: Code duplicated, block: B:25:0x0122  */
        /* JADX WARN: Code duplicated, block: B:27:0x0126  */
        /* JADX WARN: Code duplicated, block: B:29:0x0130  */
        /* JADX WARN: Code duplicated, block: B:31:0x0135  */
        /* JADX WARN: Code duplicated, block: B:35:0x013f  */
        /* JADX WARN: Code duplicated, block: B:37:0x0142  */
        /* JADX WARN: Code duplicated, block: B:45:0x0159  */
        /* JADX WARN: Code duplicated, block: B:46:0x015e  */
        /* JADX WARN: Code duplicated, block: B:48:0x017d A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:49:0x017e  */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r21v2 */
        /* JADX WARN: Type inference failed for: r21v3 */
        /* JADX WARN: Type inference failed for: r21v5 */
        /* JADX WARN: Type inference failed for: r22v0 */
        /* JADX WARN: Type inference failed for: r22v1 */
        /* JADX WARN: Type inference failed for: r22v2 */
        /* JADX WARN: Type inference failed for: r22v3 */
        /* JADX WARN: Type inference failed for: r4v10 */
        /* JADX WARN: Type inference failed for: r4v14 */
        /* JADX WARN: Type inference failed for: r4v9 */
        /* JADX WARN: Type inference failed for: r9v0 */
        /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
        /* JADX WARN: Type inference failed for: r9v2 */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x017e -> B:50:0x0183). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:66:0x0234 -> B:67:0x0248). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:95:0x0314 -> B:96:0x031d). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r26) {
            /*
                Method dump skipped, instruction units count: 1032
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.StudentViewModel.AnonymousClass4.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public final void submitTaskScore(String taskId, int score) {
        Intrinsics.checkNotNullParameter(taskId, "taskId");
        StudentProfileEntity profile = this.currentProfile.getValue();
        if (profile == null) {
            return;
        }
        ClassroomEntity classroom = this._registeredClassroom.getValue();
        long timestamp = System.currentTimeMillis() / 1000;
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07891(taskId, profile, score, timestamp, classroom, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$submitTaskScore$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$submitTaskScore$1", f = "StudentViewModel.kt", i = {1, 1, 2, 2, 2, 2}, l = {803, 814, 819}, m = "invokeSuspend", n = {"todayDateStr", "todayDateStrMdy", "todayDateStr", "todayDateStrMdy", "existingLogs", "hasTodayLog"}, s = {"L$0", "L$1", "L$0", "L$1", "L$2", "I$0"})
    static final class C07891 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        final /* synthetic */ StudentProfileEntity $profile;
        final /* synthetic */ int $score;
        final /* synthetic */ String $taskId;
        final /* synthetic */ long $timestamp;
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07891(String str, StudentProfileEntity studentProfileEntity, int i, long j, ClassroomEntity classroomEntity, Continuation<? super C07891> continuation) {
            super(2, continuation);
            this.$taskId = str;
            this.$profile = studentProfileEntity;
            this.$score = i;
            this.$timestamp = j;
            this.$classroom = classroomEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07891(this.$taskId, this.$profile, this.$score, this.$timestamp, this.$classroom, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07891) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:14:0x0066  */
        /* JADX WARN: Code duplicated, block: B:16:0x00ab A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:17:0x00ac  */
        /* JADX WARN: Code duplicated, block: B:20:0x00be  */
        /* JADX WARN: Code duplicated, block: B:23:0x00cb  */
        /* JADX WARN: Code duplicated, block: B:26:0x00d5  */
        /* JADX WARN: Code duplicated, block: B:28:0x00eb  */
        /* JADX WARN: Code duplicated, block: B:30:0x00f9  */
        /* JADX WARN: Code duplicated, block: B:32:0x0106  */
        /* JADX WARN: Code duplicated, block: B:35:0x0119  */
        /* JADX WARN: Code duplicated, block: B:37:0x011d  */
        /* JADX WARN: Code duplicated, block: B:41:0x0124 A[LOOP:0: B:24:0x00cf->B:41:0x0124, LOOP_END] */
        /* JADX WARN: Code duplicated, block: B:45:0x012e  */
        /* JADX WARN: Code duplicated, block: B:47:0x016b A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:48:0x016c  */
        /* JADX WARN: Code duplicated, block: B:52:0x0122 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:53:0x0128 A[SYNTHETIC] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String todayDateStr;
            String todayDateStrMdy;
            Object objFirst;
            String todayDateStrMdy2;
            String todayDateStr2;
            Iterable existingLogs;
            Iterable iterable;
            StudentProfileEntity studentProfileEntity;
            Iterator it;
            String todayDateStrMdy3;
            int i;
            AttendanceEntity attendanceEntity;
            boolean z;
            String date;
            String date2;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this.repository.recordTaskSubmission(this.$taskId, this.$profile.getSid(), this.$profile.getFullName(), this.$score, this.$timestamp, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    if (this.$classroom != null) {
                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                        todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
                        this.L$0 = todayDateStr;
                        this.L$1 = todayDateStrMdy;
                        this.label = 2;
                        objFirst = FlowKt.first(StudentViewModel.this.repository.getAttendanceForClassroom(this.$classroom.getCid()), this);
                        if (objFirst == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        todayDateStrMdy2 = todayDateStr;
                        todayDateStr2 = todayDateStrMdy;
                        existingLogs = (List) objFirst;
                        iterable = existingLogs;
                        studentProfileEntity = this.$profile;
                        if ((iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                            it = iterable.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    attendanceEntity = (AttendanceEntity) it.next();
                                    if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy2);
                                        if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                            todayDateStrMdy3 = todayDateStr2;
                                        } else {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStr2);
                                            if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                todayDateStrMdy3 = todayDateStr2;
                                            } else {
                                                todayDateStrMdy3 = todayDateStr2;
                                                if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                }
                                                if (z) {
                                                    i = 1;
                                                } else {
                                                    todayDateStr2 = todayDateStrMdy3;
                                                }
                                            }
                                        }
                                        z = true;
                                        if (z) {
                                            i = 1;
                                        } else {
                                            todayDateStr2 = todayDateStrMdy3;
                                        }
                                    } else {
                                        todayDateStrMdy3 = todayDateStr2;
                                    }
                                    z = false;
                                    if (z) {
                                        i = 1;
                                    } else {
                                        todayDateStr2 = todayDateStrMdy3;
                                    }
                                } else {
                                    todayDateStrMdy3 = todayDateStr2;
                                    i = 0;
                                }
                            }
                        } else {
                            todayDateStrMdy3 = todayDateStr2;
                            i = 0;
                        }
                        if (i == 0) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                            this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                            this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                            this.I$0 = i;
                            this.label = 3;
                            if (StudentViewModel.this.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$timestamp, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(StudentViewModel.this.getApplication(), this.$classroom.getCid());
                        }
                    }
                    ReminderNotificationHelper.INSTANCE.cancelTaskNotification(StudentViewModel.this.getApplication(), this.$taskId);
                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(StudentViewModel.this.getApplication());
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    if (this.$classroom != null) {
                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                        todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
                        this.L$0 = todayDateStr;
                        this.L$1 = todayDateStrMdy;
                        this.label = 2;
                        objFirst = FlowKt.first(StudentViewModel.this.repository.getAttendanceForClassroom(this.$classroom.getCid()), this);
                        if (objFirst == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        todayDateStrMdy2 = todayDateStr;
                        todayDateStr2 = todayDateStrMdy;
                        existingLogs = (List) objFirst;
                        iterable = existingLogs;
                        studentProfileEntity = this.$profile;
                        if (iterable instanceof Collection) {
                            it = iterable.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    attendanceEntity = (AttendanceEntity) it.next();
                                    if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy2);
                                        if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStr2);
                                            if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                todayDateStrMdy3 = todayDateStr2;
                                                if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                }
                                                if (z) {
                                                    i = 1;
                                                } else {
                                                    todayDateStr2 = todayDateStrMdy3;
                                                }
                                            } else {
                                                todayDateStrMdy3 = todayDateStr2;
                                            }
                                        } else {
                                            todayDateStrMdy3 = todayDateStr2;
                                        }
                                        z = true;
                                        if (z) {
                                            i = 1;
                                        } else {
                                            todayDateStr2 = todayDateStrMdy3;
                                        }
                                    } else {
                                        todayDateStrMdy3 = todayDateStr2;
                                    }
                                    z = false;
                                    if (z) {
                                        i = 1;
                                    } else {
                                        todayDateStr2 = todayDateStrMdy3;
                                    }
                                } else {
                                    todayDateStrMdy3 = todayDateStr2;
                                    i = 0;
                                }
                            }
                        } else {
                            it = iterable.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    attendanceEntity = (AttendanceEntity) it.next();
                                    if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                        date = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStrMdy2);
                                        if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                            date2 = attendanceEntity.getDate();
                                            Intrinsics.checkNotNull(todayDateStr2);
                                            if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                todayDateStrMdy3 = todayDateStr2;
                                                if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                }
                                                if (z) {
                                                    i = 1;
                                                } else {
                                                    todayDateStr2 = todayDateStrMdy3;
                                                }
                                            } else {
                                                todayDateStrMdy3 = todayDateStr2;
                                            }
                                        } else {
                                            todayDateStrMdy3 = todayDateStr2;
                                        }
                                        z = true;
                                        if (z) {
                                            i = 1;
                                        } else {
                                            todayDateStr2 = todayDateStrMdy3;
                                        }
                                    } else {
                                        todayDateStrMdy3 = todayDateStr2;
                                    }
                                    z = false;
                                    if (z) {
                                        i = 1;
                                    } else {
                                        todayDateStr2 = todayDateStrMdy3;
                                    }
                                } else {
                                    todayDateStrMdy3 = todayDateStr2;
                                    i = 0;
                                }
                            }
                        }
                        if (i == 0) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                            this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                            this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                            this.I$0 = i;
                            this.label = 3;
                            if (StudentViewModel.this.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$timestamp, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(StudentViewModel.this.getApplication(), this.$classroom.getCid());
                        }
                    }
                    ReminderNotificationHelper.INSTANCE.cancelTaskNotification(StudentViewModel.this.getApplication(), this.$taskId);
                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(StudentViewModel.this.getApplication());
                    return Unit.INSTANCE;
                case 2:
                    todayDateStr2 = (String) this.L$1;
                    todayDateStrMdy2 = (String) this.L$0;
                    ResultKt.throwOnFailure($result);
                    objFirst = $result;
                    existingLogs = (List) objFirst;
                    iterable = existingLogs;
                    studentProfileEntity = this.$profile;
                    if (iterable instanceof Collection) {
                        it = iterable.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                attendanceEntity = (AttendanceEntity) it.next();
                                if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStrMdy2);
                                    if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr2);
                                        if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                            todayDateStrMdy3 = todayDateStr2;
                                            if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                            }
                                            if (z) {
                                                i = 1;
                                            } else {
                                                todayDateStr2 = todayDateStrMdy3;
                                            }
                                        } else {
                                            todayDateStrMdy3 = todayDateStr2;
                                        }
                                    } else {
                                        todayDateStrMdy3 = todayDateStr2;
                                    }
                                    z = true;
                                    if (z) {
                                        i = 1;
                                    } else {
                                        todayDateStr2 = todayDateStrMdy3;
                                    }
                                } else {
                                    todayDateStrMdy3 = todayDateStr2;
                                }
                                z = false;
                                if (z) {
                                    i = 1;
                                } else {
                                    todayDateStr2 = todayDateStrMdy3;
                                }
                            } else {
                                todayDateStrMdy3 = todayDateStr2;
                                i = 0;
                            }
                        }
                    } else {
                        it = iterable.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                attendanceEntity = (AttendanceEntity) it.next();
                                if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                    date = attendanceEntity.getDate();
                                    Intrinsics.checkNotNull(todayDateStrMdy2);
                                    if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                        date2 = attendanceEntity.getDate();
                                        Intrinsics.checkNotNull(todayDateStr2);
                                        if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                            todayDateStrMdy3 = todayDateStr2;
                                            if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                            }
                                            if (z) {
                                                i = 1;
                                            } else {
                                                todayDateStr2 = todayDateStrMdy3;
                                            }
                                        } else {
                                            todayDateStrMdy3 = todayDateStr2;
                                        }
                                    } else {
                                        todayDateStrMdy3 = todayDateStr2;
                                    }
                                    z = true;
                                    if (z) {
                                        i = 1;
                                    } else {
                                        todayDateStr2 = todayDateStrMdy3;
                                    }
                                } else {
                                    todayDateStrMdy3 = todayDateStr2;
                                }
                                z = false;
                                if (z) {
                                    i = 1;
                                } else {
                                    todayDateStr2 = todayDateStrMdy3;
                                }
                            } else {
                                todayDateStrMdy3 = todayDateStr2;
                                i = 0;
                            }
                        }
                    }
                    if (i == 0) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                        this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                        this.I$0 = i;
                        this.label = 3;
                        if (StudentViewModel.this.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$timestamp, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(StudentViewModel.this.getApplication(), this.$classroom.getCid());
                    }
                    ReminderNotificationHelper.INSTANCE.cancelTaskNotification(StudentViewModel.this.getApplication(), this.$taskId);
                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(StudentViewModel.this.getApplication());
                    return Unit.INSTANCE;
                case 3:
                    int i2 = this.I$0;
                    ResultKt.throwOnFailure($result);
                    ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(StudentViewModel.this.getApplication(), this.$classroom.getCid());
                    ReminderNotificationHelper.INSTANCE.cancelTaskNotification(StudentViewModel.this.getApplication(), this.$taskId);
                    ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(StudentViewModel.this.getApplication());
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void submitTaskScoreBle(TaskEntity task, int score) {
        Intrinsics.checkNotNullParameter(task, "task");
        ClassroomEntity classroom = this._registeredClassroom.getValue();
        StudentProfileEntity profile = this.currentProfile.getValue();
        if (classroom == null || profile == null) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07901(null), 3, null);
            return;
        }
        if (!this.bleManager.isBluetoothEnabled()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07912(null), 3, null);
            return;
        }
        if (!this._isRegisteredSessionActive.getValue().booleanValue()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07923(null), 3, null);
            return;
        }
        this._taskSubmitTargetTask.setValue(task);
        this._taskSubmitScore.setValue(Integer.valueOf(score));
        this._taskSubmitMarkedTimestamp.setValue(null);
        this._taskSubmitState.setValue(StudentTaskSubmitState.DISCOVERING);
        this._taskSubmitMessage.setValue("Searching for classroom: " + classroom.getClassroomName() + "...");
        this._taskSubmitLogs.setValue(CollectionsKt.listOf((Object[]) new String[]{"Task submission initiated for \"" + task.getTitle() + "\" (ID: " + task.getTkid() + ")", "Score to submit: " + score, "Searching for classroom " + classroom.getClassroomName() + "..."}));
        this.bleManager.stopScan();
        BleManager.startScan$default(this.bleManager, false, 1, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07934(classroom, this, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$1", f = "StudentViewModel.kt", i = {}, l = {840}, m = "invokeSuspend", n = {}, s = {})
    static final class C07901 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07901(Continuation<? super C07901> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07901(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07901) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Join a classroom first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$2", f = "StudentViewModel.kt", i = {}, l = {847}, m = "invokeSuspend", n = {}, s = {})
    static final class C07912 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07912(Continuation<? super C07912> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07912(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07912) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Enable Bluetooth first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$3", f = "StudentViewModel.kt", i = {}, l = {854}, m = "invokeSuspend", n = {}, s = {})
    static final class C07923 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07923(Continuation<? super C07923> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07923(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07923) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Calis Device session is currently inactive or device not detected", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$4, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$submitTaskScoreBle$4", f = "StudentViewModel.kt", i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4}, l = {889, 907, 917, 928, 941}, m = "invokeSuspend", n = {"targetMac", "targetName", "devices", "found", "startTime", "targetMac", "targetName", "foundAddress", "startTime", "connected", "attempt", "targetMac", "targetName", "foundAddress", "startTime", "connected", "attempt", "connStart", "targetMac", "targetName", "foundAddress", "startTime", "connected", "subStart", "targetMac", "targetName", "foundAddress", "startTime", "connected"}, s = {"L$0", "L$1", "L$2", "L$3", "J$0", "L$0", "L$1", "L$2", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "J$0", "I$0", "I$1", "J$1", "L$0", "L$1", "L$2", "J$0", "I$0", "J$1", "L$0", "L$1", "L$2", "J$0", "I$0"})
    static final class C07934 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        int I$0;
        int I$1;
        long J$0;
        long J$1;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        final /* synthetic */ StudentViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07934(ClassroomEntity classroomEntity, StudentViewModel studentViewModel, Continuation<? super C07934> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
            this.this$0 = studentViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C07934(this.$classroom, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07934) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:120:0x0151 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:122:0x014e A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:14:0x00db  */
        /* JADX WARN: Code duplicated, block: B:19:0x0106  */
        /* JADX WARN: Code duplicated, block: B:21:0x0118  */
        /* JADX WARN: Code duplicated, block: B:25:0x0122  */
        /* JADX WARN: Code duplicated, block: B:27:0x0126  */
        /* JADX WARN: Code duplicated, block: B:29:0x0130  */
        /* JADX WARN: Code duplicated, block: B:31:0x0135  */
        /* JADX WARN: Code duplicated, block: B:35:0x013f  */
        /* JADX WARN: Code duplicated, block: B:37:0x0142  */
        /* JADX WARN: Code duplicated, block: B:45:0x0159  */
        /* JADX WARN: Code duplicated, block: B:46:0x015e  */
        /* JADX WARN: Code duplicated, block: B:48:0x017d A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:49:0x017e  */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r1v9 */
        /* JADX WARN: Type inference failed for: r21v2 */
        /* JADX WARN: Type inference failed for: r21v3 */
        /* JADX WARN: Type inference failed for: r21v5 */
        /* JADX WARN: Type inference failed for: r22v0 */
        /* JADX WARN: Type inference failed for: r22v1 */
        /* JADX WARN: Type inference failed for: r22v2 */
        /* JADX WARN: Type inference failed for: r22v3 */
        /* JADX WARN: Type inference failed for: r4v10 */
        /* JADX WARN: Type inference failed for: r4v14 */
        /* JADX WARN: Type inference failed for: r4v9 */
        /* JADX WARN: Type inference failed for: r9v0 */
        /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
        /* JADX WARN: Type inference failed for: r9v2 */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x017e -> B:50:0x0183). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:68:0x0273 -> B:69:0x0285). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:77:0x02d0 -> B:78:0x02d2). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r26) {
            /*
                Method dump skipped, instruction units count: 1162
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.StudentViewModel.C07934.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    /* JADX WARN: Code duplicated, block: B:33:0x009e  */
    public final void manualRefresh() {
        Object next;
        String stateDescription;
        boolean z;
        ClassroomEntity classroom = this._registeredClassroom.getValue();
        if (classroom == null) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07811(null), 3, null);
            return;
        }
        String targetMac = classroom.getDeviceAddress();
        String targetName = classroom.getClassroomName();
        if (!this.bleManager.isBluetoothEnabled()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07822(null), 3, null);
            return;
        }
        triggerManualRefresh();
        Iterator<T> it = this.scannedDevices.getValue().iterator();
        do {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            BleManager.ScannedDevice scannedDevice = (BleManager.ScannedDevice) next;
            String str = targetMac;
            if ((str == null || StringsKt.isBlank(str)) || !StringsKt.equals(scannedDevice.getAddress(), targetMac, true)) {
                String str2 = targetName;
                if ((str2 == null || StringsKt.isBlank(str2)) || !StringsKt.equals(scannedDevice.getName(), targetName, true)) {
                    z = false;
                } else {
                    z = true;
                }
            } else {
                z = true;
            }
        } while (!z);
        BleManager.ScannedDevice device = (BleManager.ScannedDevice) next;
        if (device == null) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07833(null), 3, null);
            return;
        }
        String str3 = targetMac;
        boolean isExpired = !(str3 == null || StringsKt.isBlank(str3)) && StringsKt.equals(device.getAddress(), targetMac, true) && (device.getState() == DeviceState.FACTORY_MODE || !(device.getName() == null || StringsKt.equals(device.getName(), targetName, true)));
        if (isExpired) {
            if (!this._isClassroomExpired.getValue().booleanValue()) {
                this._isClassroomExpired.setValue(true);
                this._showClassroomExpiredDialog.setValue(true);
            }
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07844(null), 3, null);
            this.bleManager.disconnect();
            return;
        }
        if (device.getState() != DeviceState.SESSION_ACTIVE_OPEN) {
            switch (WhenMappings.$EnumSwitchMapping$0[device.getState().ordinal()]) {
                case 1:
                    stateDescription = "Session Inactive (0xFF01) — Waiting for teacher to start session";
                    break;
                case 2:
                    stateDescription = "Authenticate/Idle (0xFF00) — Teacher authentication pending";
                    break;
                case 3:
                    stateDescription = "Session Busy (0x0111) — All student slots occupied";
                    break;
                case 4:
                    stateDescription = "Registering (0xF1FF)";
                    break;
                case 5:
                    stateDescription = "Factory Mode (0xFFFF)";
                    break;
                default:
                    stateDescription = "State " + device.getState().getDisplayName();
                    break;
            }
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass5(stateDescription, null), 3, null);
            this.bleManager.disconnect();
            return;
        }
        String str4 = targetMac;
        String connectAddress = !(str4 == null || StringsKt.isBlank(str4)) ? targetMac : device.getAddress();
        this._syncState.setValue(StudentSyncState.CONNECTING);
        this._syncMessage.setValue("Connecting to " + device.getName() + " (Session Active 0x0011)...");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass6(connectAddress, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$1", f = "StudentViewModel.kt", i = {}, l = {958}, m = "invokeSuspend", n = {}, s = {})
    static final class C07811 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07811(Continuation<? super C07811> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07811(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07811) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Join a classroom first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$2", f = "StudentViewModel.kt", i = {}, l = {967}, m = "invokeSuspend", n = {}, s = {})
    static final class C07822 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07822(Continuation<? super C07822> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07822(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07822) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Enable Bluetooth first", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$3", f = "StudentViewModel.kt", i = {}, l = {982}, m = "invokeSuspend", n = {}, s = {})
    static final class C07833 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07833(Continuation<? super C07833> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07833(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07833) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Please move closer to the Calis Device", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$4, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$4", f = "StudentViewModel.kt", i = {}, l = {997}, m = "invokeSuspend", n = {}, s = {})
    static final class C07844 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07844(Continuation<? super C07844> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07844(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07844) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Classroom has Expired", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$5, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$5", f = "StudentViewModel.kt", i = {}, l = {PointerIconCompat.TYPE_HORIZONTAL_DOUBLE_ARROW}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass5 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $stateDescription;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass5(String str, Continuation<? super AnonymousClass5> continuation) {
            super(2, continuation);
            this.$stateDescription = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass5(this.$stateDescription, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass5) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    MutableSharedFlow mutableSharedFlow = StudentViewModel.this._userMessage;
                    String str = this.$stateDescription;
                    this.label = 1;
                    if (mutableSharedFlow.emit("Cannot connect: Calis Device is in " + str, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$manualRefresh$6, reason: invalid class name */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$manualRefresh$6", f = "StudentViewModel.kt", i = {}, l = {1026}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass6 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $connectAddress;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass6(String str, Continuation<? super AnonymousClass6> continuation) {
            super(2, continuation);
            this.$connectAddress = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new AnonymousClass6(this.$connectAddress, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass6) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (StudentViewModel.this._userMessage.emit("Syncing", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            StudentViewModel.this.getBleManager().stopScan();
            StudentViewModel.this.isManualConnectAllowed = true;
            StudentViewModel.this.connectToDevice(this.$connectAddress);
            return Unit.INSTANCE;
        }
    }

    public final void dismissSyncBanner() {
        this._syncState.setValue(StudentSyncState.IDLE);
        this._syncMessage.setValue("");
        this.bleManager.clearBleObject();
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: StudentViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1", f = "StudentViewModel.kt", i = {}, l = {1042}, m = "invokeSuspend", n = {}, s = {})
    static final class C07861 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07861(Continuation<? super C07861> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return StudentViewModel.this.new C07861(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07861) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    SharedFlow<BlePacket> incomingPackets = StudentViewModel.this.getBleManager().getIncomingPackets();
                    final StudentViewModel studentViewModel = StudentViewModel.this;
                    this.label = 1;
                    if (incomingPackets.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.StudentViewModel.observeIncomingPackets.1.1

                        /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1, reason: invalid class name and collision with other inner class name */
                        /* JADX INFO: compiled from: StudentViewModel.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1", f = "StudentViewModel.kt", i = {1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 7, 7, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 10, 10, 12, 12, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 16, 16, 16}, l = {1049, 1063, 1069, 1080, 1091, 1101, 1109, 1112, 1133, 1141, 1155, 1163, 1180, 1190, 1208, 1235, 1281, 1310}, m = "invokeSuspend", n = {"classroom", "classroom", "todayDateStr", Scopes.PROFILE, "mySid", "classroom", "todayDateStr", Scopes.PROFILE, "mySid", "existingLogs", "attendance", "alreadyCheckedIn", "classroom", "todayDateStr", Scopes.PROFILE, Scopes.PROFILE, "classroom", Scopes.PROFILE, "classroom", "graceTimeStr", "calendar", "attendanceStatus", "graceMins", "currentMinutes", Scopes.PROFILE, "classroom", "graceTimeStr", "calendar", "attendanceStatus", "graceMins", "currentMinutes", Scopes.PROFILE, "classroom", "current", "updated", "classroom", "classroom", "taskDesc", "task", "classroom", "taskDesc", "task", "targetTask", Scopes.PROFILE, "classroom", "submitMsg", "epochSeconds", "score"}, s = {"L$0", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "I$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$0", "L$1", "L$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "J$0", "I$0"})
                        static final class C01661 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ BlePacket $packet;
                            int I$0;
                            int I$1;
                            long J$0;
                            Object L$0;
                            Object L$1;
                            Object L$2;
                            Object L$3;
                            Object L$4;
                            Object L$5;
                            int label;
                            final /* synthetic */ StudentViewModel this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            C01661(BlePacket blePacket, StudentViewModel studentViewModel, Continuation<? super C01661> continuation) {
                                super(2, continuation);
                                this.$packet = blePacket;
                                this.this$0 = studentViewModel;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new C01661(this.$packet, this.this$0, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                return ((C01661) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            /* JADX WARN: Code duplicated, block: B:100:0x049a A[ADDED_TO_REGION] */
                            /* JADX WARN: Code duplicated, block: B:102:0x049f  */
                            /* JADX WARN: Code duplicated, block: B:105:0x04af  */
                            /* JADX WARN: Code duplicated, block: B:113:0x050b A[ADDED_TO_REGION, REMOVE] */
                            /* JADX WARN: Code duplicated, block: B:116:0x0567 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:117:0x0568  */
                            /* JADX WARN: Code duplicated, block: B:121:0x0573  */
                            /* JADX WARN: Code duplicated, block: B:124:0x05ac A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:125:0x05ad  */
                            /* JADX WARN: Code duplicated, block: B:149:0x0694  */
                            /* JADX WARN: Code duplicated, block: B:160:0x06f3  */
                            /* JADX WARN: Code duplicated, block: B:162:0x06fe  */
                            /* JADX WARN: Code duplicated, block: B:164:0x0701  */
                            /* JADX WARN: Code duplicated, block: B:167:0x0718  */
                            /* JADX WARN: Code duplicated, block: B:170:0x0757  */
                            /* JADX WARN: Code duplicated, block: B:171:0x075c  */
                            /* JADX WARN: Code duplicated, block: B:174:0x0786 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:175:0x0787  */
                            /* JADX WARN: Code duplicated, block: B:178:0x07a8  */
                            /* JADX WARN: Code duplicated, block: B:199:0x0834  */
                            /* JADX WARN: Code duplicated, block: B:201:0x084e  */
                            /* JADX WARN: Code duplicated, block: B:204:0x0859  */
                            /* JADX WARN: Code duplicated, block: B:207:0x0863  */
                            /* JADX WARN: Code duplicated, block: B:212:0x087e  */
                            /* JADX WARN: Code duplicated, block: B:215:0x08a9  */
                            /* JADX WARN: Code duplicated, block: B:217:0x08b8  */
                            /* JADX WARN: Code duplicated, block: B:220:0x08c3  */
                            /* JADX WARN: Code duplicated, block: B:223:0x08cd  */
                            /* JADX WARN: Code duplicated, block: B:228:0x08e7  */
                            /* JADX WARN: Code duplicated, block: B:230:0x0924  */
                            /* JADX WARN: Code duplicated, block: B:232:0x0930  */
                            /* JADX WARN: Code duplicated, block: B:234:0x093e  */
                            /* JADX WARN: Code duplicated, block: B:236:0x094f  */
                            /* JADX WARN: Code duplicated, block: B:239:0x095a  */
                            /* JADX WARN: Code duplicated, block: B:242:0x0964  */
                            /* JADX WARN: Code duplicated, block: B:247:0x097e  */
                            /* JADX WARN: Code duplicated, block: B:250:0x09a5  */
                            /* JADX WARN: Code duplicated, block: B:253:0x09ee A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:254:0x09ef  */
                            /* JADX WARN: Code duplicated, block: B:310:0x0ce6  */
                            /* JADX WARN: Code duplicated, block: B:314:0x0d02  */
                            /* JADX WARN: Code duplicated, block: B:31:0x022d A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:322:0x08e4 A[SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:324:0x097b A[SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:327:0x0879 A[SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:328:0x087b A[SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:329:? A[LOOP:3: B:205:0x085d->B:329:?, LOOP_END, SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:331:0x02c3 A[SYNTHETIC] */
                            /* JADX WARN: Code duplicated, block: B:34:0x0250  */
                            /* JADX WARN: Code duplicated, block: B:36:0x027e A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:37:0x027f  */
                            /* JADX WARN: Code duplicated, block: B:40:0x028c  */
                            /* JADX WARN: Code duplicated, block: B:43:0x0297  */
                            /* JADX WARN: Code duplicated, block: B:46:0x02a1  */
                            /* JADX WARN: Code duplicated, block: B:48:0x02b3  */
                            /* JADX WARN: Code duplicated, block: B:51:0x02bf  */
                            /* JADX WARN: Code duplicated, block: B:57:0x02c7  */
                            /* JADX WARN: Code duplicated, block: B:59:0x033c A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:60:0x033d  */
                            /* JADX WARN: Code duplicated, block: B:62:0x035e  */
                            /* JADX WARN: Code duplicated, block: B:63:0x0365  */
                            /* JADX WARN: Code duplicated, block: B:66:0x0393 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:67:0x0394  */
                            /* JADX WARN: Code duplicated, block: B:88:0x043e  */
                            /* JADX WARN: Code duplicated, block: B:90:0x0459 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:93:0x045f  */
                            /* JADX WARN: Code duplicated, block: B:95:0x046b  */
                            /* JADX WARN: Code duplicated, block: B:97:0x046f A[ADDED_TO_REGION] */
                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Object invokeSuspend(Object $result) {
                                ClassroomEntity classroom;
                                Object activeBoundClassroomSync;
                                ClassroomEntity updated;
                                StudentProfileEntity value;
                                Object studentProfileOnce;
                                ClassroomEntity classroom2;
                                String todayDateStr;
                                StudentProfileEntity profile;
                                ClassroomEntity classroom3;
                                String todayDateStr2;
                                String mySid;
                                Object objFirst;
                                String mySid2;
                                Iterable existingLogs;
                                Iterable iterable;
                                Iterator<T> it;
                                AttendanceEntity attendanceEntity;
                                boolean z;
                                AttendanceEntity attendance;
                                String todayDateStr3;
                                StudentProfileEntity profile2;
                                String todayDateStr4;
                                StudentProfileEntity profile3;
                                ClassroomEntity classroom4;
                                ClassroomEntity classroom5;
                                StudentProfileEntity profile4;
                                Object activeBoundClassroomSync2;
                                String graceTimeStr;
                                int graceMins;
                                Calendar calendar;
                                int currentMinutes;
                                String attendanceStatus;
                                String attendanceStatus2;
                                String attendanceStatus3;
                                ClassroomEntity classroom6;
                                String taskDesc;
                                TaskEntity task;
                                Integer intOrNull;
                                int iIntValue;
                                ClassroomEntity classroom7;
                                TaskEntity task2;
                                String taskDesc2;
                                Iterable iterable2;
                                Iterator<T> it2;
                                boolean z2;
                                Object value2;
                                StudentCheckInState studentCheckInState;
                                StudentViewModel studentViewModel;
                                Iterable iterable3;
                                Iterator<T> it3;
                                Iterable iterable4;
                                Iterator<T> it4;
                                boolean z3;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                int i = 1;
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        BlePacket blePacket = this.$packet;
                                        if (blePacket instanceof BlePacket.RegApprovedResponse) {
                                            this.this$0._registrationStatus.setValue("APPROVED_WAITING_TASKS");
                                            this.this$0._regDialogStep.setValue(StudentRegDialogStep.SYNCHRONIZING);
                                            CalisRepository calisRepository = this.this$0.repository;
                                            String cid = ((BlePacket.RegApprovedResponse) this.$packet).getCid();
                                            this.label = 1;
                                            if (calisRepository.saveTeacher(new TeacherEntity("TEACHER_" + cid, ((BlePacket.RegApprovedResponse) this.$packet).getTc(), null, 0L, 12, null), this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            classroom2 = new ClassroomEntity(((BlePacket.RegApprovedResponse) this.$packet).getCid(), "TEACHER_" + ((BlePacket.RegApprovedResponse) this.$packet).getCid(), ((BlePacket.RegApprovedResponse) this.$packet).getCls(), ((BlePacket.RegApprovedResponse) this.$packet).getTc(), ((BlePacket.RegApprovedResponse) this.$packet).getDays(), ((BlePacket.RegApprovedResponse) this.$packet).getStart(), ((BlePacket.RegApprovedResponse) this.$packet).getGrace(), ((BlePacket.RegApprovedResponse) this.$packet).getEnd(), false, true, (String) this.this$0._registrationDeviceAddress.getValue(), 256, null);
                                            this.this$0._registeredClassroom.setValue(classroom2);
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                            this.label = 2;
                                            if (this.this$0.repository.saveClassroom(classroom2, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                            profile = this.this$0.getCurrentProfile().getValue();
                                            if (profile != null) {
                                                mySid = profile.getSid();
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                                this.L$1 = todayDateStr;
                                                this.L$2 = profile;
                                                this.L$3 = mySid;
                                                this.label = 3;
                                                objFirst = FlowKt.first(this.this$0.repository.getAttendanceForClassroom(((BlePacket.RegApprovedResponse) this.$packet).getCid()), this);
                                                if (objFirst == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                classroom3 = classroom2;
                                                mySid2 = mySid;
                                                existingLogs = (List) objFirst;
                                                iterable = existingLogs;
                                                if ((iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                                                    it = iterable.iterator();
                                                    do {
                                                        if (it.hasNext()) {
                                                            attendanceEntity = (AttendanceEntity) it.next();
                                                            if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr) || !Intrinsics.areEqual(attendanceEntity.getStudentId(), mySid2)) {
                                                                z = false;
                                                            } else {
                                                                z = true;
                                                            }
                                                        } else {
                                                            i = 0;
                                                        }
                                                    } while (!z);
                                                } else {
                                                    i = 0;
                                                }
                                                if (i == 0) {
                                                    String cid2 = ((BlePacket.RegApprovedResponse) this.$packet).getCid();
                                                    String fullName = profile.getFullName();
                                                    Intrinsics.checkNotNull(todayDateStr);
                                                    String mySid3 = mySid2;
                                                    todayDateStr3 = todayDateStr;
                                                    attendance = new AttendanceEntity(0L, cid2, mySid3, fullName, todayDateStr3, "PRESENT", System.currentTimeMillis() / 1000, 1, null);
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                                    this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr3);
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(mySid3);
                                                    this.L$4 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                    this.L$5 = SpillingKt.nullOutSpilledVariable(attendance);
                                                    this.I$0 = i;
                                                    this.label = 4;
                                                    if (this.this$0.repository.recordStudentAttendance(attendance.getClassroomId(), attendance.getStudentId(), attendance.getStudentName(), attendance.getStatus(), attendance.getTimestamp(), this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    profile2 = profile;
                                                    todayDateStr4 = todayDateStr3;
                                                    ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), ((BlePacket.RegApprovedResponse) this.$packet).getCid());
                                                    profile = profile2;
                                                    todayDateStr2 = todayDateStr4;
                                                } else {
                                                    todayDateStr2 = todayDateStr;
                                                }
                                            } else {
                                                classroom3 = classroom2;
                                                todayDateStr2 = todayDateStr;
                                            }
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr2);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                            this.L$3 = null;
                                            this.L$4 = null;
                                            this.L$5 = null;
                                            this.label = 5;
                                            if (this.this$0._userMessage.emit("Request approved!", this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            Unit unit = Unit.INSTANCE;
                                            return Unit.INSTANCE;
                                        }
                                        if (blePacket instanceof BlePacket.RegRejectedResponse) {
                                            this.this$0._registrationStatus.setValue("REJECTED");
                                            this.this$0._regDialogStep.setValue(StudentRegDialogStep.REJECTED);
                                            if (this.this$0._checkInState.getValue() != StudentCheckInState.IDLE) {
                                                this.this$0._checkInState.setValue(StudentCheckInState.FAILED);
                                                this.this$0._checkInMessage.setValue("Registration was rejected/not approved by the Teacher.");
                                            }
                                            this.label = 6;
                                            if (this.this$0._userMessage.emit("Request failed", this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new C01671(this.this$0, null), 3, null);
                                            return Unit.INSTANCE;
                                        }
                                        if (blePacket instanceof BlePacket.AtdAcceptedResponse) {
                                            value = this.this$0.getCurrentProfile().getValue();
                                            if (value == null) {
                                                this.label = 7;
                                                studentProfileOnce = this.this$0.repository.getStudentProfileOnce(this);
                                                if (studentProfileOnce == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                value = (StudentProfileEntity) studentProfileOnce;
                                                profile3 = value;
                                                classroom4 = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                                if (classroom4 == null) {
                                                    this.L$0 = profile3;
                                                    this.L$1 = SpillingKt.nullOutSpilledVariable(classroom4);
                                                    this.label = 8;
                                                    activeBoundClassroomSync2 = this.this$0.repository.getActiveBoundClassroomSync(this);
                                                    if (activeBoundClassroomSync2 == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    classroom6 = (ClassroomEntity) activeBoundClassroomSync2;
                                                    if (classroom6 != null) {
                                                        this.this$0._registeredClassroom.setValue(classroom6);
                                                    }
                                                    classroom5 = classroom6;
                                                    profile4 = profile3;
                                                } else {
                                                    classroom5 = classroom4;
                                                    profile4 = profile3;
                                                }
                                            } else {
                                                profile3 = value;
                                                classroom4 = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                                if (classroom4 == null) {
                                                    this.L$0 = profile3;
                                                    this.L$1 = SpillingKt.nullOutSpilledVariable(classroom4);
                                                    this.label = 8;
                                                    activeBoundClassroomSync2 = this.this$0.repository.getActiveBoundClassroomSync(this);
                                                    if (activeBoundClassroomSync2 == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    classroom6 = (ClassroomEntity) activeBoundClassroomSync2;
                                                    if (classroom6 != null) {
                                                        this.this$0._registeredClassroom.setValue(classroom6);
                                                    }
                                                    classroom5 = classroom6;
                                                    profile4 = profile3;
                                                } else {
                                                    classroom5 = classroom4;
                                                    profile4 = profile3;
                                                }
                                            }
                                            if (profile4 != null && classroom5 != null) {
                                                graceTimeStr = classroom5.getGraceTime();
                                                graceMins = this.this$0.parseTimeToMinutes(graceTimeStr);
                                                calendar = Calendar.getInstance();
                                                calendar.setTimeInMillis(((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp() * 1000);
                                                currentMinutes = (calendar.get(11) * 60) + calendar.get(12);
                                                if (graceMins != -1 || currentMinutes <= graceMins) {
                                                    attendanceStatus = "PRESENT";
                                                } else {
                                                    attendanceStatus = "LATE";
                                                }
                                                if (this.this$0._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT || this.this$0._checkInState.getValue() == StudentCheckInState.CHECKING_IN) {
                                                    this.this$0._checkInState.setValue(StudentCheckInState.RECEIVING_TASKS);
                                                    this.this$0._checkInMessage.setValue("Check-In Accepted by Teacher! Syncing tasks...");
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                                    this.L$1 = classroom5;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(graceTimeStr);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(calendar);
                                                    this.L$4 = attendanceStatus;
                                                    this.I$0 = graceMins;
                                                    this.I$1 = currentMinutes;
                                                    this.label = 9;
                                                    attendanceStatus2 = attendanceStatus;
                                                    if (this.this$0.repository.recordStudentAttendance(classroom5.getCid(), profile4.getSid(), profile4.getFullName(), attendanceStatus2, ((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp(), this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    attendanceStatus3 = attendanceStatus2;
                                                } else {
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                                    this.L$1 = classroom5;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(graceTimeStr);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(calendar);
                                                    this.L$4 = attendanceStatus;
                                                    this.I$0 = graceMins;
                                                    this.I$1 = currentMinutes;
                                                    this.label = 10;
                                                    String attendanceStatus4 = attendanceStatus;
                                                    if (this.this$0.repository.recordStudentAttendance(classroom5.getCid(), profile4.getSid(), profile4.getFullName(), attendanceStatus4, ((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp(), this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    attendanceStatus3 = attendanceStatus4;
                                                }
                                                if (Intrinsics.areEqual(attendanceStatus3, "PRESENT")) {
                                                    ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), classroom5.getCid());
                                                }
                                            }
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(classroom5);
                                            this.L$2 = null;
                                            this.L$3 = null;
                                            this.L$4 = null;
                                            this.label = 11;
                                            if (this.this$0._userMessage.emit("Checked-in", this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            Unit unit2 = Unit.INSTANCE;
                                            return Unit.INSTANCE;
                                        }
                                        if (blePacket instanceof BlePacket.AtdRejectedResponse) {
                                            if (this.this$0._checkInState.getValue() == StudentCheckInState.WAITING_FOR_ACCEPT || this.this$0._checkInState.getValue() == StudentCheckInState.CHECKING_IN) {
                                                this.this$0._checkInState.setValue(StudentCheckInState.FAILED);
                                                this.this$0._checkInMessage.setValue("The classroom has now been deleted");
                                            }
                                            this.label = 12;
                                            if (this.this$0._userMessage.emit("Classroom has expired", this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass2(this.this$0, null), 3, null);
                                            return Unit.INSTANCE;
                                        }
                                        if (blePacket instanceof BlePacket.SchedResponse) {
                                            ClassroomEntity current = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                            if (current != null) {
                                                ClassroomEntity updated2 = ClassroomEntity.copy$default(current, null, null, null, null, ((BlePacket.SchedResponse) this.$packet).getDays(), ((BlePacket.SchedResponse) this.$packet).getStart(), ((BlePacket.SchedResponse) this.$packet).getGrace(), ((BlePacket.SchedResponse) this.$packet).getEnd(), false, false, null, 1807, null);
                                                this.this$0._registeredClassroom.setValue(updated2);
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(current);
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(updated2);
                                                this.label = 13;
                                                if (this.this$0.repository.saveClassroom(updated2, this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                updated = current;
                                            }
                                            if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                                this.this$0._syncMessage.setValue("Classroom schedule updated (" + ((BlePacket.SchedResponse) this.$packet).getDays() + ").");
                                            }
                                            Unit unit3 = Unit.INSTANCE;
                                            return Unit.INSTANCE;
                                        }
                                        if (!(blePacket instanceof BlePacket.TaskCommand)) {
                                            if (blePacket instanceof BlePacket.MarkedResponse) {
                                                long epochSeconds = ((BlePacket.MarkedResponse) this.$packet).getTimestamp() <= 0 ? System.currentTimeMillis() / 1000 : ((BlePacket.MarkedResponse) this.$packet).getTimestamp();
                                                this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "TX -> MARKED|" + epochSeconds + " received from Teacher!"));
                                                TaskEntity targetTask = (TaskEntity) this.this$0._taskSubmitTargetTask.getValue();
                                                int score = ((Number) this.this$0._taskSubmitScore.getValue()).intValue();
                                                StudentProfileEntity profile5 = this.this$0.getCurrentProfile().getValue();
                                                ClassroomEntity classroom8 = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                                if (targetTask != null && profile5 != null) {
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass7(this.this$0, targetTask, profile5, score, epochSeconds, classroom8, null), 3, null);
                                                }
                                                this.this$0._taskSubmitMarkedTimestamp.setValue(Boxing.boxLong(epochSeconds));
                                                this.this$0._taskSubmitState.setValue(StudentTaskSubmitState.SUCCESS);
                                                this.this$0._taskSubmitMessage.setValue("Task Marked! Score (" + score + ") recorded successfully.");
                                                this.this$0._taskSubmitLogs.setValue(CollectionsKt.plus((Collection<? extends String>) this.this$0._taskSubmitLogs.getValue(), "Task successfully marked by Teacher."));
                                                String submitMsg = score > 0 ? score + " Submitted!" : "Task Mark Submitted!";
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(targetTask);
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(profile5);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(classroom8);
                                                this.L$3 = SpillingKt.nullOutSpilledVariable(submitMsg);
                                                this.J$0 = epochSeconds;
                                                this.I$0 = score;
                                                this.label = 17;
                                                if (this.this$0._userMessage.emit(submitMsg, this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                Unit unit4 = Unit.INSTANCE;
                                                return Unit.INSTANCE;
                                            }
                                            if (blePacket instanceof BlePacket.DoneResponse) {
                                                if (Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_TASKS") || Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "RECEIVING_TASKS") || Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_DONE")) {
                                                    this.this$0._registrationStatus.setValue("APPROVED");
                                                    this.this$0._regDialogStep.setValue(StudentRegDialogStep.SUCCESS);
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass8(this.this$0, null), 3, null);
                                                } else if (Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "PENDING")) {
                                                    this.this$0.handleJoinConnectionFailure("Registration was not approved by Teacher.");
                                                }
                                                if (this.this$0._checkInState.getValue() == StudentCheckInState.RECEIVING_TASKS || this.this$0._checkInState.getValue() == StudentCheckInState.WAITING_FOR_ACCEPT || this.this$0._checkInState.getValue() == StudentCheckInState.CHECKING_IN) {
                                                    this.this$0._checkInState.setValue(StudentCheckInState.SUCCESS);
                                                    boolean zIsEmpty = ((List) this.this$0._checkInTasks.getValue()).isEmpty();
                                                    StudentViewModel studentViewModel2 = this.this$0;
                                                    if (zIsEmpty) {
                                                        studentViewModel2._checkInMessage.setValue("Attendance Marked! Finished taking attendance.");
                                                    } else {
                                                        studentViewModel2._checkInMessage.setValue("Attendance Marked! Finished taking attendance. (" + ((List) this.this$0._checkInTasks.getValue()).size() + " task" + (((List) this.this$0._checkInTasks.getValue()).size() > 1 ? "s" : "") + " synced)");
                                                    }
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass9(this.this$0, null), 3, null);
                                                }
                                                if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                                    this.this$0._syncState.setValue(StudentSyncState.SUCCESS);
                                                    this.this$0._syncMessage.setValue("Synchronization completed successfully!");
                                                    this.label = 18;
                                                    if (this.this$0._userMessage.emit("Synced Successfully!", this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass10(this.this$0, null), 3, null);
                                                    if (this.this$0._taskSubmitState.getValue() != StudentTaskSubmitState.SUBMITTING || this.this$0._taskSubmitState.getValue() == StudentTaskSubmitState.SUCCESS || this.this$0._taskSubmitState.getValue() == StudentTaskSubmitState.WAITING_FOR_MARKED) {
                                                        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass11(this.this$0, null), 3, null);
                                                    }
                                                } else if (this.this$0._taskSubmitState.getValue() != StudentTaskSubmitState.SUBMITTING) {
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass11(this.this$0, null), 3, null);
                                                } else {
                                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass11(this.this$0, null), 3, null);
                                                }
                                            }
                                            Unit unit5 = Unit.INSTANCE;
                                            return Unit.INSTANCE;
                                        }
                                        classroom = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                        if (classroom == null) {
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                            this.label = 14;
                                            activeBoundClassroomSync = this.this$0.repository.getActiveBoundClassroomSync(this);
                                            if (activeBoundClassroomSync == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            classroom = (ClassroomEntity) activeBoundClassroomSync;
                                            if (classroom != null) {
                                                this.this$0._registeredClassroom.setValue(classroom);
                                            }
                                        }
                                        if (classroom == null) {
                                            return Unit.INSTANCE;
                                        }
                                        taskDesc = StringsKt.equals(((BlePacket.TaskCommand) this.$packet).getDesc(), ((BlePacket.TaskCommand) this.$packet).getTitle(), true) ? "" : ((BlePacket.TaskCommand) this.$packet).getDesc();
                                        String tkid = ((BlePacket.TaskCommand) this.$packet).getTkid();
                                        String cid3 = classroom.getCid();
                                        String title = ((BlePacket.TaskCommand) this.$packet).getTitle();
                                        long deadline = ((BlePacket.TaskCommand) this.$packet).getDeadline();
                                        long datePosted = ((BlePacket.TaskCommand) this.$packet).getDatePosted();
                                        intOrNull = StringsKt.toIntOrNull(((BlePacket.TaskCommand) this.$packet).getScore());
                                        if (intOrNull != null) {
                                            iIntValue = intOrNull.intValue();
                                        } else {
                                            iIntValue = 100;
                                        }
                                        task = new TaskEntity(tkid, cid3, title, taskDesc, deadline, datePosted, iIntValue);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(taskDesc);
                                        this.L$2 = task;
                                        this.label = 15;
                                        if (this.this$0.repository.saveTask(task, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        classroom7 = classroom;
                                        task2 = task;
                                        taskDesc2 = taskDesc;
                                        ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                        if (!Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_TASKS") || Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "RECEIVING_TASKS") || Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_DONE")) {
                                            this.this$0._registrationStatus.setValue("RECEIVING_TASKS");
                                            iterable2 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if ((iterable2 instanceof Collection) || !((Collection) iterable2).isEmpty()) {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            } else {
                                                z2 = false;
                                            }
                                            if (!z2) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        } else if (Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "PENDING")) {
                                            Iterable iterable5 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if ((iterable5 instanceof Collection) && ((Collection) iterable5).isEmpty()) {
                                                z3 = false;
                                            } else {
                                                Iterator<T> it5 = iterable5.iterator();
                                                while (true) {
                                                    if (!it5.hasNext()) {
                                                        z3 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it5.next()).getTkid(), task2.getTkid())) {
                                                        z3 = true;
                                                    }
                                                }
                                            }
                                            if (!z3) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        }
                                        value2 = this.this$0._checkInState.getValue();
                                        studentCheckInState = StudentCheckInState.RECEIVING_TASKS;
                                        studentViewModel = this.this$0;
                                        if (value2 == studentCheckInState) {
                                            iterable4 = (Iterable) studentViewModel._checkInTasks.getValue();
                                            if ((iterable4 instanceof Collection) || !((Collection) iterable4).isEmpty()) {
                                                it4 = iterable4.iterator();
                                                do {
                                                    if (!it4.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it4.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                i = 0;
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                            this.this$0._checkInMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        } else if (studentViewModel._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT || this.this$0._checkInState.getValue() == StudentCheckInState.CHECKING_IN) {
                                            iterable3 = (Iterable) this.this$0._checkInTasks.getValue();
                                            if ((iterable3 instanceof Collection) || !((Collection) iterable3).isEmpty()) {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                i = 0;
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                        }
                                        if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                            this.this$0._syncMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom7);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(taskDesc2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(task2);
                                        this.label = 16;
                                        if (this.this$0._userMessage.emit("New Task Received", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit6 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        classroom2 = new ClassroomEntity(((BlePacket.RegApprovedResponse) this.$packet).getCid(), "TEACHER_" + ((BlePacket.RegApprovedResponse) this.$packet).getCid(), ((BlePacket.RegApprovedResponse) this.$packet).getCls(), ((BlePacket.RegApprovedResponse) this.$packet).getTc(), ((BlePacket.RegApprovedResponse) this.$packet).getDays(), ((BlePacket.RegApprovedResponse) this.$packet).getStart(), ((BlePacket.RegApprovedResponse) this.$packet).getGrace(), ((BlePacket.RegApprovedResponse) this.$packet).getEnd(), false, true, (String) this.this$0._registrationDeviceAddress.getValue(), 256, null);
                                        this.this$0._registeredClassroom.setValue(classroom2);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                        this.label = 2;
                                        if (this.this$0.repository.saveClassroom(classroom2, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                        profile = this.this$0.getCurrentProfile().getValue();
                                        if (profile != null) {
                                            mySid = profile.getSid();
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                            this.L$1 = todayDateStr;
                                            this.L$2 = profile;
                                            this.L$3 = mySid;
                                            this.label = 3;
                                            objFirst = FlowKt.first(this.this$0.repository.getAttendanceForClassroom(((BlePacket.RegApprovedResponse) this.$packet).getCid()), this);
                                            if (objFirst == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            classroom3 = classroom2;
                                            mySid2 = mySid;
                                            existingLogs = (List) objFirst;
                                            iterable = existingLogs;
                                            if (iterable instanceof Collection) {
                                                it = iterable.iterator();
                                                do {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                            z = false;
                                                        } else {
                                                            z = false;
                                                        }
                                                    } else {
                                                        i = 0;
                                                    }
                                                } while (!z);
                                            } else {
                                                it = iterable.iterator();
                                                do {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                            z = false;
                                                        } else {
                                                            z = false;
                                                        }
                                                    } else {
                                                        i = 0;
                                                    }
                                                } while (!z);
                                            }
                                            if (i == 0) {
                                                String cid4 = ((BlePacket.RegApprovedResponse) this.$packet).getCid();
                                                String fullName2 = profile.getFullName();
                                                Intrinsics.checkNotNull(todayDateStr);
                                                String mySid4 = mySid2;
                                                todayDateStr3 = todayDateStr;
                                                attendance = new AttendanceEntity(0L, cid4, mySid4, fullName2, todayDateStr3, "PRESENT", System.currentTimeMillis() / 1000, 1, null);
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr3);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                                this.L$3 = SpillingKt.nullOutSpilledVariable(mySid4);
                                                this.L$4 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                this.L$5 = SpillingKt.nullOutSpilledVariable(attendance);
                                                this.I$0 = i;
                                                this.label = 4;
                                                if (this.this$0.repository.recordStudentAttendance(attendance.getClassroomId(), attendance.getStudentId(), attendance.getStudentName(), attendance.getStatus(), attendance.getTimestamp(), this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                profile2 = profile;
                                                todayDateStr4 = todayDateStr3;
                                                ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), ((BlePacket.RegApprovedResponse) this.$packet).getCid());
                                                profile = profile2;
                                                todayDateStr2 = todayDateStr4;
                                            } else {
                                                todayDateStr2 = todayDateStr;
                                            }
                                        } else {
                                            classroom3 = classroom2;
                                            todayDateStr2 = todayDateStr;
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.L$5 = null;
                                        this.label = 5;
                                        if (this.this$0._userMessage.emit("Request approved!", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit7 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 2:
                                        classroom2 = (ClassroomEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                                        profile = this.this$0.getCurrentProfile().getValue();
                                        if (profile != null) {
                                            mySid = profile.getSid();
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                            this.L$1 = todayDateStr;
                                            this.L$2 = profile;
                                            this.L$3 = mySid;
                                            this.label = 3;
                                            objFirst = FlowKt.first(this.this$0.repository.getAttendanceForClassroom(((BlePacket.RegApprovedResponse) this.$packet).getCid()), this);
                                            if (objFirst == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            classroom3 = classroom2;
                                            mySid2 = mySid;
                                            existingLogs = (List) objFirst;
                                            iterable = existingLogs;
                                            if (iterable instanceof Collection) {
                                                it = iterable.iterator();
                                                do {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                            z = false;
                                                        } else {
                                                            z = false;
                                                        }
                                                    } else {
                                                        i = 0;
                                                    }
                                                } while (!z);
                                            } else {
                                                it = iterable.iterator();
                                                do {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                            z = false;
                                                        } else {
                                                            z = false;
                                                        }
                                                    } else {
                                                        i = 0;
                                                    }
                                                } while (!z);
                                            }
                                            if (i == 0) {
                                                String cid5 = ((BlePacket.RegApprovedResponse) this.$packet).getCid();
                                                String fullName3 = profile.getFullName();
                                                Intrinsics.checkNotNull(todayDateStr);
                                                String mySid5 = mySid2;
                                                todayDateStr3 = todayDateStr;
                                                attendance = new AttendanceEntity(0L, cid5, mySid5, fullName3, todayDateStr3, "PRESENT", System.currentTimeMillis() / 1000, 1, null);
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr3);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                                this.L$3 = SpillingKt.nullOutSpilledVariable(mySid5);
                                                this.L$4 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                this.L$5 = SpillingKt.nullOutSpilledVariable(attendance);
                                                this.I$0 = i;
                                                this.label = 4;
                                                if (this.this$0.repository.recordStudentAttendance(attendance.getClassroomId(), attendance.getStudentId(), attendance.getStudentName(), attendance.getStatus(), attendance.getTimestamp(), this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                profile2 = profile;
                                                todayDateStr4 = todayDateStr3;
                                                ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), ((BlePacket.RegApprovedResponse) this.$packet).getCid());
                                                profile = profile2;
                                                todayDateStr2 = todayDateStr4;
                                            } else {
                                                todayDateStr2 = todayDateStr;
                                            }
                                        } else {
                                            classroom3 = classroom2;
                                            todayDateStr2 = todayDateStr;
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.L$5 = null;
                                        this.label = 5;
                                        if (this.this$0._userMessage.emit("Request approved!", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit8 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 3:
                                        mySid2 = (String) this.L$3;
                                        profile = (StudentProfileEntity) this.L$2;
                                        todayDateStr = (String) this.L$1;
                                        ClassroomEntity classroom9 = (ClassroomEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        objFirst = $result;
                                        classroom3 = classroom9;
                                        existingLogs = (List) objFirst;
                                        iterable = existingLogs;
                                        if (iterable instanceof Collection) {
                                            it = iterable.iterator();
                                            do {
                                                if (it.hasNext()) {
                                                    attendanceEntity = (AttendanceEntity) it.next();
                                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                        z = false;
                                                    } else {
                                                        z = false;
                                                    }
                                                } else {
                                                    i = 0;
                                                }
                                            } while (!z);
                                        } else {
                                            it = iterable.iterator();
                                            do {
                                                if (it.hasNext()) {
                                                    attendanceEntity = (AttendanceEntity) it.next();
                                                    if (Intrinsics.areEqual(attendanceEntity.getDate(), todayDateStr)) {
                                                        z = false;
                                                    } else {
                                                        z = false;
                                                    }
                                                } else {
                                                    i = 0;
                                                }
                                            } while (!z);
                                        }
                                        if (i == 0) {
                                            String cid6 = ((BlePacket.RegApprovedResponse) this.$packet).getCid();
                                            String fullName4 = profile.getFullName();
                                            Intrinsics.checkNotNull(todayDateStr);
                                            String mySid6 = mySid2;
                                            todayDateStr3 = todayDateStr;
                                            attendance = new AttendanceEntity(0L, cid6, mySid6, fullName4, todayDateStr3, "PRESENT", System.currentTimeMillis() / 1000, 1, null);
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr3);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(mySid6);
                                            this.L$4 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                            this.L$5 = SpillingKt.nullOutSpilledVariable(attendance);
                                            this.I$0 = i;
                                            this.label = 4;
                                            if (this.this$0.repository.recordStudentAttendance(attendance.getClassroomId(), attendance.getStudentId(), attendance.getStudentName(), attendance.getStatus(), attendance.getTimestamp(), this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            profile2 = profile;
                                            todayDateStr4 = todayDateStr3;
                                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), ((BlePacket.RegApprovedResponse) this.$packet).getCid());
                                            profile = profile2;
                                            todayDateStr2 = todayDateStr4;
                                        } else {
                                            todayDateStr2 = todayDateStr;
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.L$5 = null;
                                        this.label = 5;
                                        if (this.this$0._userMessage.emit("Request approved!", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit9 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 4:
                                        int i2 = this.I$0;
                                        profile2 = (StudentProfileEntity) this.L$2;
                                        todayDateStr4 = (String) this.L$1;
                                        classroom3 = (ClassroomEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), ((BlePacket.RegApprovedResponse) this.$packet).getCid());
                                        profile = profile2;
                                        todayDateStr2 = todayDateStr4;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom3);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStr2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(profile);
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.L$5 = null;
                                        this.label = 5;
                                        if (this.this$0._userMessage.emit("Request approved!", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit10 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 5:
                                        ResultKt.throwOnFailure($result);
                                        Unit unit11 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 6:
                                        ResultKt.throwOnFailure($result);
                                        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new C01671(this.this$0, null), 3, null);
                                        return Unit.INSTANCE;
                                    case 7:
                                        ResultKt.throwOnFailure($result);
                                        studentProfileOnce = $result;
                                        value = (StudentProfileEntity) studentProfileOnce;
                                        profile3 = value;
                                        classroom4 = (ClassroomEntity) this.this$0._registeredClassroom.getValue();
                                        if (classroom4 == null) {
                                            this.L$0 = profile3;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(classroom4);
                                            this.label = 8;
                                            activeBoundClassroomSync2 = this.this$0.repository.getActiveBoundClassroomSync(this);
                                            if (activeBoundClassroomSync2 == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            classroom6 = (ClassroomEntity) activeBoundClassroomSync2;
                                            if (classroom6 != null) {
                                                this.this$0._registeredClassroom.setValue(classroom6);
                                            }
                                            classroom5 = classroom6;
                                            profile4 = profile3;
                                        } else {
                                            classroom5 = classroom4;
                                            profile4 = profile3;
                                        }
                                        if (profile4 != null) {
                                            graceTimeStr = classroom5.getGraceTime();
                                            graceMins = this.this$0.parseTimeToMinutes(graceTimeStr);
                                            calendar = Calendar.getInstance();
                                            calendar.setTimeInMillis(((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp() * 1000);
                                            currentMinutes = (calendar.get(11) * 60) + calendar.get(12);
                                            if (graceMins != -1) {
                                                attendanceStatus = "PRESENT";
                                            } else {
                                                attendanceStatus = "PRESENT";
                                            }
                                            if (this.this$0._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT) {
                                            }
                                            this.this$0._checkInState.setValue(StudentCheckInState.RECEIVING_TASKS);
                                            this.this$0._checkInMessage.setValue("Check-In Accepted by Teacher! Syncing tasks...");
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                            this.L$1 = classroom5;
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(graceTimeStr);
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(calendar);
                                            this.L$4 = attendanceStatus;
                                            this.I$0 = graceMins;
                                            this.I$1 = currentMinutes;
                                            this.label = 9;
                                            attendanceStatus2 = attendanceStatus;
                                            if (this.this$0.repository.recordStudentAttendance(classroom5.getCid(), profile4.getSid(), profile4.getFullName(), attendanceStatus2, ((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp(), this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            attendanceStatus3 = attendanceStatus2;
                                            if (Intrinsics.areEqual(attendanceStatus3, "PRESENT")) {
                                                ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), classroom5.getCid());
                                            }
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(classroom5);
                                        this.L$2 = null;
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.label = 11;
                                        if (this.this$0._userMessage.emit("Checked-in", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit12 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 8:
                                        profile3 = (StudentProfileEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        activeBoundClassroomSync2 = $result;
                                        classroom6 = (ClassroomEntity) activeBoundClassroomSync2;
                                        if (classroom6 != null) {
                                            this.this$0._registeredClassroom.setValue(classroom6);
                                        }
                                        classroom5 = classroom6;
                                        profile4 = profile3;
                                        if (profile4 != null) {
                                            graceTimeStr = classroom5.getGraceTime();
                                            graceMins = this.this$0.parseTimeToMinutes(graceTimeStr);
                                            calendar = Calendar.getInstance();
                                            calendar.setTimeInMillis(((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp() * 1000);
                                            currentMinutes = (calendar.get(11) * 60) + calendar.get(12);
                                            if (graceMins != -1) {
                                                attendanceStatus = "PRESENT";
                                            } else {
                                                attendanceStatus = "PRESENT";
                                            }
                                            if (this.this$0._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT) {
                                            }
                                            this.this$0._checkInState.setValue(StudentCheckInState.RECEIVING_TASKS);
                                            this.this$0._checkInMessage.setValue("Check-In Accepted by Teacher! Syncing tasks...");
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                            this.L$1 = classroom5;
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(graceTimeStr);
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(calendar);
                                            this.L$4 = attendanceStatus;
                                            this.I$0 = graceMins;
                                            this.I$1 = currentMinutes;
                                            this.label = 9;
                                            attendanceStatus2 = attendanceStatus;
                                            if (this.this$0.repository.recordStudentAttendance(classroom5.getCid(), profile4.getSid(), profile4.getFullName(), attendanceStatus2, ((BlePacket.AtdAcceptedResponse) this.$packet).getTimestamp(), this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            attendanceStatus3 = attendanceStatus2;
                                            if (Intrinsics.areEqual(attendanceStatus3, "PRESENT")) {
                                                ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), classroom5.getCid());
                                            }
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(classroom5);
                                        this.L$2 = null;
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.label = 11;
                                        if (this.this$0._userMessage.emit("Checked-in", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit13 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 9:
                                        int currentMinutes2 = this.I$1;
                                        int i3 = this.I$0;
                                        attendanceStatus3 = (String) this.L$4;
                                        classroom5 = (ClassroomEntity) this.L$1;
                                        profile4 = (StudentProfileEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        if (Intrinsics.areEqual(attendanceStatus3, "PRESENT")) {
                                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), classroom5.getCid());
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(classroom5);
                                        this.L$2 = null;
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.label = 11;
                                        if (this.this$0._userMessage.emit("Checked-in", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit14 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 10:
                                        int i4 = this.I$1;
                                        int i5 = this.I$0;
                                        attendanceStatus3 = (String) this.L$4;
                                        classroom5 = (ClassroomEntity) this.L$1;
                                        profile4 = (StudentProfileEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        if (Intrinsics.areEqual(attendanceStatus3, "PRESENT")) {
                                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), classroom5.getCid());
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(profile4);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(classroom5);
                                        this.L$2 = null;
                                        this.L$3 = null;
                                        this.L$4 = null;
                                        this.label = 11;
                                        if (this.this$0._userMessage.emit("Checked-in", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit15 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 11:
                                        ResultKt.throwOnFailure($result);
                                        Unit unit16 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 12:
                                        ResultKt.throwOnFailure($result);
                                        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass2(this.this$0, null), 3, null);
                                        return Unit.INSTANCE;
                                    case 13:
                                        updated = (ClassroomEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                            this.this$0._syncMessage.setValue("Classroom schedule updated (" + ((BlePacket.SchedResponse) this.$packet).getDays() + ").");
                                        }
                                        Unit unit17 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 14:
                                        ResultKt.throwOnFailure($result);
                                        activeBoundClassroomSync = $result;
                                        classroom = (ClassroomEntity) activeBoundClassroomSync;
                                        if (classroom != null) {
                                            this.this$0._registeredClassroom.setValue(classroom);
                                        }
                                        if (classroom == null) {
                                            return Unit.INSTANCE;
                                        }
                                        taskDesc = StringsKt.equals(((BlePacket.TaskCommand) this.$packet).getDesc(), ((BlePacket.TaskCommand) this.$packet).getTitle(), true) ? "" : ((BlePacket.TaskCommand) this.$packet).getDesc();
                                        String tkid2 = ((BlePacket.TaskCommand) this.$packet).getTkid();
                                        String cid7 = classroom.getCid();
                                        String title2 = ((BlePacket.TaskCommand) this.$packet).getTitle();
                                        long deadline2 = ((BlePacket.TaskCommand) this.$packet).getDeadline();
                                        long datePosted2 = ((BlePacket.TaskCommand) this.$packet).getDatePosted();
                                        intOrNull = StringsKt.toIntOrNull(((BlePacket.TaskCommand) this.$packet).getScore());
                                        if (intOrNull != null) {
                                            iIntValue = intOrNull.intValue();
                                        } else {
                                            iIntValue = 100;
                                        }
                                        task = new TaskEntity(tkid2, cid7, title2, taskDesc, deadline2, datePosted2, iIntValue);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(taskDesc);
                                        this.L$2 = task;
                                        this.label = 15;
                                        if (this.this$0.repository.saveTask(task, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        classroom7 = classroom;
                                        task2 = task;
                                        taskDesc2 = taskDesc;
                                        ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                        if (Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_TASKS")) {
                                            this.this$0._registrationStatus.setValue("RECEIVING_TASKS");
                                            iterable2 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if (iterable2 instanceof Collection) {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            } else {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            }
                                            if (!z2) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        } else {
                                            this.this$0._registrationStatus.setValue("RECEIVING_TASKS");
                                            iterable2 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if (iterable2 instanceof Collection) {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            } else {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            }
                                            if (!z2) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        }
                                        value2 = this.this$0._checkInState.getValue();
                                        studentCheckInState = StudentCheckInState.RECEIVING_TASKS;
                                        studentViewModel = this.this$0;
                                        if (value2 == studentCheckInState) {
                                            iterable4 = (Iterable) studentViewModel._checkInTasks.getValue();
                                            if (iterable4 instanceof Collection) {
                                                it4 = iterable4.iterator();
                                                do {
                                                    if (!it4.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it4.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it4 = iterable4.iterator();
                                                do {
                                                    if (!it4.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it4.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                            this.this$0._checkInMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        } else if (studentViewModel._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT) {
                                            iterable3 = (Iterable) this.this$0._checkInTasks.getValue();
                                            if (iterable3 instanceof Collection) {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                        } else {
                                            iterable3 = (Iterable) this.this$0._checkInTasks.getValue();
                                            if (iterable3 instanceof Collection) {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                        }
                                        if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                            this.this$0._syncMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom7);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(taskDesc2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(task2);
                                        this.label = 16;
                                        if (this.this$0._userMessage.emit("New Task Received", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit18 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 15:
                                        task2 = (TaskEntity) this.L$2;
                                        taskDesc2 = (String) this.L$1;
                                        classroom7 = (ClassroomEntity) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                        if (Intrinsics.areEqual(this.this$0._registrationStatus.getValue(), "APPROVED_WAITING_TASKS")) {
                                            this.this$0._registrationStatus.setValue("RECEIVING_TASKS");
                                            iterable2 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if (iterable2 instanceof Collection) {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            } else {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            }
                                            if (!z2) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        } else {
                                            this.this$0._registrationStatus.setValue("RECEIVING_TASKS");
                                            iterable2 = (Iterable) this.this$0._registrationTasks.getValue();
                                            if (iterable2 instanceof Collection) {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            } else {
                                                it2 = iterable2.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        z2 = false;
                                                    } else if (Intrinsics.areEqual(((TaskEntity) it2.next()).getTkid(), task2.getTkid())) {
                                                        z2 = true;
                                                    }
                                                }
                                            }
                                            if (!z2) {
                                                this.this$0._registrationTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._registrationTasks.getValue(), task2));
                                            }
                                        }
                                        value2 = this.this$0._checkInState.getValue();
                                        studentCheckInState = StudentCheckInState.RECEIVING_TASKS;
                                        studentViewModel = this.this$0;
                                        if (value2 == studentCheckInState) {
                                            iterable4 = (Iterable) studentViewModel._checkInTasks.getValue();
                                            if (iterable4 instanceof Collection) {
                                                it4 = iterable4.iterator();
                                                do {
                                                    if (!it4.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it4.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it4 = iterable4.iterator();
                                                do {
                                                    if (!it4.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it4.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                            this.this$0._checkInMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        } else if (studentViewModel._checkInState.getValue() != StudentCheckInState.WAITING_FOR_ACCEPT) {
                                            iterable3 = (Iterable) this.this$0._checkInTasks.getValue();
                                            if (iterable3 instanceof Collection) {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                        } else {
                                            iterable3 = (Iterable) this.this$0._checkInTasks.getValue();
                                            if (iterable3 instanceof Collection) {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            } else {
                                                it3 = iterable3.iterator();
                                                do {
                                                    if (!it3.hasNext()) {
                                                        i = 0;
                                                    }
                                                } while (!Intrinsics.areEqual(((TaskEntity) it3.next()).getTkid(), task2.getTkid()));
                                            }
                                            if (i == 0) {
                                                this.this$0._checkInTasks.setValue(CollectionsKt.plus((Collection<? extends TaskEntity>) this.this$0._checkInTasks.getValue(), task2));
                                            }
                                        }
                                        if (this.this$0._syncState.getValue() == StudentSyncState.SYNCING) {
                                            this.this$0._syncMessage.setValue("Received task: " + ((BlePacket.TaskCommand) this.$packet).getTitle());
                                        }
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom7);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(taskDesc2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(task2);
                                        this.label = 16;
                                        if (this.this$0._userMessage.emit("New Task Received", this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit19 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 16:
                                        ResultKt.throwOnFailure($result);
                                        Unit unit110 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 17:
                                        int i6 = this.I$0;
                                        long j = this.J$0;
                                        ResultKt.throwOnFailure($result);
                                        Unit unit20 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    case 18:
                                        ResultKt.throwOnFailure($result);
                                        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass10(this.this$0, null), 3, null);
                                        if (this.this$0._taskSubmitState.getValue() != StudentTaskSubmitState.SUBMITTING) {
                                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass11(this.this$0, null), 3, null);
                                        } else {
                                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this.this$0), null, null, new AnonymousClass11(this.this$0, null), 3, null);
                                        }
                                        Unit unit21 = Unit.INSTANCE;
                                        return Unit.INSTANCE;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$1, reason: invalid class name and collision with other inner class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$1", f = "StudentViewModel.kt", i = {}, l = {1103}, m = "invokeSuspend", n = {}, s = {})
                            static final class C01671 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                C01671(StudentViewModel studentViewModel, Continuation<? super C01671> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new C01671(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((C01671) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$2, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$2", f = "StudentViewModel.kt", i = {}, l = {1165}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass2(StudentViewModel studentViewModel, Continuation<? super AnonymousClass2> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass2(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$7, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$7", f = "StudentViewModel.kt", i = {1, 1, 2, 2, 2, 2}, l = {1247, 1257, 1262}, m = "invokeSuspend", n = {"todayDateStr", "todayDateStrMdy", "todayDateStr", "todayDateStrMdy", "existingLogs", "hasTodayLog"}, s = {"L$0", "L$1", "L$0", "L$1", "L$2", "I$0"})
                            static final class AnonymousClass7 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                final /* synthetic */ ClassroomEntity $classroom;
                                final /* synthetic */ long $epochSeconds;
                                final /* synthetic */ StudentProfileEntity $profile;
                                final /* synthetic */ int $score;
                                final /* synthetic */ TaskEntity $targetTask;
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass7(StudentViewModel studentViewModel, TaskEntity taskEntity, StudentProfileEntity studentProfileEntity, int i, long j, ClassroomEntity classroomEntity, Continuation<? super AnonymousClass7> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                    this.$targetTask = taskEntity;
                                    this.$profile = studentProfileEntity;
                                    this.$score = i;
                                    this.$epochSeconds = j;
                                    this.$classroom = classroomEntity;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass7(this.this$0, this.$targetTask, this.$profile, this.$score, this.$epochSeconds, this.$classroom, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass7) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                /* JADX WARN: Code duplicated, block: B:14:0x006a  */
                                /* JADX WARN: Code duplicated, block: B:16:0x00b7 A[RETURN] */
                                /* JADX WARN: Code duplicated, block: B:17:0x00b8  */
                                /* JADX WARN: Code duplicated, block: B:20:0x00ca  */
                                /* JADX WARN: Code duplicated, block: B:23:0x00d7  */
                                /* JADX WARN: Code duplicated, block: B:26:0x00e1  */
                                /* JADX WARN: Code duplicated, block: B:28:0x00f7  */
                                /* JADX WARN: Code duplicated, block: B:30:0x0105  */
                                /* JADX WARN: Code duplicated, block: B:32:0x0112  */
                                /* JADX WARN: Code duplicated, block: B:35:0x0125  */
                                /* JADX WARN: Code duplicated, block: B:37:0x0129  */
                                /* JADX WARN: Code duplicated, block: B:41:0x0130 A[LOOP:0: B:24:0x00db->B:41:0x0130, LOOP_END] */
                                /* JADX WARN: Code duplicated, block: B:45:0x013a  */
                                /* JADX WARN: Code duplicated, block: B:47:0x0177 A[RETURN] */
                                /* JADX WARN: Code duplicated, block: B:48:0x0178  */
                                /* JADX WARN: Code duplicated, block: B:52:0x012e A[SYNTHETIC] */
                                /* JADX WARN: Code duplicated, block: B:53:0x0134 A[SYNTHETIC] */
                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    String todayDateStr;
                                    String todayDateStrMdy;
                                    Object objFirst;
                                    String todayDateStrMdy2;
                                    String todayDateStr2;
                                    Iterable existingLogs;
                                    Iterable iterable;
                                    StudentProfileEntity studentProfileEntity;
                                    Iterator<T> it;
                                    String todayDateStrMdy3;
                                    int i;
                                    AttendanceEntity attendanceEntity;
                                    boolean z;
                                    String date;
                                    String date2;
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (this.this$0.repository.recordTaskSubmission(this.$targetTask.getTkid(), this.$profile.getSid(), this.$profile.getFullName(), this.$score, this.$epochSeconds, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            if (this.$classroom != null) {
                                                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(this.$epochSeconds * 1000));
                                                todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(this.$epochSeconds * 1000));
                                                this.L$0 = todayDateStr;
                                                this.L$1 = todayDateStrMdy;
                                                this.label = 2;
                                                objFirst = FlowKt.first(this.this$0.repository.getAttendanceForClassroom(this.$classroom.getCid()), this);
                                                if (objFirst == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                todayDateStrMdy2 = todayDateStr;
                                                todayDateStr2 = todayDateStrMdy;
                                                existingLogs = (List) objFirst;
                                                iterable = existingLogs;
                                                studentProfileEntity = this.$profile;
                                                if ((iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                                                    it = iterable.iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            attendanceEntity = (AttendanceEntity) it.next();
                                                            if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                                                date = attendanceEntity.getDate();
                                                                Intrinsics.checkNotNull(todayDateStrMdy2);
                                                                if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                } else {
                                                                    date2 = attendanceEntity.getDate();
                                                                    Intrinsics.checkNotNull(todayDateStr2);
                                                                    if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                    } else {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                        if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                                        }
                                                                        if (z) {
                                                                            i = 1;
                                                                        } else {
                                                                            todayDateStr2 = todayDateStrMdy3;
                                                                        }
                                                                    }
                                                                }
                                                                z = true;
                                                                if (z) {
                                                                    i = 1;
                                                                } else {
                                                                    todayDateStr2 = todayDateStrMdy3;
                                                                }
                                                            } else {
                                                                todayDateStrMdy3 = todayDateStr2;
                                                            }
                                                            z = false;
                                                            if (z) {
                                                                i = 1;
                                                            } else {
                                                                todayDateStr2 = todayDateStrMdy3;
                                                            }
                                                        } else {
                                                            todayDateStrMdy3 = todayDateStr2;
                                                            i = 0;
                                                        }
                                                    }
                                                } else {
                                                    todayDateStrMdy3 = todayDateStr2;
                                                    i = 0;
                                                }
                                                if (i == 0) {
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                                                    this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                    this.I$0 = i;
                                                    this.label = 3;
                                                    if (this.this$0.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$epochSeconds, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), this.$classroom.getCid());
                                                }
                                            }
                                            ReminderNotificationHelper.INSTANCE.cancelTaskNotification(this.this$0.getApplication(), this.$targetTask.getTkid());
                                            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                            return Unit.INSTANCE;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            if (this.$classroom != null) {
                                                todayDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(this.$epochSeconds * 1000));
                                                todayDateStrMdy = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(this.$epochSeconds * 1000));
                                                this.L$0 = todayDateStr;
                                                this.L$1 = todayDateStrMdy;
                                                this.label = 2;
                                                objFirst = FlowKt.first(this.this$0.repository.getAttendanceForClassroom(this.$classroom.getCid()), this);
                                                if (objFirst == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                todayDateStrMdy2 = todayDateStr;
                                                todayDateStr2 = todayDateStrMdy;
                                                existingLogs = (List) objFirst;
                                                iterable = existingLogs;
                                                studentProfileEntity = this.$profile;
                                                if (iterable instanceof Collection) {
                                                    it = iterable.iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            attendanceEntity = (AttendanceEntity) it.next();
                                                            if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                                                date = attendanceEntity.getDate();
                                                                Intrinsics.checkNotNull(todayDateStrMdy2);
                                                                if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                                                    date2 = attendanceEntity.getDate();
                                                                    Intrinsics.checkNotNull(todayDateStr2);
                                                                    if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                        if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                                        }
                                                                        if (z) {
                                                                            i = 1;
                                                                        } else {
                                                                            todayDateStr2 = todayDateStrMdy3;
                                                                        }
                                                                    } else {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                    }
                                                                } else {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                }
                                                                z = true;
                                                                if (z) {
                                                                    i = 1;
                                                                } else {
                                                                    todayDateStr2 = todayDateStrMdy3;
                                                                }
                                                            } else {
                                                                todayDateStrMdy3 = todayDateStr2;
                                                            }
                                                            z = false;
                                                            if (z) {
                                                                i = 1;
                                                            } else {
                                                                todayDateStr2 = todayDateStrMdy3;
                                                            }
                                                        } else {
                                                            todayDateStrMdy3 = todayDateStr2;
                                                            i = 0;
                                                        }
                                                    }
                                                } else {
                                                    it = iterable.iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            attendanceEntity = (AttendanceEntity) it.next();
                                                            if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                                                date = attendanceEntity.getDate();
                                                                Intrinsics.checkNotNull(todayDateStrMdy2);
                                                                if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                                                    date2 = attendanceEntity.getDate();
                                                                    Intrinsics.checkNotNull(todayDateStr2);
                                                                    if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                        if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                                        }
                                                                        if (z) {
                                                                            i = 1;
                                                                        } else {
                                                                            todayDateStr2 = todayDateStrMdy3;
                                                                        }
                                                                    } else {
                                                                        todayDateStrMdy3 = todayDateStr2;
                                                                    }
                                                                } else {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                }
                                                                z = true;
                                                                if (z) {
                                                                    i = 1;
                                                                } else {
                                                                    todayDateStr2 = todayDateStrMdy3;
                                                                }
                                                            } else {
                                                                todayDateStrMdy3 = todayDateStr2;
                                                            }
                                                            z = false;
                                                            if (z) {
                                                                i = 1;
                                                            } else {
                                                                todayDateStr2 = todayDateStrMdy3;
                                                            }
                                                        } else {
                                                            todayDateStrMdy3 = todayDateStr2;
                                                            i = 0;
                                                        }
                                                    }
                                                }
                                                if (i == 0) {
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                                                    this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                    this.I$0 = i;
                                                    this.label = 3;
                                                    if (this.this$0.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$epochSeconds, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), this.$classroom.getCid());
                                                }
                                            }
                                            ReminderNotificationHelper.INSTANCE.cancelTaskNotification(this.this$0.getApplication(), this.$targetTask.getTkid());
                                            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                            return Unit.INSTANCE;
                                        case 2:
                                            todayDateStr2 = (String) this.L$1;
                                            todayDateStrMdy2 = (String) this.L$0;
                                            ResultKt.throwOnFailure($result);
                                            objFirst = $result;
                                            existingLogs = (List) objFirst;
                                            iterable = existingLogs;
                                            studentProfileEntity = this.$profile;
                                            if (iterable instanceof Collection) {
                                                it = iterable.iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                                            date = attendanceEntity.getDate();
                                                            Intrinsics.checkNotNull(todayDateStrMdy2);
                                                            if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                                                date2 = attendanceEntity.getDate();
                                                                Intrinsics.checkNotNull(todayDateStr2);
                                                                if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                    if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                                    }
                                                                    if (z) {
                                                                        i = 1;
                                                                    } else {
                                                                        todayDateStr2 = todayDateStrMdy3;
                                                                    }
                                                                } else {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                }
                                                            } else {
                                                                todayDateStrMdy3 = todayDateStr2;
                                                            }
                                                            z = true;
                                                            if (z) {
                                                                i = 1;
                                                            } else {
                                                                todayDateStr2 = todayDateStrMdy3;
                                                            }
                                                        } else {
                                                            todayDateStrMdy3 = todayDateStr2;
                                                        }
                                                        z = false;
                                                        if (z) {
                                                            i = 1;
                                                        } else {
                                                            todayDateStr2 = todayDateStrMdy3;
                                                        }
                                                    } else {
                                                        todayDateStrMdy3 = todayDateStr2;
                                                        i = 0;
                                                    }
                                                }
                                            } else {
                                                it = iterable.iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
                                                        attendanceEntity = (AttendanceEntity) it.next();
                                                        if (Intrinsics.areEqual(attendanceEntity.getStudentId(), studentProfileEntity.getSid())) {
                                                            date = attendanceEntity.getDate();
                                                            Intrinsics.checkNotNull(todayDateStrMdy2);
                                                            if (StringsKt.startsWith$default(date, todayDateStrMdy2, false, 2, (Object) null)) {
                                                                date2 = attendanceEntity.getDate();
                                                                Intrinsics.checkNotNull(todayDateStr2);
                                                                if (StringsKt.startsWith$default(date2, todayDateStr2, false, 2, (Object) null)) {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                    if (StringsKt.contains$default((CharSequence) attendanceEntity.getDate(), (CharSequence) todayDateStrMdy3, false, 2, (Object) null)) {
                                                                    }
                                                                    if (z) {
                                                                        i = 1;
                                                                    } else {
                                                                        todayDateStr2 = todayDateStrMdy3;
                                                                    }
                                                                } else {
                                                                    todayDateStrMdy3 = todayDateStr2;
                                                                }
                                                            } else {
                                                                todayDateStrMdy3 = todayDateStr2;
                                                            }
                                                            z = true;
                                                            if (z) {
                                                                i = 1;
                                                            } else {
                                                                todayDateStr2 = todayDateStrMdy3;
                                                            }
                                                        } else {
                                                            todayDateStrMdy3 = todayDateStr2;
                                                        }
                                                        z = false;
                                                        if (z) {
                                                            i = 1;
                                                        } else {
                                                            todayDateStr2 = todayDateStrMdy3;
                                                        }
                                                    } else {
                                                        todayDateStrMdy3 = todayDateStr2;
                                                        i = 0;
                                                    }
                                                }
                                            }
                                            if (i == 0) {
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy2);
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(todayDateStrMdy3);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(existingLogs);
                                                this.I$0 = i;
                                                this.label = 3;
                                                if (this.this$0.repository.recordStudentAttendance(this.$classroom.getCid(), this.$profile.getSid(), this.$profile.getFullName(), "PRESENT", this.$epochSeconds, this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), this.$classroom.getCid());
                                            }
                                            ReminderNotificationHelper.INSTANCE.cancelTaskNotification(this.this$0.getApplication(), this.$targetTask.getTkid());
                                            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                            return Unit.INSTANCE;
                                        case 3:
                                            int i2 = this.I$0;
                                            ResultKt.throwOnFailure($result);
                                            ReminderNotificationHelper.INSTANCE.cancelCheckInAndLateNotifications(this.this$0.getApplication(), this.$classroom.getCid());
                                            ReminderNotificationHelper.INSTANCE.cancelTaskNotification(this.this$0.getApplication(), this.$targetTask.getTkid());
                                            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(this.this$0.getApplication());
                                            return Unit.INSTANCE;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$8, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$8", f = "StudentViewModel.kt", i = {}, l = {1289}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass8 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass8(StudentViewModel studentViewModel, Continuation<? super AnonymousClass8> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass8(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass8) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$9, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$9", f = "StudentViewModel.kt", i = {}, l = {1303}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass9 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass9(StudentViewModel studentViewModel, Continuation<? super AnonymousClass9> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass9(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass9) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$10, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$10", f = "StudentViewModel.kt", i = {}, l = {1312}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass10 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass10(StudentViewModel studentViewModel, Continuation<? super AnonymousClass10> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass10(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass10) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$11, reason: invalid class name */
                            /* JADX INFO: compiled from: StudentViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$observeIncomingPackets$1$1$1$11", f = "StudentViewModel.kt", i = {}, l = {1318}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass11 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int label;
                                final /* synthetic */ StudentViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass11(StudentViewModel studentViewModel, Continuation<? super AnonymousClass11> continuation) {
                                    super(2, continuation);
                                    this.this$0 = studentViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass11(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass11) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (DelayKt.delay(400L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    this.this$0.getBleManager().clearBleObject();
                                    return Unit.INSTANCE;
                                }
                            }
                        }

                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((BlePacket) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(BlePacket packet, Continuation<? super Unit> continuation) {
                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(studentViewModel), null, null, new C01661(packet, studentViewModel, null), 3, null);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    private final void observeIncomingPackets() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07861(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int parseTimeToMinutes(String raw) {
        int hour;
        String trimmed = StringsKt.trim((CharSequence) raw).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(trimmed, "toUpperCase(...)");
        if ((trimmed.length() == 0) || Intrinsics.areEqual(trimmed, "N/A")) {
            return -1;
        }
        boolean isPM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "PM", false, 2, (Object) null);
        boolean isAM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "AM", false, 2, (Object) null);
        String clean = StringsKt.trim((CharSequence) StringsKt.replace$default(StringsKt.replace$default(trimmed, "AM", "", false, 4, (Object) null), "PM", "", false, 4, (Object) null)).toString();
        List parts = StringsKt.split$default((CharSequence) clean, new String[]{ServerSentEventKt.COLON}, false, 0, 6, (Object) null);
        int min = 0;
        if (parts.size() >= 2) {
            Integer intOrNull = StringsKt.toIntOrNull((String) parts.get(0));
            hour = intOrNull != null ? intOrNull.intValue() : 0;
            Integer intOrNull2 = StringsKt.toIntOrNull((String) parts.get(1));
            min = intOrNull2 != null ? intOrNull2.intValue() : 0;
        } else if (clean.length() >= 3) {
            Integer intOrNull3 = StringsKt.toIntOrNull(StringsKt.dropLast(clean, 2));
            hour = intOrNull3 != null ? intOrNull3.intValue() : 0;
            Integer intOrNull4 = StringsKt.toIntOrNull(StringsKt.takeLast(clean, 2));
            min = intOrNull4 != null ? intOrNull4.intValue() : 0;
        } else {
            Integer intOrNull5 = StringsKt.toIntOrNull(clean);
            hour = intOrNull5 != null ? intOrNull5.intValue() : 0;
        }
        if (isPM && hour < 12) {
            hour += 12;
        }
        if (isAM && hour == 12) {
            hour = 0;
        }
        return (hour * 60) + min;
    }
}
