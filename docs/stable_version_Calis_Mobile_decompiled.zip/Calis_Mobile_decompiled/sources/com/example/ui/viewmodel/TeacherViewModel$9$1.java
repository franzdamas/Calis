package com.example.ui.viewmodel;

import com.example.data.db.TaskDeliveryEntity;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: TeacherViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\n"}, d2 = {"<anonymous>", "", "it", "", "Lcom/example/data/db/TaskDeliveryEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$9$1", f = "TeacherViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class TeacherViewModel$9$1 extends SuspendLambda implements Function2<List<? extends TaskDeliveryEntity>, Continuation<? super Unit>, Object> {
    int label;
    final /* synthetic */ TeacherViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TeacherViewModel$9$1(TeacherViewModel teacherViewModel, Continuation<? super TeacherViewModel$9$1> continuation) {
        super(2, continuation);
        this.this$0 = teacherViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new TeacherViewModel$9$1(this.this$0, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ Object invoke(List<? extends TaskDeliveryEntity> list, Continuation<? super Unit> continuation) {
        return invoke2((List<TaskDeliveryEntity>) list, continuation);
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final Object invoke2(List<TaskDeliveryEntity> list, Continuation<? super Unit> continuation) {
        return ((TeacherViewModel$9$1) create(list, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                this.this$0._isSubmissionsLoading.setValue(Boxing.boxBoolean(false));
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
