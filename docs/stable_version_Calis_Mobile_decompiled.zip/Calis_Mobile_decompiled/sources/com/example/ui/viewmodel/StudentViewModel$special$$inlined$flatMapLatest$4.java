package com.example.ui.viewmodel;

import com.example.data.db.AttendanceEntity;
import com.example.data.db.ClassroomEntity;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function3;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;

/* JADX INFO: compiled from: Merge.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\b\u0012\u0004\u0012\u0002H\u00020\u00042\u0006\u0010\u0005\u001a\u0002H\u0003H\n¨\u0006\u0006"}, d2 = {"<anonymous>", "", "R", "T", "Lkotlinx/coroutines/flow/FlowCollector;", "it", "kotlinx/coroutines/flow/FlowKt__MergeKt$flatMapLatest$1"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.viewmodel.StudentViewModel$special$$inlined$flatMapLatest$4", f = "StudentViewModel.kt", i = {0, 0}, l = {189}, m = "invokeSuspend", n = {"$this$transformLatest", "it"}, s = {"L$0", "L$1"})
public final class StudentViewModel$special$$inlined$flatMapLatest$4 extends SuspendLambda implements Function3<FlowCollector<? super List<? extends AttendanceEntity>>, ClassroomEntity, Continuation<? super Unit>, Object> {
    private /* synthetic */ Object L$0;
    /* synthetic */ Object L$1;
    int label;
    final /* synthetic */ StudentViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StudentViewModel$special$$inlined$flatMapLatest$4(Continuation continuation, StudentViewModel studentViewModel) {
        super(3, continuation);
        this.this$0 = studentViewModel;
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(FlowCollector<? super List<? extends AttendanceEntity>> flowCollector, ClassroomEntity classroomEntity, Continuation<? super Unit> continuation) {
        StudentViewModel$special$$inlined$flatMapLatest$4 studentViewModel$special$$inlined$flatMapLatest$4 = new StudentViewModel$special$$inlined$flatMapLatest$4(continuation, this.this$0);
        studentViewModel$special$$inlined$flatMapLatest$4.L$0 = flowCollector;
        studentViewModel$special$$inlined$flatMapLatest$4.L$1 = classroomEntity;
        return studentViewModel$special$$inlined$flatMapLatest$4.invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        Flow<List<AttendanceEntity>> flowFlowOf;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                FlowCollector $this$transformLatest = (FlowCollector) this.L$0;
                Object it = this.L$1;
                ClassroomEntity classroomEntity = (ClassroomEntity) it;
                if (classroomEntity != null) {
                    flowFlowOf = this.this$0.repository.getAttendanceForClassroom(classroomEntity.getCid());
                } else {
                    flowFlowOf = FlowKt.flowOf(CollectionsKt.emptyList());
                }
                this.L$0 = SpillingKt.nullOutSpilledVariable($this$transformLatest);
                this.L$1 = SpillingKt.nullOutSpilledVariable(it);
                this.label = 1;
                if (FlowKt.emitAll($this$transformLatest, flowFlowOf, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
            case 1:
                Object obj = this.L$1;
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}
