package com.example.ui.viewmodel;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX INFO: compiled from: StudentViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u000b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b¨\u0006\f"}, d2 = {"Lcom/example/ui/viewmodel/StudentCheckInState;", "", "<init>", "(Ljava/lang/String;I)V", "IDLE", "DISCOVERING", "CONNECTING", "CHECKING_IN", "WAITING_FOR_ACCEPT", "RECEIVING_TASKS", "SUCCESS", "FAILED", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public enum StudentCheckInState {
    IDLE,
    DISCOVERING,
    CONNECTING,
    CHECKING_IN,
    WAITING_FOR_ACCEPT,
    RECEIVING_TASKS,
    SUCCESS,
    FAILED;

    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    public static EnumEntries<StudentCheckInState> getEntries() {
        return $ENTRIES;
    }
}
