package com.example.ui.viewmodel;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.compose.animation.core.AnimationConstants;
import androidx.compose.runtime.ComposerKt;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModelKt;
import com.example.ble.CalisBleService;
import com.example.data.db.CalisDatabase;
import com.example.data.db.ClassroomEntity;
import com.example.data.db.StudentProfileEntity;
import com.example.data.db.TeacherEntity;
import com.example.data.repository.CalisRepository;
import com.example.util.BlePermissionUtils;
import com.example.util.IdGenerator;
import com.example.util.ReminderNotificationHelper;
import com.google.android.gms.common.Scopes;
import java.util.Arrays;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: AuthViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u000e\n\u0002\b\u001a\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\t\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010'\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010(\u001a\u00020\u001e2\u0006\u0010)\u001a\u00020$J\u000e\u0010C\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010D\u001a\u00020\u001e2\u0006\u0010)\u001a\u00020$J\u000e\u0010E\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010F\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010G\u001a\u00020\u001e2\u0006\u0010H\u001a\u00020$J\u0016\u0010I\u001a\u00020\u001e2\u0006\u0010J\u001a\u00020$2\u0006\u0010K\u001a\u00020$J\u000e\u0010^\u001a\u00020\u001e2\u0006\u0010_\u001a\u000207J\u001e\u0010`\u001a\u00020\u001e2\u0006\u0010a\u001a\u0002072\u0006\u0010b\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\rJ\u000e\u0010c\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\rJ\u000e\u0010e\u001a\u00020\u001e2\u0006\u0010f\u001a\u00020\rJ\u0014\u0010g\u001a\u00020\u001e2\f\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001e0iJ\u0014\u0010j\u001a\u00020\u001e2\f\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001e0iJ&\u0010k\u001a\u00020\u001e2\u0006\u0010l\u001a\u0002072\b\b\u0002\u0010m\u001a\u0002072\f\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001e0iJ\u0096\u0001\u0010n\u001a\u00020\u001e2\u0006\u0010l\u001a\u0002072\b\b\u0002\u0010m\u001a\u0002072\u0006\u0010o\u001a\u0002072\u0006\u0010H\u001a\u0002072\u0006\u0010p\u001a\u0002072\u0006\u0010q\u001a\u0002072\u0006\u0010r\u001a\u0002072\n\b\u0002\u0010s\u001a\u0004\u0018\u0001072\n\b\u0002\u0010t\u001a\u0004\u0018\u0001072\n\b\u0002\u0010u\u001a\u0004\u0018\u0001072\n\b\u0002\u0010v\u001a\u0004\u0018\u0001072\n\b\u0002\u0010w\u001a\u0004\u0018\u0001072\n\b\u0002\u0010x\u001a\u0004\u0018\u0001072\f\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001e0iJ4\u0010y\u001a\u00020\u001e2\u0006\u0010l\u001a\u0002072\u0006\u0010m\u001a\u0002072\u0006\u0010z\u001a\u0002072\u0006\u0010{\u001a\u00020|2\f\u0010h\u001a\b\u0012\u0004\u0012\u00020\u001e0iR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n \n*\u0004\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0010R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0010R\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0010R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0010R\u0014\u0010 \u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010!\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0010R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020$0\u000f¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0010R\u0014\u0010*\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010+\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b,\u0010\u0010R\u0014\u0010-\u001a\b\u0012\u0004\u0012\u00020$0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010.\u001a\b\u0012\u0004\u0012\u00020$0\u000f¢\u0006\b\n\u0000\u001a\u0004\b/\u0010\u0010R\u0014\u00100\u001a\b\u0012\u0004\u0012\u00020$0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00101\u001a\b\u0012\u0004\u0012\u00020$0\u000f¢\u0006\b\n\u0000\u001a\u0004\b2\u0010\u0010R\u0014\u00103\u001a\b\u0012\u0004\u0012\u00020$0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00104\u001a\b\u0012\u0004\u0012\u00020$0\u000f¢\u0006\b\n\u0000\u001a\u0004\b5\u0010\u0010R\u0014\u00106\u001a\b\u0012\u0004\u0012\u0002070\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00108\u001a\b\u0012\u0004\u0012\u0002070\u000f¢\u0006\b\n\u0000\u001a\u0004\b9\u0010\u0010R\u0014\u0010:\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010;\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b<\u0010\u0010R\u0014\u0010=\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010>\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b?\u0010\u0010R\u0014\u0010@\u001a\b\u0012\u0004\u0012\u00020$0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010A\u001a\b\u0012\u0004\u0012\u00020$0\u000f¢\u0006\b\n\u0000\u001a\u0004\bB\u0010\u0010R\u0014\u0010L\u001a\b\u0012\u0004\u0012\u0002070\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010M\u001a\b\u0012\u0004\u0012\u0002070\u000f¢\u0006\b\n\u0000\u001a\u0004\bN\u0010\u0010R\u0014\u0010O\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010P\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\bP\u0010\u0010R\u001b\u0010Q\u001a\u000f\u0012\u000b\u0012\t\u0018\u000107¢\u0006\u0002\bR0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010S\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001070\u000f¢\u0006\b\n\u0000\u001a\u0004\bT\u0010\u0010R\u0019\u0010U\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010V0\u000f¢\u0006\b\n\u0000\u001a\u0004\bW\u0010\u0010R\u0019\u0010X\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010Y0\u000f¢\u0006\b\n\u0000\u001a\u0004\bZ\u0010\u0010R\u0016\u0010[\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001070\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\\\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001070\u000f¢\u0006\b\n\u0000\u001a\u0004\b]\u0010\u0010¨\u0006}"}, d2 = {"Lcom/example/ui/viewmodel/AuthViewModel;", "Landroidx/lifecycle/AndroidViewModel;", "application", "Landroid/app/Application;", "<init>", "(Landroid/app/Application;)V", "repository", "Lcom/example/data/repository/CalisRepository;", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "_isDbLoaded", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "isDbLoaded", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "_hasAccount", "hasAccount", "getHasAccount", "_saveLogin", "saveLogin", "getSaveLogin", "_enableBiometrics", "enableBiometrics", "getEnableBiometrics", "_autoStartSession", "autoStartSession", "getAutoStartSession", "setAutoStartSession", "", "enabled", "_remindStartSession", "remindStartSession", "getRemindStartSession", "_remindStartSessionMinutes", "", "remindStartSessionMinutes", "getRemindStartSessionMinutes", "setRemindStartSession", "setRemindStartSessionMinutes", "minutes", "_remindTaskDeadline", "remindTaskDeadline", "getRemindTaskDeadline", "_remindTaskDeadlineDays", "remindTaskDeadlineDays", "getRemindTaskDeadlineDays", "_remindTaskDeadlineHour", "remindTaskDeadlineHour", "getRemindTaskDeadlineHour", "_remindTaskDeadlineMinute", "remindTaskDeadlineMinute", "getRemindTaskDeadlineMinute", "_remindTaskDeadlineTime", "", "remindTaskDeadlineTime", "getRemindTaskDeadlineTime", "_autoStartupEnabled", "autoStartupEnabled", "getAutoStartupEnabled", "_remindCheckIn", "remindCheckIn", "getRemindCheckIn", "_remindCheckInMinutes", "remindCheckInMinutes", "getRemindCheckInMinutes", "setRemindCheckIn", "setRemindCheckInMinutes", "setAutoStartupEnabled", "setRemindTaskDeadline", "setRemindTaskDeadlineDays", "days", "setRemindTaskDeadlineTime", "hour", "minute", "_savedPin", "savedPin", "getSavedPin", "_isLoggedIn", "isLoggedIn", "_userRole", "Lkotlin/jvm/internal/EnhancedNullability;", "userRole", "getUserRole", "currentTeacher", "Lcom/example/data/db/TeacherEntity;", "getCurrentTeacher", "currentStudentProfile", "Lcom/example/data/db/StudentProfileEntity;", "getCurrentStudentProfile", "_selectedRole", "selectedRole", "getSelectedRole", "selectRole", "role", "saveAuthCredentials", "pin", "biometrics", "setSaveLogin", "setEnableBiometrics", "setLoggedIn", "loggedIn", "logout", "onComplete", "Lkotlin/Function0;", "deleteAccountAndAllData", "createTeacherProfile", "fullName", "sex", "createTeacherProfileWithClassroom", "classroomName", "startTime", "graceTime", "endTime", "tid", "cid", "firstName", "middleName", "surname", "honorific", "createStudentProfile", "lrn", "birthDate", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AuthViewModel extends AndroidViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<Boolean> _autoStartSession;
    private final MutableStateFlow<Boolean> _autoStartupEnabled;
    private final MutableStateFlow<Boolean> _enableBiometrics;
    private final MutableStateFlow<Boolean> _hasAccount;
    private final MutableStateFlow<Boolean> _isDbLoaded;
    private final MutableStateFlow<Boolean> _isLoggedIn;
    private final MutableStateFlow<Boolean> _remindCheckIn;
    private final MutableStateFlow<Integer> _remindCheckInMinutes;
    private final MutableStateFlow<Boolean> _remindStartSession;
    private final MutableStateFlow<Integer> _remindStartSessionMinutes;
    private final MutableStateFlow<Boolean> _remindTaskDeadline;
    private final MutableStateFlow<Integer> _remindTaskDeadlineDays;
    private final MutableStateFlow<Integer> _remindTaskDeadlineHour;
    private final MutableStateFlow<Integer> _remindTaskDeadlineMinute;
    private final MutableStateFlow<String> _remindTaskDeadlineTime;
    private final MutableStateFlow<Boolean> _saveLogin;
    private final MutableStateFlow<String> _savedPin;
    private final MutableStateFlow<String> _selectedRole;
    private final MutableStateFlow<String> _userRole;
    private final StateFlow<Boolean> autoStartSession;
    private final StateFlow<Boolean> autoStartupEnabled;
    private final StateFlow<StudentProfileEntity> currentStudentProfile;
    private final StateFlow<TeacherEntity> currentTeacher;
    private final StateFlow<Boolean> enableBiometrics;
    private final StateFlow<Boolean> hasAccount;
    private final StateFlow<Boolean> isDbLoaded;
    private final StateFlow<Boolean> isLoggedIn;
    private final SharedPreferences prefs;
    private final StateFlow<Boolean> remindCheckIn;
    private final StateFlow<Integer> remindCheckInMinutes;
    private final StateFlow<Boolean> remindStartSession;
    private final StateFlow<Integer> remindStartSessionMinutes;
    private final StateFlow<Boolean> remindTaskDeadline;
    private final StateFlow<Integer> remindTaskDeadlineDays;
    private final StateFlow<Integer> remindTaskDeadlineHour;
    private final StateFlow<Integer> remindTaskDeadlineMinute;
    private final StateFlow<String> remindTaskDeadlineTime;
    private final CalisRepository repository;
    private final StateFlow<Boolean> saveLogin;
    private final StateFlow<String> savedPin;
    private final StateFlow<String> selectedRole;
    private final StateFlow<String> userRole;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AuthViewModel(Application application) {
        super(application);
        Intrinsics.checkNotNullParameter(application, "application");
        this.prefs = application.getSharedPreferences("calis_auth_prefs", 0);
        BlePermissionUtils.INSTANCE.setAppContext(application.getApplicationContext());
        this._isDbLoaded = StateFlowKt.MutableStateFlow(false);
        this.isDbLoaded = FlowKt.asStateFlow(this._isDbLoaded);
        this._hasAccount = StateFlowKt.MutableStateFlow(false);
        this.hasAccount = FlowKt.asStateFlow(this._hasAccount);
        this._saveLogin = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("save_login", true)));
        this.saveLogin = FlowKt.asStateFlow(this._saveLogin);
        this._enableBiometrics = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("enable_biometrics", false)));
        this.enableBiometrics = FlowKt.asStateFlow(this._enableBiometrics);
        this._autoStartSession = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("auto_start_session", true)));
        this.autoStartSession = FlowKt.asStateFlow(this._autoStartSession);
        this._remindStartSession = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("remind_start_session", false)));
        this.remindStartSession = FlowKt.asStateFlow(this._remindStartSession);
        this._remindStartSessionMinutes = StateFlowKt.MutableStateFlow(Integer.valueOf(this.prefs.getInt("remind_start_session_minutes", 15)));
        this.remindStartSessionMinutes = FlowKt.asStateFlow(this._remindStartSessionMinutes);
        this._remindTaskDeadline = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("remind_task_deadline", false)));
        this.remindTaskDeadline = FlowKt.asStateFlow(this._remindTaskDeadline);
        this._remindTaskDeadlineDays = StateFlowKt.MutableStateFlow(Integer.valueOf(this.prefs.getInt("remind_task_deadline_days", 1)));
        this.remindTaskDeadlineDays = FlowKt.asStateFlow(this._remindTaskDeadlineDays);
        this._remindTaskDeadlineHour = StateFlowKt.MutableStateFlow(Integer.valueOf(this.prefs.getInt("remind_task_deadline_time_hour", 8)));
        this.remindTaskDeadlineHour = FlowKt.asStateFlow(this._remindTaskDeadlineHour);
        this._remindTaskDeadlineMinute = StateFlowKt.MutableStateFlow(Integer.valueOf(this.prefs.getInt("remind_task_deadline_time_minute", 0)));
        this.remindTaskDeadlineMinute = FlowKt.asStateFlow(this._remindTaskDeadlineMinute);
        String string = this.prefs.getString("remind_task_deadline_time", "8:00 AM");
        this._remindTaskDeadlineTime = StateFlowKt.MutableStateFlow(string != null ? string : "8:00 AM");
        this.remindTaskDeadlineTime = FlowKt.asStateFlow(this._remindTaskDeadlineTime);
        this._autoStartupEnabled = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("auto_startup_enabled", true)));
        this.autoStartupEnabled = FlowKt.asStateFlow(this._autoStartupEnabled);
        this._remindCheckIn = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("remind_check_in", false)));
        this.remindCheckIn = FlowKt.asStateFlow(this._remindCheckIn);
        this._remindCheckInMinutes = StateFlowKt.MutableStateFlow(Integer.valueOf(this.prefs.getInt("remind_check_in_minutes", 15)));
        this.remindCheckInMinutes = FlowKt.asStateFlow(this._remindCheckInMinutes);
        String string2 = this.prefs.getString("saved_pin", "");
        this._savedPin = StateFlowKt.MutableStateFlow(string2 != null ? string2 : "");
        this.savedPin = FlowKt.asStateFlow(this._savedPin);
        this._isLoggedIn = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("is_logged_in", false)));
        this.isLoggedIn = FlowKt.asStateFlow(this._isLoggedIn);
        this._userRole = StateFlowKt.MutableStateFlow(this.prefs.getString("user_role", null));
        this.userRole = FlowKt.asStateFlow(this._userRole);
        CalisDatabase db = CalisDatabase.INSTANCE.getDatabase(application);
        this.repository = new CalisRepository(db, db.teacherDao(), db.studentProfileDao(), db.classroomDao(), db.approvedStudentDao(), db.pendingRegistrationDao(), db.attendanceDao(), db.taskDao(), db.taskSubmissionDao(), db.syncRecordDao());
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new AnonymousClass1(null), 2, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass2(null), 3, null);
        this.currentTeacher = FlowKt.stateIn(this.repository.getCurrentTeacher(), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        this.currentStudentProfile = FlowKt.stateIn(this.repository.getCurrentStudentProfile(), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        this._selectedRole = StateFlowKt.MutableStateFlow(null);
        this.selectedRole = FlowKt.asStateFlow(this._selectedRole);
    }

    public final StateFlow<Boolean> isDbLoaded() {
        return this.isDbLoaded;
    }

    public final StateFlow<Boolean> getHasAccount() {
        return this.hasAccount;
    }

    public final StateFlow<Boolean> getSaveLogin() {
        return this.saveLogin;
    }

    public final StateFlow<Boolean> getEnableBiometrics() {
        return this.enableBiometrics;
    }

    public final StateFlow<Boolean> getAutoStartSession() {
        return this.autoStartSession;
    }

    public final void setAutoStartSession(boolean enabled) {
        this.prefs.edit().putBoolean("auto_start_session", enabled).apply();
        this._autoStartSession.setValue(Boolean.valueOf(enabled));
    }

    public final StateFlow<Boolean> getRemindStartSession() {
        return this.remindStartSession;
    }

    public final StateFlow<Integer> getRemindStartSessionMinutes() {
        return this.remindStartSessionMinutes;
    }

    public final void setRemindStartSession(boolean enabled) {
        this.prefs.edit().putBoolean("remind_start_session", enabled).apply();
        this._remindStartSession.setValue(Boolean.valueOf(enabled));
        if (enabled) {
            Context ctx = getApplication().getApplicationContext();
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.clearSessionReminderKeys(ctx);
            ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(ctx);
            return;
        }
        ReminderNotificationHelper reminderNotificationHelper2 = ReminderNotificationHelper.INSTANCE;
        Context applicationContext = getApplication().getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
        reminderNotificationHelper2.cancelSessionReminder(applicationContext);
    }

    public final void setRemindStartSessionMinutes(int minutes) {
        this.prefs.edit().putInt("remind_start_session_minutes", minutes).apply();
        this._remindStartSessionMinutes.setValue(Integer.valueOf(minutes));
        if (this._remindStartSession.getValue().booleanValue()) {
            Context ctx = getApplication().getApplicationContext();
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.clearSessionReminderKeys(ctx);
            ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(ctx);
        }
    }

    public final StateFlow<Boolean> getRemindTaskDeadline() {
        return this.remindTaskDeadline;
    }

    public final StateFlow<Integer> getRemindTaskDeadlineDays() {
        return this.remindTaskDeadlineDays;
    }

    public final StateFlow<Integer> getRemindTaskDeadlineHour() {
        return this.remindTaskDeadlineHour;
    }

    public final StateFlow<Integer> getRemindTaskDeadlineMinute() {
        return this.remindTaskDeadlineMinute;
    }

    public final StateFlow<String> getRemindTaskDeadlineTime() {
        return this.remindTaskDeadlineTime;
    }

    public final StateFlow<Boolean> getAutoStartupEnabled() {
        return this.autoStartupEnabled;
    }

    public final StateFlow<Boolean> getRemindCheckIn() {
        return this.remindCheckIn;
    }

    public final StateFlow<Integer> getRemindCheckInMinutes() {
        return this.remindCheckInMinutes;
    }

    public final void setRemindCheckIn(boolean enabled) {
        this.prefs.edit().putBoolean("remind_check_in", enabled).apply();
        this._remindCheckIn.setValue(Boolean.valueOf(enabled));
        Context ctx = getApplication().getApplicationContext();
        if (enabled) {
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.checkAndPostCheckInReminder(ctx);
        }
    }

    public final void setRemindCheckInMinutes(int minutes) {
        this.prefs.edit().putInt("remind_check_in_minutes", minutes).apply();
        this._remindCheckInMinutes.setValue(Integer.valueOf(minutes));
        Context ctx = getApplication().getApplicationContext();
        if (this._remindCheckIn.getValue().booleanValue()) {
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.checkAndPostCheckInReminder(ctx);
        }
    }

    public final void setAutoStartupEnabled(boolean enabled) {
        this.prefs.edit().putBoolean("auto_startup_enabled", enabled).apply();
        this._autoStartupEnabled.setValue(Boolean.valueOf(enabled));
    }

    public final void setRemindTaskDeadline(boolean enabled) {
        this.prefs.edit().putBoolean("remind_task_deadline", enabled).apply();
        this._remindTaskDeadline.setValue(Boolean.valueOf(enabled));
        Context ctx = getApplication().getApplicationContext();
        if (enabled) {
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.clearTaskReminderKeys(ctx);
            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(ctx);
            return;
        }
        ReminderNotificationHelper reminderNotificationHelper2 = ReminderNotificationHelper.INSTANCE;
        Intrinsics.checkNotNull(ctx);
        reminderNotificationHelper2.cancelTaskDeadlineReminder(ctx);
    }

    public final void setRemindTaskDeadlineDays(int days) {
        this.prefs.edit().putInt("remind_task_deadline_days", days).apply();
        this._remindTaskDeadlineDays.setValue(Integer.valueOf(days));
        if (this._remindTaskDeadline.getValue().booleanValue()) {
            Context ctx = getApplication().getApplicationContext();
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.clearTaskReminderKeys(ctx);
            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(ctx);
        }
    }

    public final void setRemindTaskDeadlineTime(int hour, int minute) {
        int h12 = 12;
        String amPm = hour >= 12 ? "PM" : "AM";
        int h = hour % 12;
        if (h != 0) {
            h12 = h;
        }
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String formatted = String.format(Locale.US, "%d:%02d %s", Arrays.copyOf(new Object[]{Integer.valueOf(h12), Integer.valueOf(minute), amPm}, 3));
        Intrinsics.checkNotNullExpressionValue(formatted, "format(...)");
        this.prefs.edit().putInt("remind_task_deadline_time_hour", hour).putInt("remind_task_deadline_time_minute", minute).putString("remind_task_deadline_time", formatted).apply();
        this._remindTaskDeadlineHour.setValue(Integer.valueOf(hour));
        this._remindTaskDeadlineMinute.setValue(Integer.valueOf(minute));
        this._remindTaskDeadlineTime.setValue(formatted);
        if (this._remindTaskDeadline.getValue().booleanValue()) {
            Context ctx = getApplication().getApplicationContext();
            ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
            Intrinsics.checkNotNull(ctx);
            reminderNotificationHelper.clearTaskReminderKeys(ctx);
            ReminderNotificationHelper.INSTANCE.checkAndPostTaskDeadlineReminder(ctx);
        }
    }

    public final StateFlow<String> getSavedPin() {
        return this.savedPin;
    }

    public final StateFlow<Boolean> isLoggedIn() {
        return this.isLoggedIn;
    }

    public final StateFlow<String> getUserRole() {
        return this.userRole;
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$1", f = "AuthViewModel.kt", i = {0, 1, 1}, l = {ComposerKt.providerMapsKey, 205}, m = "invokeSuspend", n = {"savedRole", "savedRole", "student"}, s = {"L$0", "L$0", "L$1"})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        Object L$1;
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AuthViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0064 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:14:0x0065  */
        /* JADX WARN: Code duplicated, block: B:17:0x0074 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:19:0x0078  */
        /* JADX WARN: Code duplicated, block: B:21:0x007e A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:23:0x0082 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:24:0x0084  */
        /* JADX WARN: Code duplicated, block: B:25:0x0086 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:26:0x0088  */
        /* JADX WARN: Code duplicated, block: B:27:0x008a A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:29:0x008d  */
        /* JADX WARN: Code duplicated, block: B:32:0x0091  */
        /* JADX WARN: Code duplicated, block: B:35:0x00b3 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:36:0x00b5  */
        /* JADX WARN: Code duplicated, block: B:37:0x00b7  */
        /* JADX WARN: Code duplicated, block: B:38:0x00b9  */
        /* JADX WARN: Code duplicated, block: B:40:0x00bf A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:41:0x00c1  */
        /* JADX WARN: Code duplicated, block: B:42:0x00c3  */
        /* JADX WARN: Code duplicated, block: B:43:0x00c5  */
        /* JADX WARN: Code duplicated, block: B:44:0x00c7 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:47:0x00cc  */
        /* JADX WARN: Code duplicated, block: B:50:0x00e0 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:52:0x00f0  */
        /* JADX WARN: Code duplicated, block: B:54:0x00f8  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String savedRole;
            Object studentProfileOnce;
            StudentProfileEntity student;
            Object teacherOnce;
            StudentProfileEntity student2;
            TeacherEntity teacher;
            boolean hasActiveAccount;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            String determinedRole = null;
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    savedRole = AuthViewModel.this.prefs.getString("user_role", null);
                    this.L$0 = savedRole;
                    this.label = 1;
                    studentProfileOnce = AuthViewModel.this.repository.getStudentProfileOnce(this);
                    if (studentProfileOnce == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    student = (StudentProfileEntity) studentProfileOnce;
                    this.L$0 = savedRole;
                    this.L$1 = student;
                    this.label = 2;
                    teacherOnce = AuthViewModel.this.repository.getTeacherOnce(this);
                    if (teacherOnce == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    student2 = student;
                    teacher = (TeacherEntity) teacherOnce;
                    if (!Intrinsics.areEqual(savedRole, "STUDENT") && student2 != null) {
                        determinedRole = "STUDENT";
                    } else if (!Intrinsics.areEqual(savedRole, "TEACHER") && teacher != null) {
                        determinedRole = "TEACHER";
                    } else if (student2 != null) {
                        determinedRole = "STUDENT";
                    } else if (teacher != null) {
                        determinedRole = "TEACHER";
                    } else if (savedRole != null) {
                        determinedRole = savedRole;
                    }
                    if (determinedRole != null) {
                        AuthViewModel.this.prefs.edit().putString("user_role", determinedRole).apply();
                        AuthViewModel.this._userRole.setValue(determinedRole);
                    }
                    if (Intrinsics.areEqual(determinedRole, "STUDENT")) {
                        if (student2 != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (Intrinsics.areEqual(determinedRole, "TEACHER")) {
                        if (teacher != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (student2 == null || teacher != null) {
                        hasActiveAccount = true;
                    } else {
                        hasActiveAccount = false;
                    }
                    if (((Boolean) AuthViewModel.this._isLoggedIn.getValue()).booleanValue() || hasActiveAccount) {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(hasActiveAccount));
                    } else {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(true));
                    }
                    AuthViewModel.this._isDbLoaded.setValue(Boxing.boxBoolean(true));
                    return Unit.INSTANCE;
                case 1:
                    savedRole = (String) this.L$0;
                    ResultKt.throwOnFailure($result);
                    studentProfileOnce = $result;
                    student = (StudentProfileEntity) studentProfileOnce;
                    this.L$0 = savedRole;
                    this.L$1 = student;
                    this.label = 2;
                    teacherOnce = AuthViewModel.this.repository.getTeacherOnce(this);
                    if (teacherOnce == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    student2 = student;
                    teacher = (TeacherEntity) teacherOnce;
                    if (!Intrinsics.areEqual(savedRole, "STUDENT")) {
                        if (!Intrinsics.areEqual(savedRole, "TEACHER")) {
                            if (student2 != null) {
                                determinedRole = "STUDENT";
                            } else if (teacher != null) {
                                determinedRole = "TEACHER";
                            } else if (savedRole != null) {
                                determinedRole = savedRole;
                            }
                        } else if (student2 != null) {
                            determinedRole = "STUDENT";
                        } else if (teacher != null) {
                            determinedRole = "TEACHER";
                        } else if (savedRole != null) {
                            determinedRole = savedRole;
                        }
                    } else if (!Intrinsics.areEqual(savedRole, "TEACHER")) {
                        if (student2 != null) {
                            determinedRole = "STUDENT";
                        } else if (teacher != null) {
                            determinedRole = "TEACHER";
                        } else if (savedRole != null) {
                            determinedRole = savedRole;
                        }
                    } else if (student2 != null) {
                        determinedRole = "STUDENT";
                    } else if (teacher != null) {
                        determinedRole = "TEACHER";
                    } else if (savedRole != null) {
                        determinedRole = savedRole;
                    }
                    if (determinedRole != null) {
                        AuthViewModel.this.prefs.edit().putString("user_role", determinedRole).apply();
                        AuthViewModel.this._userRole.setValue(determinedRole);
                    }
                    if (Intrinsics.areEqual(determinedRole, "STUDENT")) {
                        if (student2 != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (Intrinsics.areEqual(determinedRole, "TEACHER")) {
                        if (teacher != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (student2 == null) {
                        hasActiveAccount = true;
                    } else {
                        hasActiveAccount = true;
                    }
                    if (((Boolean) AuthViewModel.this._isLoggedIn.getValue()).booleanValue()) {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(hasActiveAccount));
                    } else {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(hasActiveAccount));
                    }
                    AuthViewModel.this._isDbLoaded.setValue(Boxing.boxBoolean(true));
                    return Unit.INSTANCE;
                case 2:
                    student2 = (StudentProfileEntity) this.L$1;
                    savedRole = (String) this.L$0;
                    ResultKt.throwOnFailure($result);
                    teacherOnce = $result;
                    teacher = (TeacherEntity) teacherOnce;
                    if (!Intrinsics.areEqual(savedRole, "STUDENT")) {
                        if (!Intrinsics.areEqual(savedRole, "TEACHER")) {
                            if (student2 != null) {
                                determinedRole = "STUDENT";
                            } else if (teacher != null) {
                                determinedRole = "TEACHER";
                            } else if (savedRole != null) {
                                determinedRole = savedRole;
                            }
                        } else if (student2 != null) {
                            determinedRole = "STUDENT";
                        } else if (teacher != null) {
                            determinedRole = "TEACHER";
                        } else if (savedRole != null) {
                            determinedRole = savedRole;
                        }
                    } else if (!Intrinsics.areEqual(savedRole, "TEACHER")) {
                        if (student2 != null) {
                            determinedRole = "STUDENT";
                        } else if (teacher != null) {
                            determinedRole = "TEACHER";
                        } else if (savedRole != null) {
                            determinedRole = savedRole;
                        }
                    } else if (student2 != null) {
                        determinedRole = "STUDENT";
                    } else if (teacher != null) {
                        determinedRole = "TEACHER";
                    } else if (savedRole != null) {
                        determinedRole = savedRole;
                    }
                    if (determinedRole != null) {
                        AuthViewModel.this.prefs.edit().putString("user_role", determinedRole).apply();
                        AuthViewModel.this._userRole.setValue(determinedRole);
                    }
                    if (Intrinsics.areEqual(determinedRole, "STUDENT")) {
                        if (student2 != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (Intrinsics.areEqual(determinedRole, "TEACHER")) {
                        if (teacher != null) {
                            hasActiveAccount = true;
                        } else {
                            hasActiveAccount = false;
                        }
                    } else if (student2 == null) {
                        hasActiveAccount = true;
                    } else {
                        hasActiveAccount = true;
                    }
                    if (((Boolean) AuthViewModel.this._isLoggedIn.getValue()).booleanValue()) {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(hasActiveAccount));
                    } else {
                        AuthViewModel.this._hasAccount.setValue(Boxing.boxBoolean(hasActiveAccount));
                    }
                    AuthViewModel.this._isDbLoaded.setValue(Boxing.boxBoolean(true));
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$2, reason: invalid class name */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$2", f = "AuthViewModel.kt", i = {}, l = {242}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AuthViewModel.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$2$1, reason: invalid class name */
        /* JADX INFO: compiled from: AuthViewModel.kt */
        @Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\n"}, d2 = {"<anonymous>", "", "teacher", "Lcom/example/data/db/TeacherEntity;", "student", "Lcom/example/data/db/StudentProfileEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$2$1", f = "AuthViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass1 extends SuspendLambda implements Function3<TeacherEntity, StudentProfileEntity, Continuation<? super Boolean>, Object> {
            /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;
            int label;
            final /* synthetic */ AuthViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass1(AuthViewModel authViewModel, Continuation<? super AnonymousClass1> continuation) {
                super(3, continuation);
                this.this$0 = authViewModel;
            }

            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(TeacherEntity teacherEntity, StudentProfileEntity studentProfileEntity, Continuation<? super Boolean> continuation) {
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, continuation);
                anonymousClass1.L$0 = teacherEntity;
                anonymousClass1.L$1 = studentProfileEntity;
                return anonymousClass1.invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object $result) {
                TeacherEntity teacher = (TeacherEntity) this.L$0;
                StudentProfileEntity student = (StudentProfileEntity) this.L$1;
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String currentRole = (String) this.this$0._userRole.getValue();
                        if (currentRole == null) {
                            currentRole = this.this$0.prefs.getString("user_role", null);
                        }
                        boolean z = true;
                        if (Intrinsics.areEqual(currentRole, "STUDENT")) {
                            if (student == null) {
                                z = false;
                            }
                        } else if (Intrinsics.areEqual(currentRole, "TEACHER")) {
                            if (teacher == null) {
                                z = false;
                            }
                        } else if (student == null && teacher == null) {
                            z = false;
                        }
                        return Boxing.boxBoolean(z);
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow flowCombine = FlowKt.combine(AuthViewModel.this.repository.getCurrentTeacher(), AuthViewModel.this.repository.getCurrentStudentProfile(), new AnonymousClass1(AuthViewModel.this, null));
                    final AuthViewModel authViewModel = AuthViewModel.this;
                    this.label = 1;
                    if (flowCombine.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.AuthViewModel.2.2
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit(((Boolean) value).booleanValue(), (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(boolean accountExists, Continuation<? super Unit> continuation) {
                            if (((Boolean) authViewModel._isDbLoaded.getValue()).booleanValue()) {
                                authViewModel._hasAccount.setValue(Boxing.boxBoolean(accountExists));
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final StateFlow<TeacherEntity> getCurrentTeacher() {
        return this.currentTeacher;
    }

    public final StateFlow<StudentProfileEntity> getCurrentStudentProfile() {
        return this.currentStudentProfile;
    }

    public final StateFlow<String> getSelectedRole() {
        return this.selectedRole;
    }

    public final void selectRole(String role) {
        Intrinsics.checkNotNullParameter(role, "role");
        this._selectedRole.setValue(role);
    }

    public final void saveAuthCredentials(String pin, boolean biometrics, boolean saveLogin) {
        Intrinsics.checkNotNullParameter(pin, "pin");
        this.prefs.edit().putString("saved_pin", pin).putBoolean("enable_biometrics", biometrics).putBoolean("save_login", saveLogin).putBoolean("is_logged_in", true).apply();
        this._savedPin.setValue(pin);
        this._enableBiometrics.setValue(Boolean.valueOf(biometrics));
        this._saveLogin.setValue(Boolean.valueOf(saveLogin));
        this._isLoggedIn.setValue(true);
    }

    public final void setSaveLogin(boolean enabled) {
        this.prefs.edit().putBoolean("save_login", enabled).apply();
        this._saveLogin.setValue(Boolean.valueOf(enabled));
    }

    public final void setEnableBiometrics(boolean enabled) {
        this.prefs.edit().putBoolean("enable_biometrics", enabled).apply();
        this._enableBiometrics.setValue(Boolean.valueOf(enabled));
    }

    public final void setLoggedIn(boolean loggedIn) {
        this.prefs.edit().putBoolean("is_logged_in", loggedIn).apply();
        this._isLoggedIn.setValue(Boolean.valueOf(loggedIn));
    }

    public final void logout(Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        this.prefs.edit().putBoolean("is_logged_in", false).apply();
        this._isLoggedIn.setValue(false);
        CalisBleService.INSTANCE.stopService(getApplication());
        onComplete.invoke();
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$deleteAccountAndAllData$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$deleteAccountAndAllData$1", f = "AuthViewModel.kt", i = {}, l = {AnimationConstants.DefaultDurationMillis, 313}, m = "invokeSuspend", n = {}, s = {})
    static final class C07791 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function0<Unit> $onComplete;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07791(Function0<Unit> function0, Continuation<? super C07791> continuation) {
            super(2, continuation);
            this.$onComplete = function0;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AuthViewModel.this.new C07791(this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07791) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x00ef A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (AuthViewModel.this.repository.deleteAllData(this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    AuthViewModel.this.prefs.edit().clear().apply();
                    AuthViewModel.this._savedPin.setValue("");
                    AuthViewModel.this._enableBiometrics.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._saveLogin.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._isLoggedIn.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._selectedRole.setValue(null);
                    AuthViewModel.this._userRole.setValue(null);
                    AuthViewModel.this._remindStartSession.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._remindTaskDeadline.setValue(Boxing.boxBoolean(false));
                    ReminderNotificationHelper reminderNotificationHelper = ReminderNotificationHelper.INSTANCE;
                    Context applicationContext = AuthViewModel.this.getApplication().getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                    reminderNotificationHelper.cancelSessionReminder(applicationContext);
                    ReminderNotificationHelper reminderNotificationHelper2 = ReminderNotificationHelper.INSTANCE;
                    Context applicationContext2 = AuthViewModel.this.getApplication().getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext2, "getApplicationContext(...)");
                    reminderNotificationHelper2.cancelTaskDeadlineReminder(applicationContext2);
                    CalisBleService.INSTANCE.stopService(AuthViewModel.this.getApplication());
                    this.label = 2;
                    if (BuildersKt.withContext(Dispatchers.getMain(), new C01621(this.$onComplete, null), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    AuthViewModel.this.prefs.edit().clear().apply();
                    AuthViewModel.this._savedPin.setValue("");
                    AuthViewModel.this._enableBiometrics.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._saveLogin.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._isLoggedIn.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._selectedRole.setValue(null);
                    AuthViewModel.this._userRole.setValue(null);
                    AuthViewModel.this._remindStartSession.setValue(Boxing.boxBoolean(false));
                    AuthViewModel.this._remindTaskDeadline.setValue(Boxing.boxBoolean(false));
                    ReminderNotificationHelper reminderNotificationHelper3 = ReminderNotificationHelper.INSTANCE;
                    Context applicationContext3 = AuthViewModel.this.getApplication().getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext3, "getApplicationContext(...)");
                    reminderNotificationHelper3.cancelSessionReminder(applicationContext3);
                    ReminderNotificationHelper reminderNotificationHelper4 = ReminderNotificationHelper.INSTANCE;
                    Context applicationContext4 = AuthViewModel.this.getApplication().getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext4, "getApplicationContext(...)");
                    reminderNotificationHelper4.cancelTaskDeadlineReminder(applicationContext4);
                    CalisBleService.INSTANCE.stopService(AuthViewModel.this.getApplication());
                    this.label = 2;
                    if (BuildersKt.withContext(Dispatchers.getMain(), new C01621(this.$onComplete, null), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$deleteAccountAndAllData$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: AuthViewModel.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$deleteAccountAndAllData$1$1", f = "AuthViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class C01621 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Function0<Unit> $onComplete;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C01621(Function0<Unit> function0, Continuation<? super C01621> continuation) {
                super(2, continuation);
                this.$onComplete = function0;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C01621(this.$onComplete, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((C01621) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object $result) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.$onComplete.invoke();
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }
    }

    public final void deleteAccountAndAllData(Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new C07791(onComplete, null), 2, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$createTeacherProfile$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$createTeacherProfile$1", f = "AuthViewModel.kt", i = {0, 0}, l = {327}, m = "invokeSuspend", n = {"tid", "teacher"}, s = {"L$0", "L$1"})
    static final class C07771 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $fullName;
        final /* synthetic */ Function0<Unit> $onComplete;
        final /* synthetic */ String $sex;
        Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ AuthViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07771(String str, String str2, AuthViewModel authViewModel, Function0<Unit> function0, Continuation<? super C07771> continuation) {
            super(2, continuation);
            this.$fullName = str;
            this.$sex = str2;
            this.this$0 = authViewModel;
            this.$onComplete = function0;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C07771(this.$fullName, this.$sex, this.this$0, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07771) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    String tid = IdGenerator.INSTANCE.generateTID();
                    TeacherEntity teacher = new TeacherEntity(tid, StringsKt.trim((CharSequence) this.$fullName).toString(), this.$sex, 0L, 8, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(tid);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(teacher);
                    this.label = 1;
                    if (this.this$0.repository.saveTeacher(teacher, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            this.this$0.prefs.edit().putString("user_role", "TEACHER").apply();
            this.this$0._userRole.setValue("TEACHER");
            this.this$0._selectedRole.setValue("TEACHER");
            this.$onComplete.invoke();
            return Unit.INSTANCE;
        }
    }

    public static /* synthetic */ void createTeacherProfile$default(AuthViewModel authViewModel, String str, String str2, Function0 function0, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = "M";
        }
        authViewModel.createTeacherProfile(str, str2, function0);
    }

    public final void createTeacherProfile(String fullName, String sex, Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        Intrinsics.checkNotNullParameter(sex, "sex");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07771(fullName, sex, this, onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$createTeacherProfileWithClassroom$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$createTeacherProfileWithClassroom$1", f = "AuthViewModel.kt", i = {0, 0, 1, 1, 1, 1}, l = {366, 380}, m = "invokeSuspend", n = {"teacherTid", "teacher", "teacherTid", "teacher", "classroomCid", "classroom"}, s = {"L$0", "L$1", "L$0", "L$1", "L$2", "L$3"})
    static final class C07781 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $cid;
        final /* synthetic */ String $classroomName;
        final /* synthetic */ String $days;
        final /* synthetic */ String $endTime;
        final /* synthetic */ String $firstName;
        final /* synthetic */ String $fullName;
        final /* synthetic */ String $graceTime;
        final /* synthetic */ String $honorific;
        final /* synthetic */ String $middleName;
        final /* synthetic */ Function0<Unit> $onComplete;
        final /* synthetic */ String $sex;
        final /* synthetic */ String $startTime;
        final /* synthetic */ String $surname;
        final /* synthetic */ String $tid;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        final /* synthetic */ AuthViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07781(String str, String str2, AuthViewModel authViewModel, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, Function0<Unit> function0, Continuation<? super C07781> continuation) {
            super(2, continuation);
            this.$firstName = str;
            this.$surname = str2;
            this.this$0 = authViewModel;
            this.$middleName = str3;
            this.$honorific = str4;
            this.$tid = str5;
            this.$fullName = str6;
            this.$sex = str7;
            this.$cid = str8;
            this.$classroomName = str9;
            this.$days = str10;
            this.$startTime = str11;
            this.$graceTime = str12;
            this.$endTime = str13;
            this.$onComplete = function0;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C07781(this.$firstName, this.$surname, this.this$0, this.$middleName, this.$honorific, this.$tid, this.$fullName, this.$sex, this.$cid, this.$classroomName, this.$days, this.$startTime, this.$graceTime, this.$endTime, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07781) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:22:0x005d  */
        /* JADX WARN: Code duplicated, block: B:24:0x006d  */
        /* JADX WARN: Code duplicated, block: B:27:0x0078  */
        /* JADX WARN: Code duplicated, block: B:30:0x0083  */
        /* JADX WARN: Code duplicated, block: B:34:0x008f  */
        /* JADX WARN: Code duplicated, block: B:45:0x00d9  */
        /* JADX WARN: Code duplicated, block: B:48:0x0135 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:49:0x0136  */
        /* JADX WARN: Instruction removed from duplicated block: B:22:0x005d, please report this as an issue */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String str;
            String str2;
            String str3;
            TeacherEntity teacher;
            String teacherTid;
            String strGenerateCID;
            ClassroomEntity classroom;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    String str4 = this.$firstName;
                    if (str4 == null || StringsKt.isBlank(str4)) {
                        String str5 = this.$surname;
                        if (!(str5 == null || StringsKt.isBlank(str5))) {
                            SharedPreferences.Editor editorEdit = this.this$0.prefs.edit();
                            str = this.$firstName;
                            if (str == null) {
                                str = "";
                            }
                            SharedPreferences.Editor editorPutString = editorEdit.putString("teacher_first_name", str);
                            str2 = this.$middleName;
                            if (str2 == null) {
                                str2 = "";
                            }
                            SharedPreferences.Editor editorPutString2 = editorPutString.putString("teacher_middle_name", str2);
                            str3 = this.$surname;
                            if (str3 == null) {
                                str3 = "";
                            }
                            SharedPreferences.Editor editorPutString3 = editorPutString2.putString("teacher_surname", str3);
                            String str6 = this.$honorific;
                            editorPutString3.putString("teacher_honorific", str6 != null ? str6 : "").apply();
                        }
                    } else {
                        SharedPreferences.Editor editorEdit2 = this.this$0.prefs.edit();
                        str = this.$firstName;
                        if (str == null) {
                            str = "";
                        }
                        SharedPreferences.Editor editorPutString4 = editorEdit2.putString("teacher_first_name", str);
                        str2 = this.$middleName;
                        if (str2 == null) {
                            str2 = "";
                        }
                        SharedPreferences.Editor editorPutString5 = editorPutString4.putString("teacher_middle_name", str2);
                        str3 = this.$surname;
                        if (str3 == null) {
                            str3 = "";
                        }
                        SharedPreferences.Editor editorPutString6 = editorPutString5.putString("teacher_surname", str3);
                        String str7 = this.$honorific;
                        editorPutString6.putString("teacher_honorific", str7 != null ? str7 : "").apply();
                    }
                    String strGenerateTID = this.$tid;
                    if (strGenerateTID == null) {
                        strGenerateTID = IdGenerator.INSTANCE.generateTID();
                    }
                    String teacherTid2 = strGenerateTID;
                    TeacherEntity teacher2 = new TeacherEntity(teacherTid2, StringsKt.trim((CharSequence) this.$fullName).toString(), this.$sex, 0L, 8, null);
                    this.L$0 = teacherTid2;
                    this.L$1 = teacher2;
                    this.label = 1;
                    if (this.this$0.repository.saveTeacher(teacher2, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    teacher = teacher2;
                    teacherTid = teacherTid2;
                    strGenerateCID = this.$cid;
                    if (strGenerateCID == null) {
                        strGenerateCID = IdGenerator.INSTANCE.generateCID();
                    }
                    String classroomCid = strGenerateCID;
                    classroom = new ClassroomEntity(classroomCid, teacherTid, StringsKt.trim((CharSequence) this.$classroomName).toString(), teacher.getFullName(), this.$days, this.$startTime, this.$graceTime, this.$endTime, false, false, null, 1280, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(teacherTid);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(teacher);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(classroomCid);
                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroom);
                    this.label = 2;
                    if (this.this$0.repository.saveClassroom(classroom, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(this.this$0.getApplication());
                    this.this$0.prefs.edit().putString("user_role", "TEACHER").apply();
                    this.this$0._userRole.setValue("TEACHER");
                    this.this$0._selectedRole.setValue("TEACHER");
                    this.$onComplete.invoke();
                    return Unit.INSTANCE;
                case 1:
                    TeacherEntity teacher3 = (TeacherEntity) this.L$1;
                    String teacherTid3 = (String) this.L$0;
                    ResultKt.throwOnFailure($result);
                    teacherTid = teacherTid3;
                    teacher = teacher3;
                    strGenerateCID = this.$cid;
                    if (strGenerateCID == null) {
                        strGenerateCID = IdGenerator.INSTANCE.generateCID();
                    }
                    String classroomCid2 = strGenerateCID;
                    classroom = new ClassroomEntity(classroomCid2, teacherTid, StringsKt.trim((CharSequence) this.$classroomName).toString(), teacher.getFullName(), this.$days, this.$startTime, this.$graceTime, this.$endTime, false, false, null, 1280, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(teacherTid);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(teacher);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(classroomCid2);
                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroom);
                    this.label = 2;
                    if (this.this$0.repository.saveClassroom(classroom, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(this.this$0.getApplication());
                    this.this$0.prefs.edit().putString("user_role", "TEACHER").apply();
                    this.this$0._userRole.setValue("TEACHER");
                    this.this$0._selectedRole.setValue("TEACHER");
                    this.$onComplete.invoke();
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(this.this$0.getApplication());
                    this.this$0.prefs.edit().putString("user_role", "TEACHER").apply();
                    this.this$0._userRole.setValue("TEACHER");
                    this.this$0._selectedRole.setValue("TEACHER");
                    this.$onComplete.invoke();
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void createTeacherProfileWithClassroom(String fullName, String sex, String classroomName, String days, String startTime, String graceTime, String endTime, String tid, String cid, String firstName, String middleName, String surname, String honorific, Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        Intrinsics.checkNotNullParameter(sex, "sex");
        Intrinsics.checkNotNullParameter(classroomName, "classroomName");
        Intrinsics.checkNotNullParameter(days, "days");
        Intrinsics.checkNotNullParameter(startTime, "startTime");
        Intrinsics.checkNotNullParameter(graceTime, "graceTime");
        Intrinsics.checkNotNullParameter(endTime, "endTime");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07781(firstName, surname, this, middleName, honorific, tid, fullName, sex, cid, classroomName, days, startTime, graceTime, endTime, onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.AuthViewModel$createStudentProfile$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: AuthViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.AuthViewModel$createStudentProfile$1", f = "AuthViewModel.kt", i = {0, 0}, l = {406}, m = "invokeSuspend", n = {"sid", Scopes.PROFILE}, s = {"L$0", "L$1"})
    static final class C07761 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ long $birthDate;
        final /* synthetic */ String $fullName;
        final /* synthetic */ String $lrn;
        final /* synthetic */ Function0<Unit> $onComplete;
        final /* synthetic */ String $sex;
        Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ AuthViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07761(String str, String str2, String str3, long j, AuthViewModel authViewModel, Function0<Unit> function0, Continuation<? super C07761> continuation) {
            super(2, continuation);
            this.$fullName = str;
            this.$sex = str2;
            this.$lrn = str3;
            this.$birthDate = j;
            this.this$0 = authViewModel;
            this.$onComplete = function0;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C07761(this.$fullName, this.$sex, this.$lrn, this.$birthDate, this.this$0, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07761) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    String sid = IdGenerator.INSTANCE.generateSID();
                    StudentProfileEntity profile = new StudentProfileEntity(sid, StringsKt.trim((CharSequence) this.$fullName).toString(), this.$sex, StringsKt.trim((CharSequence) this.$lrn).toString(), this.$birthDate, 0L, 32, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(sid);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(profile);
                    this.label = 1;
                    if (this.this$0.repository.saveStudentProfile(profile, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            this.this$0.prefs.edit().putString("user_role", "STUDENT").apply();
            this.this$0._userRole.setValue("STUDENT");
            this.this$0._selectedRole.setValue("STUDENT");
            CalisBleService.INSTANCE.stopService(this.this$0.getApplication());
            this.$onComplete.invoke();
            return Unit.INSTANCE;
        }
    }

    public final void createStudentProfile(String fullName, String sex, String lrn, long birthDate, Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(fullName, "fullName");
        Intrinsics.checkNotNullParameter(sex, "sex");
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07761(fullName, sex, lrn, birthDate, this, onComplete, null), 3, null);
    }
}
