package com.example.ui.viewmodel;

import com.example.data.db.ApprovedStudentEntity;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableSharedFlow;

/* JADX INFO: compiled from: TeacherViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$4$1", f = "TeacherViewModel.kt", i = {}, l = {1300}, m = "invokeSuspend", n = {}, s = {})
final class TeacherViewModel$observeIncomingPackets$1$1$1$4$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ ApprovedStudentEntity $studentEntry;
    int label;
    final /* synthetic */ TeacherViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TeacherViewModel$observeIncomingPackets$1$1$1$4$1(TeacherViewModel teacherViewModel, ApprovedStudentEntity approvedStudentEntity, Continuation<? super TeacherViewModel$observeIncomingPackets$1$1$1$4$1> continuation) {
        super(2, continuation);
        this.this$0 = teacherViewModel;
        this.$studentEntry = approvedStudentEntity;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new TeacherViewModel$observeIncomingPackets$1$1$1$4$1(this.this$0, this.$studentEntry, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((TeacherViewModel$observeIncomingPackets$1$1$1$4$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                MutableSharedFlow mutableSharedFlow = this.this$0._userMessage;
                String studentName = this.$studentEntry.getStudentName();
                this.label = 1;
                if (mutableSharedFlow.emit("Attendance Marked for " + studentName, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}
