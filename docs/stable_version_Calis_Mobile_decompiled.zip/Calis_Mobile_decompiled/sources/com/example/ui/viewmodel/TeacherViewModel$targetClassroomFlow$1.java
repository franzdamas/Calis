package com.example.ui.viewmodel;

import com.example.data.db.ClassroomEntity;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function3;

/* JADX INFO: compiled from: TeacherViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u00012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", "Lcom/example/data/db/ClassroomEntity;", "active", "current"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$targetClassroomFlow$1", f = "TeacherViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class TeacherViewModel$targetClassroomFlow$1 extends SuspendLambda implements Function3<ClassroomEntity, ClassroomEntity, Continuation<? super ClassroomEntity>, Object> {
    /* synthetic */ Object L$0;
    /* synthetic */ Object L$1;
    int label;

    TeacherViewModel$targetClassroomFlow$1(Continuation<? super TeacherViewModel$targetClassroomFlow$1> continuation) {
        super(3, continuation);
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(ClassroomEntity classroomEntity, ClassroomEntity classroomEntity2, Continuation<? super ClassroomEntity> continuation) {
        TeacherViewModel$targetClassroomFlow$1 teacherViewModel$targetClassroomFlow$1 = new TeacherViewModel$targetClassroomFlow$1(continuation);
        teacherViewModel$targetClassroomFlow$1.L$0 = classroomEntity;
        teacherViewModel$targetClassroomFlow$1.L$1 = classroomEntity2;
        return teacherViewModel$targetClassroomFlow$1.invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        ClassroomEntity active = (ClassroomEntity) this.L$0;
        ClassroomEntity current = (ClassroomEntity) this.L$1;
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                return active == null ? current : active;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
