package com.example.ui.viewmodel;

import android.app.Application;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModelKt;
import com.example.ble.BleManager;
import com.example.ble.BlePacket;
import com.example.ble.CalisBleService;
import com.example.ble.DeviceState;
import com.example.data.db.ApprovedStudentEntity;
import com.example.data.db.AttendanceEntity;
import com.example.data.db.CalisDatabase;
import com.example.data.db.ClassroomEntity;
import com.example.data.db.PendingRegistrationEntity;
import com.example.data.db.TaskDeliveryEntity;
import com.example.data.db.TaskEntity;
import com.example.data.db.TaskSubmissionEntity;
import com.example.data.db.TeacherEntity;
import com.example.data.repository.CalisRepository;
import com.example.util.BlePermissionUtils;
import com.example.util.CsvExportUtils;
import com.example.util.IdGenerator;
import com.example.util.ReminderNotificationHelper;
import io.ktor.http.LinkHeader;
import io.ktor.sse.ServerSentEventKt;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharedFlow;
import kotlinx.coroutines.flow.SharedFlowKt;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import kotlinx.coroutines.sync.Mutex;
import kotlinx.coroutines.sync.MutexKt;

/* JADX INFO: compiled from: TeacherViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000ø\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u000e\n\u0002\u0010\"\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b=\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001:\u0002¿\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010N\u001a\u00020O2\u0006\u0010P\u001a\u000206J\u000e\u0010j\u001a\u00020O2\u0006\u0010k\u001a\u00020/J\u0006\u0010l\u001a\u00020OJ\u0012\u0010\u0083\u0001\u001a\u00020O2\t\b\u0002\u0010\u0084\u0001\u001a\u00020/J\u0007\u0010\u0085\u0001\u001a\u00020OJ\u0007\u0010\u0086\u0001\u001a\u00020OJ\u0010\u0010\u0087\u0001\u001a\u00020O2\u0007\u0010\u0088\u0001\u001a\u00020/J\u0012\u0010\u0089\u0001\u001a\u00020O2\t\u0010\u008a\u0001\u001a\u0004\u0018\u00010/J\u0019\u0010\u008b\u0001\u001a\u00020O2\u0007\u0010\u0088\u0001\u001a\u00020/2\u0007\u0010\u008a\u0001\u001a\u00020/J\u0007\u0010\u008c\u0001\u001a\u00020OJ\u001d\u0010\u008d\u0001\u001a\u00020O2\t\b\u0002\u0010\u008e\u0001\u001a\u00020/2\t\b\u0002\u0010\u008a\u0001\u001a\u00020/J$\u0010\u008f\u0001\u001a\u00020O2\u0007\u0010\u008a\u0001\u001a\u00020/2\u0007\u0010\u0088\u0001\u001a\u00020/2\t\b\u0002\u0010\u008e\u0001\u001a\u00020/J\u001b\u0010\u008f\u0001\u001a\u00020O2\u0007\u0010\u0090\u0001\u001a\u00020,2\t\b\u0002\u0010\u008e\u0001\u001a\u00020/J\u0012\u0010\u0091\u0001\u001a\u00020O2\t\u0010\u0092\u0001\u001a\u0004\u0018\u00010#J\u0012\u0010\u0093\u0001\u001a\u00020O2\t\b\u0002\u0010\u0094\u0001\u001a\u000206J\u0007\u0010\u0095\u0001\u001a\u00020OJ\u0010\u0010\u0096\u0001\u001a\u00020O2\u0007\u0010\u008a\u0001\u001a\u00020/J\u0007\u0010\u0097\u0001\u001a\u00020OJ\u0007\u0010\u0098\u0001\u001a\u00020OJ\u0007\u0010\u0099\u0001\u001a\u00020OJ\u0007\u0010\u009a\u0001\u001a\u00020OJ\u0007\u0010\u009b\u0001\u001a\u00020OJ\u0007\u0010\u009c\u0001\u001a\u00020OJ\u0010\u0010\u009d\u0001\u001a\u00020O2\u0007\u0010\u009e\u0001\u001a\u00020\u001aJ\u0010\u0010\u009f\u0001\u001a\u00020O2\u0007\u0010\u009e\u0001\u001a\u00020\u001aJ(\u0010 \u0001\u001a\u00020O2\u0007\u0010¡\u0001\u001a\u00020\u00122\r\u0010¢\u0001\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0019H\u0086@¢\u0006\u0003\u0010£\u0001J\u0007\u0010¤\u0001\u001a\u00020OJ\"\u0010¥\u0001\u001a\u00020O2\u0007\u0010¦\u0001\u001a\u00020/2\u0007\u0010§\u0001\u001a\u00020/2\u0007\u0010¨\u0001\u001a\u00020/J,\u0010©\u0001\u001a\u00020O2\u0007\u0010ª\u0001\u001a\u00020/2\u0007\u0010«\u0001\u001a\u00020/2\b\u0010¬\u0001\u001a\u00030\u00ad\u00012\u0007\u0010®\u0001\u001a\u00020eJ\u0010\u0010¯\u0001\u001a\u00020O2\u0007\u0010\u0092\u0001\u001a\u00020#J\u0010\u0010¯\u0001\u001a\u00020O2\u0007\u0010°\u0001\u001a\u00020/J\u001d\u0010±\u0001\u001a\u00020O2\u0014\u0010²\u0001\u001a\u000f\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020O0³\u0001J'\u0010´\u0001\u001a\u00020O2\b\u0010µ\u0001\u001a\u00030¶\u00012\u0014\u0010²\u0001\u001a\u000f\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020O0³\u0001J&\u0010·\u0001\u001a\u00020O2\u0007\u0010\u0092\u0001\u001a\u00020#2\u0014\u0010²\u0001\u001a\u000f\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020O0³\u0001J6\u0010¸\u0001\u001a\u00020O2\r\u0010¹\u0001\u001a\b\u0012\u0004\u0012\u00020#0\u00192\b\u0010µ\u0001\u001a\u00030º\u00012\u0014\u0010²\u0001\u001a\u000f\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020O0³\u0001J\u0007\u0010»\u0001\u001a\u00020OJ\t\u0010¼\u0001\u001a\u00020OH\u0002J\u0012\u0010½\u0001\u001a\u00020e2\u0007\u0010¾\u0001\u001a\u00020/H\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0019\u0010\f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\r¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0019\u0010\u0011\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0019\u0010\u0014\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0010R\u0019\u0010\u0016\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0010R\u001d\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001a0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0010R\u001d\u0010\u001c\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001d0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0010R\u001d\u0010\u001f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020 0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0010R\u001d\u0010\"\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020#0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0010R\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020&0\r¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0010R\u0017\u0010(\u001a\b\u0012\u0004\u0012\u00020)0\r¢\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0010R\u001d\u0010+\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020,0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b-\u0010\u0010R\u0017\u0010.\u001a\b\u0012\u0004\u0012\u00020/0\r¢\u0006\b\n\u0000\u001a\u0004\b0\u0010\u0010R\u0016\u00101\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010#02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u00103\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010#0\r¢\u0006\b\n\u0000\u001a\u0004\b4\u0010\u0010R\u0014\u00105\u001a\b\u0012\u0004\u0012\u00020602X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00107\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\b7\u0010\u0010R\u001d\u00108\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002090\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b:\u0010\u0010R\u001d\u0010;\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020<0\u00190\r¢\u0006\b\n\u0000\u001a\u0004\b=\u0010\u0010R\u0014\u0010>\u001a\b\u0012\u0004\u0012\u00020/0?X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010@\u001a\b\u0012\u0004\u0012\u00020/0A¢\u0006\b\n\u0000\u001a\u0004\bB\u0010CR\u0017\u0010D\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\bD\u0010\u0010R\u000e\u0010E\u001a\u000206X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010F\u001a\b\u0012\u0004\u0012\u00020602X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010G\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\bG\u0010\u0010R\u0016\u0010H\u001a\n J*\u0004\u0018\u00010I0IX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010K\u001a\b\u0012\u0004\u0012\u00020602X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010L\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\bM\u0010\u0010R\u0014\u0010Q\u001a\b\u0012\u0004\u0012\u00020602X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010R\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\bR\u0010\u0010R$\u0010T\u001a\u0002062\u0006\u0010S\u001a\u0002068F@FX\u0086\u000e¢\u0006\f\u001a\u0004\bT\u0010U\"\u0004\bV\u0010WR\u0016\u0010X\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010Y\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/0\r¢\u0006\b\n\u0000\u001a\u0004\bZ\u0010\u0010R\u0014\u0010[\u001a\b\u0012\u0004\u0012\u00020602X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\\\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\b\\\u0010\u0010R\u001a\u0010]\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020/0^02X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010_\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020/0^0\r¢\u0006\b\n\u0000\u001a\u0004\b`\u0010\u0010R\u000e\u0010a\u001a\u00020bX\u0082\u0004¢\u0006\u0002\n\u0000R \u0010c\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020e0d02X\u0082\u0004¢\u0006\u0002\n\u0000R#\u0010f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020/\u0012\u0004\u0012\u00020e0d0\r¢\u0006\b\n\u0000\u001a\u0004\bg\u0010\u0010R\u0017\u0010h\u001a\b\u0012\u0004\u0012\u00020e0\r¢\u0006\b\n\u0000\u001a\u0004\bi\u0010\u0010R\u0017\u0010m\u001a\b\u0012\u0004\u0012\u0002060\r¢\u0006\b\n\u0000\u001a\u0004\bm\u0010\u0010R\u0016\u0010n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010o02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010p\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010o0\r¢\u0006\b\n\u0000\u001a\u0004\bq\u0010\u0010R\u0014\u0010r\u001a\b\u0012\u0004\u0012\u00020/02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010s\u001a\b\u0012\u0004\u0012\u00020/0\r¢\u0006\b\n\u0000\u001a\u0004\bt\u0010\u0010R\u0016\u0010u\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010v\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/0\r¢\u0006\b\n\u0000\u001a\u0004\bw\u0010\u0010R\u0016\u0010x\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010y\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010/0\r¢\u0006\b\n\u0000\u001a\u0004\bz\u0010\u0010R\u0014\u0010{\u001a\b\u0012\u0004\u0012\u00020/02X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010|\u001a\b\u0012\u0004\u0012\u00020/0\r¢\u0006\b\n\u0000\u001a\u0004\b}\u0010\u0010R\u001f\u0010~\u001a\u0004\u0018\u00010\u0012X\u0086\u000e¢\u0006\u0011\n\u0000\u001a\u0005\b\u007f\u0010\u0080\u0001\"\u0006\b\u0081\u0001\u0010\u0082\u0001¨\u0006À\u0001"}, d2 = {"Lcom/example/ui/viewmodel/TeacherViewModel;", "Landroidx/lifecycle/AndroidViewModel;", "application", "Landroid/app/Application;", "<init>", "(Landroid/app/Application;)V", "repository", "Lcom/example/data/repository/CalisRepository;", "bleManager", "Lcom/example/ble/BleManager;", "getBleManager", "()Lcom/example/ble/BleManager;", "currentTeacher", "Lkotlinx/coroutines/flow/StateFlow;", "Lcom/example/data/db/TeacherEntity;", "getCurrentTeacher", "()Lkotlinx/coroutines/flow/StateFlow;", "activeClassroom", "Lcom/example/data/db/ClassroomEntity;", "getActiveClassroom", "currentClassroom", "getCurrentClassroom", "targetClassroom", "getTargetClassroom", "pendingRegistrations", "", "Lcom/example/data/db/PendingRegistrationEntity;", "getPendingRegistrations", "approvedStudents", "Lcom/example/data/db/ApprovedStudentEntity;", "getApprovedStudents", "attendanceLogs", "Lcom/example/data/db/AttendanceEntity;", "getAttendanceLogs", "tasks", "Lcom/example/data/db/TaskEntity;", "getTasks", "connectionState", "Lcom/example/ble/BleManager$ConnectionState;", "getConnectionState", "deviceState", "Lcom/example/ble/DeviceState;", "getDeviceState", "scannedDevices", "Lcom/example/ble/BleManager$ScannedDevice;", "getScannedDevices", "lastTxResponse", "", "getLastTxResponse", "_selectedTaskForSubmissions", "Lkotlinx/coroutines/flow/MutableStateFlow;", "selectedTaskForSubmissions", "getSelectedTaskForSubmissions", "_isSubmissionsLoading", "", "isSubmissionsLoading", "currentSubmissions", "Lcom/example/data/db/TaskSubmissionEntity;", "getCurrentSubmissions", "currentDeliveries", "Lcom/example/data/db/TaskDeliveryEntity;", "getCurrentDeliveries", "_userMessage", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "userMessage", "Lkotlinx/coroutines/flow/SharedFlow;", "getUserMessage", "()Lkotlinx/coroutines/flow/SharedFlow;", "isAuthenticated", "hasAttemptedStartupAutoConnect", "_isUserDisconnected", "isUserDisconnected", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "_autoApproveEnabled", "autoApproveEnabled", "getAutoApproveEnabled", "setAutoApproveEnabled", "", "enabled", "_isWaitingForReconnect", "isWaitingForReconnectFlow", "value", "isWaitingForReconnect", "()Z", "setWaitingForReconnect", "(Z)V", "_savedMacAddress", "savedMacAddress", "getSavedMacAddress", "_isClassroomLoaded", "isClassroomLoaded", "_unviewedSubmittedTaskIds", "", "unviewedSubmittedTaskIds", "getUnviewedSubmittedTaskIds", "submissionMutex", "Lkotlinx/coroutines/sync/Mutex;", "_taskUnviewedSubmissionCounts", "", "", "taskUnviewedSubmissionCounts", "getTaskUnviewedSubmissionCounts", "unviewedTaskSubmissionsCount", "getUnviewedTaskSubmissionsCount", "markTaskSubmissionsAsViewed", "taskId", "clearAllUnviewedSubmissions", "isControlsEnabled", "_regDialogStep", "Lcom/example/ui/viewmodel/TeacherViewModel$RegDialogStep;", "regDialogStep", "getRegDialogStep", "_registrationClassroomName", "registrationClassroomName", "getRegistrationClassroomName", "_registrationDeviceAddress", "registrationDeviceAddress", "getRegistrationDeviceAddress", "_registrationDeviceName", "registrationDeviceName", "getRegistrationDeviceName", "_registrationButtonText", "registrationButtonText", "getRegistrationButtonText", "tempClassroomToRegister", "getTempClassroomToRegister", "()Lcom/example/data/db/ClassroomEntity;", "setTempClassroomToRegister", "(Lcom/example/data/db/ClassroomEntity;)V", "startRegistrationDialog", "initialClassroomName", "cancelRegistrationDialog", "stopRegistrationFlow", "setRegistrationClassroomName", "name", "setSavedMacAddress", "address", "setRegistrationSelectedDevice", "onRegistrationNextClicked", "startRegistrationFlow", "classroomName", "initiateDeviceRegistration", "selectedDevice", "selectTaskForSubmissions", "task", "startBleScan", "forceRestart", "stopBleScan", "connectToDevice", "disconnectDevice", "authenticateDevice", "checkAndAutoAuthenticate", "startSession", "endSession", "unregisterDevice", "approveStudent", "pending", "rejectStudent", "checkAndInitializeDailyAttendance", "classroom", "students", "(Lcom/example/data/db/ClassroomEntity;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "refreshDailyAttendance", "updateAttendanceStatus", "studentId", "dateStr", "newStatus", "createTask", LinkHeader.Parameters.Title, "description", "deadline", "", "maxScore", "deleteTask", "tkid", "exportAttendanceData", "onComplete", "Lkotlin/Function1;", "exportCustomAttendanceCsv", "config", "Lcom/example/util/CsvExportUtils$AttendanceExportConfig;", "exportTaskSubmissionsData", "exportCustomTasksCsv", "selectedTasks", "Lcom/example/util/CsvExportUtils$TasksExportConfig;", "resetAllState", "observeIncomingPackets", "parseTimeToMinutes", "raw", "RegDialogStep", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class TeacherViewModel extends AndroidViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<Boolean> _autoApproveEnabled;
    private final MutableStateFlow<Boolean> _isClassroomLoaded;
    private final MutableStateFlow<Boolean> _isSubmissionsLoading;
    private final MutableStateFlow<Boolean> _isUserDisconnected;
    private final MutableStateFlow<Boolean> _isWaitingForReconnect;
    private final MutableStateFlow<RegDialogStep> _regDialogStep;
    private final MutableStateFlow<String> _registrationButtonText;
    private final MutableStateFlow<String> _registrationClassroomName;
    private final MutableStateFlow<String> _registrationDeviceAddress;
    private final MutableStateFlow<String> _registrationDeviceName;
    private final MutableStateFlow<String> _savedMacAddress;
    private final MutableStateFlow<TaskEntity> _selectedTaskForSubmissions;
    private final MutableStateFlow<Map<String, Integer>> _taskUnviewedSubmissionCounts;
    private final MutableStateFlow<Set<String>> _unviewedSubmittedTaskIds;
    private final MutableSharedFlow<String> _userMessage;
    private final StateFlow<ClassroomEntity> activeClassroom;
    private final StateFlow<List<ApprovedStudentEntity>> approvedStudents;
    private final StateFlow<List<AttendanceEntity>> attendanceLogs;
    private final StateFlow<Boolean> autoApproveEnabled;
    private final BleManager bleManager;
    private final StateFlow<BleManager.ConnectionState> connectionState;
    private final StateFlow<ClassroomEntity> currentClassroom;
    private final StateFlow<List<TaskDeliveryEntity>> currentDeliveries;
    private final StateFlow<List<TaskSubmissionEntity>> currentSubmissions;
    private final StateFlow<TeacherEntity> currentTeacher;
    private final StateFlow<DeviceState> deviceState;
    private boolean hasAttemptedStartupAutoConnect;
    private final StateFlow<Boolean> isAuthenticated;
    private final StateFlow<Boolean> isClassroomLoaded;
    private final StateFlow<Boolean> isControlsEnabled;
    private final StateFlow<Boolean> isSubmissionsLoading;
    private final StateFlow<Boolean> isUserDisconnected;
    private final StateFlow<Boolean> isWaitingForReconnectFlow;
    private final StateFlow<String> lastTxResponse;
    private final StateFlow<List<PendingRegistrationEntity>> pendingRegistrations;
    private final SharedPreferences prefs;
    private final StateFlow<RegDialogStep> regDialogStep;
    private final StateFlow<String> registrationButtonText;
    private final StateFlow<String> registrationClassroomName;
    private final StateFlow<String> registrationDeviceAddress;
    private final StateFlow<String> registrationDeviceName;
    private final CalisRepository repository;
    private final StateFlow<String> savedMacAddress;
    private final StateFlow<List<BleManager.ScannedDevice>> scannedDevices;
    private final StateFlow<TaskEntity> selectedTaskForSubmissions;
    private final Mutex submissionMutex;
    private final StateFlow<ClassroomEntity> targetClassroom;
    private final StateFlow<Map<String, Integer>> taskUnviewedSubmissionCounts;
    private final StateFlow<List<TaskEntity>> tasks;
    private ClassroomEntity tempClassroomToRegister;
    private final StateFlow<Set<String>> unviewedSubmittedTaskIds;
    private final StateFlow<Integer> unviewedTaskSubmissionsCount;
    private final SharedFlow<String> userMessage;

    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"}, d2 = {"Lcom/example/ui/viewmodel/TeacherViewModel$RegDialogStep;", "", "<init>", "(Ljava/lang/String;I)V", "DISCOVERING", "CONNECTING", "REGISTERING", "AUTHENTICATING", "SUCCESS", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public enum RegDialogStep {
        DISCOVERING,
        CONNECTING,
        REGISTERING,
        AUTHENTICATING,
        SUCCESS;

        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        public static EnumEntries<RegDialogStep> getEntries() {
            return $ENTRIES;
        }
    }

    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[RegDialogStep.values().length];
            try {
                iArr[RegDialogStep.DISCOVERING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[RegDialogStep.CONNECTING.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[RegDialogStep.REGISTERING.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[RegDialogStep.AUTHENTICATING.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[RegDialogStep.SUCCESS.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$checkAndInitializeDailyAttendance$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel", f = "TeacherViewModel.kt", i = {0, 0, 0, 1, 1, 1, 1, 1, 1, 1}, l = {940, 946}, m = "checkAndInitializeDailyAttendance", n = {"classroom", "students", "todayDateStr", "classroom", "students", "todayDateStr", "existingLogs", "existingStudentIds", "student", "timestamp"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$6", "J$0"})
    static final class C07961 extends ContinuationImpl {
        long J$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        int label;
        /* synthetic */ Object result;

        C07961(Continuation<? super C07961> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return TeacherViewModel.this.checkAndInitializeDailyAttendance(null, null, this);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TeacherViewModel(Application application) {
        super(application);
        Intrinsics.checkNotNullParameter(application, "application");
        this.bleManager = BleManager.INSTANCE.getInstance(application);
        this.connectionState = this.bleManager.getConnectionState();
        this.deviceState = this.bleManager.getDeviceState();
        this.scannedDevices = this.bleManager.getScannedDevices();
        this.lastTxResponse = this.bleManager.getLastTxResponse();
        this._selectedTaskForSubmissions = StateFlowKt.MutableStateFlow(null);
        this.selectedTaskForSubmissions = FlowKt.asStateFlow(this._selectedTaskForSubmissions);
        this._isSubmissionsLoading = StateFlowKt.MutableStateFlow(false);
        this.isSubmissionsLoading = FlowKt.asStateFlow(this._isSubmissionsLoading);
        this._userMessage = SharedFlowKt.MutableSharedFlow$default(0, 10, null, 5, null);
        this.userMessage = FlowKt.asSharedFlow(this._userMessage);
        this.isAuthenticated = this.bleManager.isAuthenticated();
        this._isUserDisconnected = StateFlowKt.MutableStateFlow(false);
        this.isUserDisconnected = FlowKt.asStateFlow(this._isUserDisconnected);
        this.prefs = application.getSharedPreferences("calis_auth_prefs", 0);
        this._autoApproveEnabled = StateFlowKt.MutableStateFlow(Boolean.valueOf(this.prefs.getBoolean("auto_approve_enabled", true)));
        this.autoApproveEnabled = FlowKt.asStateFlow(this._autoApproveEnabled);
        this._isWaitingForReconnect = StateFlowKt.MutableStateFlow(false);
        this.isWaitingForReconnectFlow = FlowKt.asStateFlow(this._isWaitingForReconnect);
        this._savedMacAddress = StateFlowKt.MutableStateFlow(null);
        this.savedMacAddress = FlowKt.asStateFlow(this._savedMacAddress);
        this._isClassroomLoaded = StateFlowKt.MutableStateFlow(false);
        this.isClassroomLoaded = FlowKt.asStateFlow(this._isClassroomLoaded);
        this._unviewedSubmittedTaskIds = StateFlowKt.MutableStateFlow(SetsKt.emptySet());
        this.unviewedSubmittedTaskIds = FlowKt.asStateFlow(this._unviewedSubmittedTaskIds);
        this.submissionMutex = MutexKt.Mutex$default(false, 1, null);
        this._taskUnviewedSubmissionCounts = StateFlowKt.MutableStateFlow(MapsKt.emptyMap());
        this.taskUnviewedSubmissionCounts = FlowKt.asStateFlow(this._taskUnviewedSubmissionCounts);
        final Flow flow = this._unviewedSubmittedTaskIds;
        this.unviewedTaskSubmissionsCount = FlowKt.stateIn(new Flow<Integer>() { // from class: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$1
            @Override // kotlinx.coroutines.flow.Flow
            public Object collect(FlowCollector<? super Integer> flowCollector, Continuation $completion) {
                Object objCollect = flow.collect(new AnonymousClass2(flowCollector), $completion);
                return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$1$2, reason: invalid class name */
            /* JADX INFO: compiled from: Emitters.kt */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class AnonymousClass2<T> implements FlowCollector {
                final /* synthetic */ FlowCollector $this_unsafeFlow;

                /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$1$2$1, reason: invalid class name */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$1$2", f = "TeacherViewModel.kt", i = {0, 0, 0, 0, 0}, l = {50}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"})
                public static final class AnonymousClass1 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    public AnonymousClass1(Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object emit(Object value, Continuation $completion) {
                    AnonymousClass1 $completion2;
                    if ($completion instanceof AnonymousClass1) {
                        $completion2 = (AnonymousClass1) $completion;
                        if (($completion2.label & Integer.MIN_VALUE) != 0) {
                            $completion2.label -= Integer.MIN_VALUE;
                        } else {
                            $completion2 = new AnonymousClass1($completion);
                        }
                    } else {
                        $completion2 = new AnonymousClass1($completion);
                    }
                    Object $result = $completion2.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch ($completion2.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                            Integer numBoxInt = Boxing.boxInt(((Set) value).size());
                            $completion2.L$0 = SpillingKt.nullOutSpilledVariable(value);
                            $completion2.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                            $completion2.L$2 = SpillingKt.nullOutSpilledVariable(value);
                            $completion2.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                            $completion2.I$0 = 0;
                            $completion2.label = 1;
                            if ($this$map_u24lambda_u245.emit(numBoxInt, $completion2) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            int i = $completion2.I$0;
                            Object obj = $completion2.L$2;
                            Object value2 = $completion2.L$0;
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }
        }, ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), 0);
        this.isControlsEnabled = FlowKt.stateIn(FlowKt.combine(this.bleManager.getConnectionState(), this.bleManager.isAuthenticated(), this.bleManager.getDeviceState(), new C08061(null)), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), false);
        this._regDialogStep = StateFlowKt.MutableStateFlow(null);
        this.regDialogStep = FlowKt.asStateFlow(this._regDialogStep);
        this._registrationClassroomName = StateFlowKt.MutableStateFlow("");
        this.registrationClassroomName = FlowKt.asStateFlow(this._registrationClassroomName);
        this._registrationDeviceAddress = StateFlowKt.MutableStateFlow(null);
        this.registrationDeviceAddress = FlowKt.asStateFlow(this._registrationDeviceAddress);
        this._registrationDeviceName = StateFlowKt.MutableStateFlow(null);
        this.registrationDeviceName = FlowKt.asStateFlow(this._registrationDeviceName);
        this._registrationButtonText = StateFlowKt.MutableStateFlow("Search Setup Calis");
        this.registrationButtonText = FlowKt.asStateFlow(this._registrationButtonText);
        CalisDatabase db = CalisDatabase.INSTANCE.getDatabase(application);
        this.repository = new CalisRepository(db, db.teacherDao(), db.studentProfileDao(), db.classroomDao(), db.approvedStudentDao(), db.pendingRegistrationDao(), db.attendanceDao(), db.taskDao(), db.taskSubmissionDao(), db.syncRecordDao());
        this.currentTeacher = FlowKt.stateIn(this.repository.getCurrentTeacher(), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        this.activeClassroom = FlowKt.stateIn(this.repository.getActiveBoundClassroom(), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        this.currentClassroom = FlowKt.stateIn(FlowKt.transformLatest(this.currentTeacher, new TeacherViewModel$special$$inlined$flatMapLatest$1(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        Flow targetClassroomFlow = FlowKt.flowCombine(this.activeClassroom, this.currentClassroom, new TeacherViewModel$targetClassroomFlow$1(null));
        this.targetClassroom = FlowKt.stateIn(targetClassroomFlow, ViewModelKt.getViewModelScope(this), SharingStarted.INSTANCE.getEagerly(), null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass2(targetClassroomFlow, this, application, null), 3, null);
        final Flow flowTransformLatest = FlowKt.transformLatest(targetClassroomFlow, new TeacherViewModel$special$$inlined$flatMapLatest$2(null, this));
        this.pendingRegistrations = FlowKt.stateIn(new Flow<List<? extends PendingRegistrationEntity>>() { // from class: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$2
            @Override // kotlinx.coroutines.flow.Flow
            public Object collect(FlowCollector<? super List<? extends PendingRegistrationEntity>> flowCollector, Continuation $completion) {
                Object objCollect = flowTransformLatest.collect(new AnonymousClass2(flowCollector), $completion);
                return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$2$2, reason: invalid class name */
            /* JADX INFO: compiled from: Emitters.kt */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class AnonymousClass2<T> implements FlowCollector {
                final /* synthetic */ FlowCollector $this_unsafeFlow;

                /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$2$2$1, reason: invalid class name */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$special$$inlined$map$2$2", f = "TeacherViewModel.kt", i = {0, 0, 0, 0, 0}, l = {50}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"})
                public static final class AnonymousClass1 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    public AnonymousClass1(Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object emit(Object value, Continuation $completion) {
                    AnonymousClass1 anonymousClass1;
                    if ($completion instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) $completion;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1($completion);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1($completion);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                            Continuation $completion2 = anonymousClass1;
                            HashSet hashSet = new HashSet();
                            ArrayList arrayList = new ArrayList();
                            for (Object obj : (List) value) {
                                if (hashSet.add(((PendingRegistrationEntity) obj).getStudentId())) {
                                    arrayList.add(obj);
                                }
                            }
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                            anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                            anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                            anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                            anonymousClass1.I$0 = 0;
                            anonymousClass1.label = 1;
                            if ($this$map_u24lambda_u245.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                            break;
                        case 1:
                            int i = anonymousClass1.I$0;
                            Object obj2 = anonymousClass1.L$2;
                            Object obj3 = anonymousClass1.L$0;
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }
        }, ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.approvedStudents = FlowKt.stateIn(FlowKt.transformLatest(targetClassroomFlow, new TeacherViewModel$special$$inlined$flatMapLatest$3(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.attendanceLogs = FlowKt.stateIn(FlowKt.transformLatest(targetClassroomFlow, new TeacherViewModel$special$$inlined$flatMapLatest$4(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.tasks = FlowKt.stateIn(FlowKt.transformLatest(targetClassroomFlow, new TeacherViewModel$special$$inlined$flatMapLatest$5(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.currentSubmissions = FlowKt.stateIn(FlowKt.transformLatest(this._selectedTaskForSubmissions, new TeacherViewModel$special$$inlined$flatMapLatest$6(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.currentDeliveries = FlowKt.stateIn(FlowKt.transformLatest(this._selectedTaskForSubmissions, new TeacherViewModel$special$$inlined$flatMapLatest$7(null, this)), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.bleManager.resetBleStateOnStartup(false);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass10(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass11(targetClassroomFlow, this, null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass12(application, null), 3, null);
        observeIncomingPackets();
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass13(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass14(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass15(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass16(null), 3, null);
    }

    public final BleManager getBleManager() {
        return this.bleManager;
    }

    public final StateFlow<TeacherEntity> getCurrentTeacher() {
        return this.currentTeacher;
    }

    public final StateFlow<ClassroomEntity> getActiveClassroom() {
        return this.activeClassroom;
    }

    public final StateFlow<ClassroomEntity> getCurrentClassroom() {
        return this.currentClassroom;
    }

    public final StateFlow<ClassroomEntity> getTargetClassroom() {
        return this.targetClassroom;
    }

    public final StateFlow<List<PendingRegistrationEntity>> getPendingRegistrations() {
        return this.pendingRegistrations;
    }

    public final StateFlow<List<ApprovedStudentEntity>> getApprovedStudents() {
        return this.approvedStudents;
    }

    public final StateFlow<List<AttendanceEntity>> getAttendanceLogs() {
        return this.attendanceLogs;
    }

    public final StateFlow<List<TaskEntity>> getTasks() {
        return this.tasks;
    }

    public final StateFlow<BleManager.ConnectionState> getConnectionState() {
        return this.connectionState;
    }

    public final StateFlow<DeviceState> getDeviceState() {
        return this.deviceState;
    }

    public final StateFlow<List<BleManager.ScannedDevice>> getScannedDevices() {
        return this.scannedDevices;
    }

    public final StateFlow<String> getLastTxResponse() {
        return this.lastTxResponse;
    }

    public final StateFlow<TaskEntity> getSelectedTaskForSubmissions() {
        return this.selectedTaskForSubmissions;
    }

    public final StateFlow<Boolean> isSubmissionsLoading() {
        return this.isSubmissionsLoading;
    }

    public final StateFlow<List<TaskSubmissionEntity>> getCurrentSubmissions() {
        return this.currentSubmissions;
    }

    public final StateFlow<List<TaskDeliveryEntity>> getCurrentDeliveries() {
        return this.currentDeliveries;
    }

    public final SharedFlow<String> getUserMessage() {
        return this.userMessage;
    }

    public final StateFlow<Boolean> isAuthenticated() {
        return this.isAuthenticated;
    }

    public final StateFlow<Boolean> isUserDisconnected() {
        return this.isUserDisconnected;
    }

    public final StateFlow<Boolean> getAutoApproveEnabled() {
        return this.autoApproveEnabled;
    }

    public final void setAutoApproveEnabled(boolean enabled) {
        this.prefs.edit().putBoolean("auto_approve_enabled", enabled).apply();
        this._autoApproveEnabled.setValue(Boolean.valueOf(enabled));
    }

    public final StateFlow<Boolean> isWaitingForReconnectFlow() {
        return this.isWaitingForReconnectFlow;
    }

    public final boolean isWaitingForReconnect() {
        return this._isWaitingForReconnect.getValue().booleanValue();
    }

    public final void setWaitingForReconnect(boolean value) {
        this._isWaitingForReconnect.setValue(Boolean.valueOf(value));
    }

    public final StateFlow<String> getSavedMacAddress() {
        return this.savedMacAddress;
    }

    public final StateFlow<Boolean> isClassroomLoaded() {
        return this.isClassroomLoaded;
    }

    public final StateFlow<Set<String>> getUnviewedSubmittedTaskIds() {
        return this.unviewedSubmittedTaskIds;
    }

    public final StateFlow<Map<String, Integer>> getTaskUnviewedSubmissionCounts() {
        return this.taskUnviewedSubmissionCounts;
    }

    public final StateFlow<Integer> getUnviewedTaskSubmissionsCount() {
        return this.unviewedTaskSubmissionsCount;
    }

    public final void markTaskSubmissionsAsViewed(String taskId) {
        Intrinsics.checkNotNullParameter(taskId, "taskId");
        this._unviewedSubmittedTaskIds.setValue(SetsKt.minus(this._unviewedSubmittedTaskIds.getValue(), taskId));
        Map<String, Integer> mutableMap = MapsKt.toMutableMap(this._taskUnviewedSubmissionCounts.getValue());
        mutableMap.put(taskId, 0);
        this._taskUnviewedSubmissionCounts.setValue(mutableMap);
    }

    public final void clearAllUnviewedSubmissions() {
        this._unviewedSubmittedTaskIds.setValue(SetsKt.emptySet());
        this._taskUnviewedSubmissionCounts.setValue(MapsKt.emptyMap());
    }

    public final StateFlow<Boolean> isControlsEnabled() {
        return this.isControlsEnabled;
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$isControlsEnabled$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0006H\n"}, d2 = {"<anonymous>", "", "conn", "Lcom/example/ble/BleManager$ConnectionState;", "auth", "devState", "Lcom/example/ble/DeviceState;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$isControlsEnabled$1", f = "TeacherViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C08061 extends SuspendLambda implements Function4<BleManager.ConnectionState, Boolean, DeviceState, Continuation<? super Boolean>, Object> {
        /* synthetic */ Object L$0;
        /* synthetic */ Object L$1;
        /* synthetic */ boolean Z$0;
        int label;

        C08061(Continuation<? super C08061> continuation) {
            super(4, continuation);
        }

        public final Object invoke(BleManager.ConnectionState connectionState, boolean z, DeviceState deviceState, Continuation<? super Boolean> continuation) {
            C08061 c08061 = new C08061(continuation);
            c08061.L$0 = connectionState;
            c08061.Z$0 = z;
            c08061.L$1 = deviceState;
            return c08061.invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.jvm.functions.Function4
        public /* bridge */ /* synthetic */ Object invoke(BleManager.ConnectionState connectionState, Boolean bool, DeviceState deviceState, Continuation<? super Boolean> continuation) {
            return invoke(connectionState, bool.booleanValue(), deviceState, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            BleManager.ConnectionState conn = (BleManager.ConnectionState) this.L$0;
            boolean auth = this.Z$0;
            DeviceState devState = (DeviceState) this.L$1;
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    return Boxing.boxBoolean((conn instanceof BleManager.ConnectionState.Connected) && auth && (devState == DeviceState.SESSION_INACTIVE || devState == DeviceState.SESSION_ACTIVE_OPEN || devState == DeviceState.SESSION_ACTIVE_BUSY || devState == DeviceState.AUTHENTICATE));
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final StateFlow<RegDialogStep> getRegDialogStep() {
        return this.regDialogStep;
    }

    public final StateFlow<String> getRegistrationClassroomName() {
        return this.registrationClassroomName;
    }

    public final StateFlow<String> getRegistrationDeviceAddress() {
        return this.registrationDeviceAddress;
    }

    public final StateFlow<String> getRegistrationDeviceName() {
        return this.registrationDeviceName;
    }

    public final StateFlow<String> getRegistrationButtonText() {
        return this.registrationButtonText;
    }

    public final ClassroomEntity getTempClassroomToRegister() {
        return this.tempClassroomToRegister;
    }

    public final void setTempClassroomToRegister(ClassroomEntity classroomEntity) {
        this.tempClassroomToRegister = classroomEntity;
    }

    public static /* synthetic */ void startRegistrationDialog$default(TeacherViewModel teacherViewModel, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        teacherViewModel.startRegistrationDialog(str);
    }

    public final void startRegistrationDialog(String initialClassroomName) {
        Intrinsics.checkNotNullParameter(initialClassroomName, "initialClassroomName");
        this._registrationClassroomName.setValue(initialClassroomName);
        this._registrationDeviceAddress.setValue(null);
        this._registrationDeviceName.setValue(null);
        this._regDialogStep.setValue(RegDialogStep.DISCOVERING);
        this._registrationButtonText.setValue("Search Setup Calis");
        BleManager.startScan$default(this.bleManager, false, 1, null);
    }

    public final void cancelRegistrationDialog() {
        boolean wasSuccess = this._regDialogStep.getValue() == RegDialogStep.SUCCESS;
        if (!wasSuccess) {
            ClassroomEntity value = this.activeClassroom.getValue();
            if (!(value != null && value.isBound())) {
                this.bleManager.clearBleObject();
            }
        }
        this._regDialogStep.setValue(null);
        this._registrationDeviceAddress.setValue(null);
        this._registrationDeviceName.setValue(null);
        this.tempClassroomToRegister = null;
    }

    public final void stopRegistrationFlow() {
        cancelRegistrationDialog();
    }

    public final void setRegistrationClassroomName(String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        this._registrationClassroomName.setValue(name);
    }

    public final void setSavedMacAddress(String address) {
        this._savedMacAddress.setValue(address);
    }

    public final void setRegistrationSelectedDevice(String name, String address) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(address, "address");
        this._registrationDeviceName.setValue(name);
        this._registrationDeviceAddress.setValue(address);
    }

    public final void onRegistrationNextClicked() {
        RegDialogStep step = this._regDialogStep.getValue();
        if (step == null) {
            return;
        }
        switch (WhenMappings.$EnumSwitchMapping$0[step.ordinal()]) {
            case 1:
                String selectedAddress = this._registrationDeviceAddress.getValue();
                String str = selectedAddress;
                if (!(str == null || StringsKt.isBlank(str))) {
                    this._regDialogStep.setValue(RegDialogStep.CONNECTING);
                    this._registrationButtonText.setValue("Connecting");
                    this.bleManager.connect(selectedAddress);
                    return;
                }
                BleManager.startScan$default(this.bleManager, false, 1, null);
                return;
            case 2:
                String selectedAddress2 = this._registrationDeviceAddress.getValue();
                if (selectedAddress2 == null) {
                    return;
                }
                this.bleManager.connect(selectedAddress2);
                return;
            case 3:
            case 4:
                return;
            case 5:
                this._regDialogStep.setValue(null);
                this._userMessage.tryEmit("Classroom registered!");
                return;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    public static /* synthetic */ void startRegistrationFlow$default(TeacherViewModel teacherViewModel, String str, String str2, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        if ((i & 2) != 0) {
            str2 = "";
        }
        teacherViewModel.startRegistrationFlow(str, str2);
    }

    public final void startRegistrationFlow(String classroomName, String address) {
        Intrinsics.checkNotNullParameter(classroomName, "classroomName");
        Intrinsics.checkNotNullParameter(address, "address");
        MutableStateFlow<String> mutableStateFlow = this._registrationDeviceAddress;
        String str = address;
        if (StringsKt.isBlank(str)) {
            str = null;
        }
        mutableStateFlow.setValue(str);
        this._registrationClassroomName.setValue(classroomName);
        boolean zIsBlank = StringsKt.isBlank(address);
        MutableStateFlow<RegDialogStep> mutableStateFlow2 = this._regDialogStep;
        if (!zIsBlank) {
            mutableStateFlow2.setValue(RegDialogStep.CONNECTING);
            this._registrationButtonText.setValue("Connecting");
            this.bleManager.connect(address);
        } else {
            mutableStateFlow2.setValue(RegDialogStep.DISCOVERING);
            this._registrationButtonText.setValue("Search Setup Calis");
            BleManager.startScan$default(this.bleManager, false, 1, null);
        }
    }

    public static /* synthetic */ void initiateDeviceRegistration$default(TeacherViewModel teacherViewModel, String str, String str2, String str3, int i, Object obj) {
        if ((i & 4) != 0) {
            str3 = "";
        }
        teacherViewModel.initiateDeviceRegistration(str, str2, str3);
    }

    public final void initiateDeviceRegistration(String address, String name, String classroomName) {
        Intrinsics.checkNotNullParameter(address, "address");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(classroomName, "classroomName");
        this._registrationDeviceName.setValue(name);
        this._registrationDeviceAddress.setValue(address);
        if (!StringsKt.isBlank(classroomName)) {
            this._registrationClassroomName.setValue(classroomName);
        }
        this._regDialogStep.setValue(RegDialogStep.CONNECTING);
        this._registrationButtonText.setValue("Connecting");
        this.bleManager.connect(address);
    }

    public static /* synthetic */ void initiateDeviceRegistration$default(TeacherViewModel teacherViewModel, BleManager.ScannedDevice scannedDevice, String str, int i, Object obj) {
        if ((i & 2) != 0) {
            str = "";
        }
        teacherViewModel.initiateDeviceRegistration(scannedDevice, str);
    }

    public final void initiateDeviceRegistration(BleManager.ScannedDevice selectedDevice, String classroomName) {
        Intrinsics.checkNotNullParameter(selectedDevice, "selectedDevice");
        Intrinsics.checkNotNullParameter(classroomName, "classroomName");
        this._registrationDeviceName.setValue(selectedDevice.getName());
        this._registrationDeviceAddress.setValue(selectedDevice.getAddress());
        if (!StringsKt.isBlank(classroomName)) {
            this._registrationClassroomName.setValue(classroomName);
        }
        this._regDialogStep.setValue(RegDialogStep.CONNECTING);
        this._registrationButtonText.setValue("Connecting");
        this.bleManager.connect(selectedDevice.getAddress());
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$2, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$2", f = "TeacherViewModel.kt", i = {}, l = {312}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Application $application;
        final /* synthetic */ Flow<ClassroomEntity> $targetClassroomFlow;
        int label;
        final /* synthetic */ TeacherViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(Flow<ClassroomEntity> flow, TeacherViewModel teacherViewModel, Application application, Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
            this.$targetClassroomFlow = flow;
            this.this$0 = teacherViewModel;
            this.$application = application;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass2(this.$targetClassroomFlow, this.this$0, this.$application, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<ClassroomEntity> flow = this.$targetClassroomFlow;
                    final TeacherViewModel teacherViewModel = this.this$0;
                    final Application application = this.$application;
                    this.label = 1;
                    if (flow.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.2.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((ClassroomEntity) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(ClassroomEntity classroom, Continuation<? super Unit> continuation) {
                            teacherViewModel._isClassroomLoaded.setValue(Boxing.boxBoolean(true));
                            if (classroom != null) {
                                String deviceAddress = classroom.getDeviceAddress();
                                if (!(deviceAddress == null || StringsKt.isBlank(deviceAddress))) {
                                    teacherViewModel._savedMacAddress.setValue(classroom.getDeviceAddress());
                                }
                                teacherViewModel.getBleManager().setVirtualClassroomInfo(classroom.getClassroomName(), classroom.isBound());
                                if (classroom.isBound()) {
                                    if (BlePermissionUtils.INSTANCE.hasPermissions(application)) {
                                        CalisBleService.INSTANCE.startService(application);
                                    } else {
                                        Boxing.boxInt(Log.d("CALIS", "startService skipped in TeacherViewModel: Bluetooth permissions not granted yet"));
                                    }
                                    String deviceAddress2 = classroom.getDeviceAddress();
                                    if (!(deviceAddress2 == null || StringsKt.isBlank(deviceAddress2)) && (teacherViewModel.getBleManager().getConnectionState().getValue() instanceof BleManager.ConnectionState.Disconnected) && !teacherViewModel.getBleManager().getIsExplicitlyDisconnected()) {
                                        Log.d("CALIS", "Classroom is bound. Initial auto-scan/connect to registered device...");
                                        BleManager.startScan$default(teacherViewModel.getBleManager(), false, 1, null);
                                    }
                                } else {
                                    CalisBleService.INSTANCE.stopService(application);
                                }
                            } else {
                                CalisBleService.INSTANCE.stopService(application);
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$10, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$10", f = "TeacherViewModel.kt", i = {0, 0, 0}, l = {408}, m = "invokeSuspend", n = {"classroom", "isConnected", "isServiceActive"}, s = {"L$0", "I$0", "Z$0"})
    static final class AnonymousClass10 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int I$0;
        Object L$0;
        boolean Z$0;
        int label;

        AnonymousClass10(Continuation<? super AnonymousClass10> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass10(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass10) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            boolean z;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    boolean z2 = TeacherViewModel.this.getBleManager().getConnectionState().getValue() instanceof BleManager.ConnectionState.Connected;
                    boolean zIsServiceRunning = CalisBleService.INSTANCE.isServiceRunning();
                    if (!z2 && !zIsServiceRunning) {
                        ClassroomEntity value = TeacherViewModel.this.getActiveClassroom().getValue();
                        if (value == null) {
                            value = TeacherViewModel.this.getCurrentClassroom().getValue();
                        }
                        if (value != null && value.isActiveSession()) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(value);
                            this.I$0 = z2 ? 1 : 0;
                            this.Z$0 = zIsServiceRunning;
                            this.label = 1;
                            if (TeacherViewModel.this.repository.updateClassroomSession(value.getCid(), false, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            z = zIsServiceRunning;
                            CalisBleService.INSTANCE.setSessionActive(TeacherViewModel.this.getApplication(), false);
                        }
                    }
                    return Unit.INSTANCE;
                case 1:
                    z = this.Z$0;
                    int i = this.I$0;
                    ResultKt.throwOnFailure(obj);
                    CalisBleService.INSTANCE.setSessionActive(TeacherViewModel.this.getApplication(), false);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$11, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$11", f = "TeacherViewModel.kt", i = {}, l = {418}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass11 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Flow<ClassroomEntity> $targetClassroomFlow;
        int label;
        final /* synthetic */ TeacherViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass11(Flow<ClassroomEntity> flow, TeacherViewModel teacherViewModel, Continuation<? super AnonymousClass11> continuation) {
            super(2, continuation);
            this.$targetClassroomFlow = flow;
            this.this$0 = teacherViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass11(this.$targetClassroomFlow, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass11) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$11$1, reason: invalid class name */
        /* JADX INFO: compiled from: TeacherViewModel.kt */
        @Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u00030\u00012\b\u0010\u0005\u001a\u0004\u0018\u00010\u00022\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\n"}, d2 = {"<anonymous>", "Lkotlin/Pair;", "Lcom/example/data/db/ClassroomEntity;", "", "Lcom/example/data/db/ApprovedStudentEntity;", "cls", "students"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$11$1", f = "TeacherViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass1 extends SuspendLambda implements Function3<ClassroomEntity, List<? extends ApprovedStudentEntity>, Continuation<? super Pair<? extends ClassroomEntity, ? extends List<? extends ApprovedStudentEntity>>>, Object> {
            /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;
            int label;

            AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                super(3, continuation);
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final Object invoke2(ClassroomEntity classroomEntity, List<ApprovedStudentEntity> list, Continuation<? super Pair<ClassroomEntity, ? extends List<ApprovedStudentEntity>>> continuation) {
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(continuation);
                anonymousClass1.L$0 = classroomEntity;
                anonymousClass1.L$1 = list;
                return anonymousClass1.invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ Object invoke(ClassroomEntity classroomEntity, List<? extends ApprovedStudentEntity> list, Continuation<? super Pair<? extends ClassroomEntity, ? extends List<? extends ApprovedStudentEntity>>> continuation) {
                return invoke2(classroomEntity, (List<ApprovedStudentEntity>) list, (Continuation<? super Pair<ClassroomEntity, ? extends List<ApprovedStudentEntity>>>) continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object $result) {
                ClassroomEntity cls = (ClassroomEntity) this.L$0;
                List students = (List) this.L$1;
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        return TuplesKt.to(cls, students);
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (FlowKt.collectLatest(FlowKt.combine(this.$targetClassroomFlow, this.this$0.getApprovedStudents(), new AnonymousClass1(null)), new AnonymousClass2(this.this$0, null), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$11$2, reason: invalid class name */
        /* JADX INFO: compiled from: TeacherViewModel.kt */
        @Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u001a\u0010\u0002\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00050\u0003H\n"}, d2 = {"<anonymous>", "", "<destruct>", "Lkotlin/Pair;", "Lcom/example/data/db/ClassroomEntity;", "", "Lcom/example/data/db/ApprovedStudentEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$11$2", f = "TeacherViewModel.kt", i = {0, 0, 0}, l = {420}, m = "invokeSuspend", n = {"<destruct>", "cls", "students"}, s = {"L$0", "L$1", "L$2"})
        static final class AnonymousClass2 extends SuspendLambda implements Function2<Pair<? extends ClassroomEntity, ? extends List<? extends ApprovedStudentEntity>>, Continuation<? super Unit>, Object> {
            /* synthetic */ Object L$0;
            Object L$1;
            Object L$2;
            int label;
            final /* synthetic */ TeacherViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass2(TeacherViewModel teacherViewModel, Continuation<? super AnonymousClass2> continuation) {
                super(2, continuation);
                this.this$0 = teacherViewModel;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.this$0, continuation);
                anonymousClass2.L$0 = obj;
                return anonymousClass2;
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(Pair<? extends ClassroomEntity, ? extends List<? extends ApprovedStudentEntity>> pair, Continuation<? super Unit> continuation) {
                return invoke2((Pair<ClassroomEntity, ? extends List<ApprovedStudentEntity>>) pair, continuation);
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final Object invoke2(Pair<ClassroomEntity, ? extends List<ApprovedStudentEntity>> pair, Continuation<? super Unit> continuation) {
                return ((AnonymousClass2) create(pair, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object $result) {
                List<ApprovedStudentEntity> list;
                Pair pair = (Pair) this.L$0;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        ClassroomEntity cls = (ClassroomEntity) pair.component1();
                        List<ApprovedStudentEntity> list2 = (List) pair.component2();
                        if (cls != null && !list2.isEmpty()) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(pair);
                            this.L$1 = SpillingKt.nullOutSpilledVariable(cls);
                            this.L$2 = SpillingKt.nullOutSpilledVariable(list2);
                            this.label = 1;
                            if (this.this$0.checkAndInitializeDailyAttendance(cls, list2, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            list = list2;
                        }
                        return Unit.INSTANCE;
                    case 1:
                        list = (List) this.L$2;
                        ResultKt.throwOnFailure($result);
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$12, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$12", f = "TeacherViewModel.kt", i = {}, l = {427}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass12 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Application $application;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass12(Application application, Continuation<? super AnonymousClass12> continuation) {
            super(2, continuation);
            this.$application = application;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass12(this.$application, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass12) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<Boolean> stateFlowIsAuthenticated = TeacherViewModel.this.getBleManager().isAuthenticated();
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    final Application application = this.$application;
                    this.label = 1;
                    if (stateFlowIsAuthenticated.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.12.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit(((Boolean) value).booleanValue(), (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(boolean authenticated, Continuation<? super Unit> continuation) {
                            if (authenticated && teacherViewModel._regDialogStep.getValue() == null) {
                                SharedPreferences prefs = application.getSharedPreferences("calis_auth_prefs", 0);
                                boolean autoStart = prefs.getBoolean("auto_start_session", true);
                                if (autoStart) {
                                    ClassroomEntity classroom = teacherViewModel.getActiveClassroom().getValue();
                                    if (classroom == null) {
                                        classroom = teacherViewModel.getCurrentClassroom().getValue();
                                    }
                                    if (classroom != null && !classroom.isActiveSession()) {
                                        Log.d("CALIS", "Auto-starting session because auto_start_session is enabled and TC is authenticated");
                                        teacherViewModel.startSession();
                                    }
                                }
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$13, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$13", f = "TeacherViewModel.kt", i = {}, l = {446}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass13 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass13(Continuation<? super AnonymousClass13> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass13(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass13) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<String> pendingAction = TeacherViewModel.this.getBleManager().getPendingAction();
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    this.label = 1;
                    if (pendingAction.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.13.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((String) value, (Continuation<? super Unit>) $completion);
                        }

                        /* JADX WARN: Code duplicated, block: B:50:0x00d1  */
                        /* JADX WARN: Code duplicated, block: B:51:0x00d9  */
                        /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
                        public final Object emit(String str, Continuation<? super Unit> continuation) {
                            String deviceAddress;
                            T next;
                            BleManager.ScannedDevice scannedDevice;
                            TeacherViewModel teacherViewModel2;
                            BleManager.ScannedDevice scannedDevice2;
                            String classroomName;
                            if (str != null) {
                                switch (str.hashCode()) {
                                    case -1132650631:
                                        if (str.equals("START_SESSION") && teacherViewModel.isControlsEnabled().getValue().booleanValue()) {
                                            teacherViewModel.startSession();
                                        }
                                        break;
                                    case 534632178:
                                        if (str.equals("END_SESSION") && teacherViewModel.isControlsEnabled().getValue().booleanValue()) {
                                            teacherViewModel.endSession();
                                        }
                                        break;
                                    case 1015497884:
                                        if (str.equals("DISCONNECT")) {
                                            teacherViewModel.disconnectDevice();
                                        }
                                        break;
                                    case 1669334218:
                                        if (str.equals("CONNECT")) {
                                            ClassroomEntity value = teacherViewModel.getActiveClassroom().getValue();
                                            if (value == null) {
                                                value = teacherViewModel.getCurrentClassroom().getValue();
                                            }
                                            if (value == null || (deviceAddress = value.getDeviceAddress()) == null) {
                                                deviceAddress = (String) teacherViewModel._savedMacAddress.getValue();
                                            }
                                            String str2 = deviceAddress;
                                            boolean z = str2 == null || StringsKt.isBlank(str2);
                                            TeacherViewModel teacherViewModel3 = teacherViewModel;
                                            if (!z) {
                                                teacherViewModel3.connectToDevice(deviceAddress);
                                            } else {
                                                boolean isSimulatedMode = teacherViewModel3.getBleManager().getIsSimulatedMode();
                                                TeacherViewModel teacherViewModel4 = teacherViewModel;
                                                if (!isSimulatedMode) {
                                                    Iterator<T> it = teacherViewModel4.getBleManager().getScannedDevices().getValue().iterator();
                                                    do {
                                                        if (it.hasNext()) {
                                                            next = it.next();
                                                            scannedDevice2 = (BleManager.ScannedDevice) next;
                                                            if (value == null || (classroomName = value.getClassroomName()) == null) {
                                                                classroomName = "";
                                                            }
                                                        } else {
                                                            next = (T) null;
                                                        }
                                                        scannedDevice = next;
                                                        teacherViewModel2 = teacherViewModel;
                                                        if (scannedDevice != null) {
                                                            TeacherViewModel.startBleScan$default(teacherViewModel2, false, 1, null);
                                                        } else {
                                                            teacherViewModel2.connectToDevice(scannedDevice.getAddress());
                                                        }
                                                        break;
                                                    } while (!((!StringsKt.isBlank(classroomName) && StringsKt.contains((CharSequence) scannedDevice2.getName(), (CharSequence) classroomName, true)) || StringsKt.contains((CharSequence) scannedDevice2.getName(), (CharSequence) "Calis", true)));
                                                    scannedDevice = next;
                                                    teacherViewModel2 = teacherViewModel;
                                                    if (scannedDevice != null) {
                                                        TeacherViewModel.startBleScan$default(teacherViewModel2, false, 1, null);
                                                    } else {
                                                        teacherViewModel2.connectToDevice(scannedDevice.getAddress());
                                                    }
                                                } else {
                                                    teacherViewModel4.connectToDevice("VIRTUAL_CALIS_DEVICE");
                                                }
                                            }
                                        }
                                        break;
                                }
                                teacherViewModel.getBleManager().setPendingAction(null);
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$14, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$14", f = "TeacherViewModel.kt", i = {0}, l = {491}, m = "invokeSuspend", n = {"previousState"}, s = {"L$0"})
    static final class AnonymousClass14 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        AnonymousClass14(Continuation<? super AnonymousClass14> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass14(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass14) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    final Ref.ObjectRef previousState = new Ref.ObjectRef();
                    StateFlow<BleManager.ConnectionState> connectionState = TeacherViewModel.this.getBleManager().getConnectionState();
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    this.L$0 = SpillingKt.nullOutSpilledVariable(previousState);
                    this.label = 1;
                    if (connectionState.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.14.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((BleManager.ConnectionState) value, (Continuation<? super Unit>) $completion);
                        }

                        /* JADX WARN: Multi-variable type inference failed */
                        public final Object emit(BleManager.ConnectionState connectionState2, Continuation<? super Unit> continuation) {
                            String cidToAuth;
                            String tid;
                            String cid;
                            String classroomName;
                            String clsName;
                            String fullName;
                            ClassroomEntity tempClassroom;
                            String tid2;
                            String teacherId;
                            String teacherName;
                            TeacherEntity teacher = teacherViewModel.getCurrentTeacher().getValue();
                            ClassroomEntity classroom = teacherViewModel.getActiveClassroom().getValue();
                            if (classroom == null) {
                                classroom = teacherViewModel.getCurrentClassroom().getValue();
                            }
                            DeviceState devState = teacherViewModel.getBleManager().getDeviceState().getValue();
                            if (connectionState2 instanceof BleManager.ConnectionState.Connected) {
                                teacherViewModel._isUserDisconnected.setValue(Boxing.boxBoolean(false));
                                Object value = teacherViewModel._regDialogStep.getValue();
                                RegDialogStep regDialogStep = RegDialogStep.CONNECTING;
                                TeacherViewModel teacherViewModel2 = teacherViewModel;
                                String str = "T001";
                                if (value == regDialogStep) {
                                    ClassroomEntity value2 = teacherViewModel2.getActiveClassroom().getValue();
                                    if (value2 == null) {
                                        value2 = teacherViewModel.getCurrentClassroom().getValue();
                                    }
                                    ClassroomEntity existingClassroom = value2;
                                    if (existingClassroom == null || (cid = existingClassroom.getCid()) == null) {
                                        cid = IdGenerator.INSTANCE.generateCID();
                                    }
                                    if (StringsKt.isBlank((CharSequence) teacherViewModel._registrationClassroomName.getValue())) {
                                        if (existingClassroom == null || (classroomName = existingClassroom.getClassroomName()) == null) {
                                            classroomName = "My Classroom";
                                        }
                                        clsName = classroomName;
                                    } else {
                                        clsName = (String) teacherViewModel._registrationClassroomName.getValue();
                                    }
                                    if (existingClassroom == null || (tempClassroom = ClassroomEntity.copy$default(existingClassroom, null, null, clsName, null, null, null, null, null, false, false, null, 1531, null)) == null) {
                                        if (teacher != null && (tid2 = teacher.getTid()) != null) {
                                            str = tid2;
                                        }
                                        if (teacher == null || (fullName = teacher.getFullName()) == null) {
                                            fullName = "Teacher Account";
                                        }
                                        String clsName2 = clsName;
                                        String clsName3 = str;
                                        tempClassroom = new ClassroomEntity(cid, clsName3, clsName2, fullName, "MON-FRI", "0800", "0815", "1700", false, false, null, 1280, null);
                                    }
                                    teacherViewModel.setTempClassroomToRegister(tempClassroom);
                                    String cid2 = tempClassroom.getCid();
                                    if (teacher == null || (teacherId = teacher.getTid()) == null) {
                                        teacherId = tempClassroom.getTeacherId();
                                    }
                                    String classroomName2 = tempClassroom.getClassroomName();
                                    BlePermissionUtils blePermissionUtils = BlePermissionUtils.INSTANCE;
                                    if (teacher == null || (teacherName = teacher.getFullName()) == null) {
                                        teacherName = tempClassroom.getTeacherName();
                                    }
                                    BlePacket.RegCommand regPacket = new BlePacket.RegCommand(cid2, teacherId, classroomName2, BlePermissionUtils.formatTeacherNameWithMiddleInitial$default(blePermissionUtils, teacherName, null, 2, null));
                                    teacherViewModel._regDialogStep.setValue(RegDialogStep.REGISTERING);
                                    teacherViewModel._registrationButtonText.setValue("Registering");
                                    BleManager.sendPacket$default(teacherViewModel.getBleManager(), regPacket, null, 2, null);
                                } else {
                                    Object value3 = teacherViewModel2._regDialogStep.getValue();
                                    RegDialogStep regDialogStep2 = RegDialogStep.AUTHENTICATING;
                                    TeacherViewModel teacherViewModel3 = teacherViewModel;
                                    if (value3 == regDialogStep2) {
                                        ClassroomEntity tempClassroomToRegister = teacherViewModel3.getTempClassroomToRegister();
                                        if (tempClassroomToRegister == null || (cidToAuth = tempClassroomToRegister.getCid()) == null) {
                                            ClassroomEntity value4 = teacherViewModel.getActiveClassroom().getValue();
                                            if (value4 == null) {
                                                value4 = teacherViewModel.getCurrentClassroom().getValue();
                                            }
                                            cidToAuth = value4 != null ? value4.getCid() : "";
                                        }
                                        if (teacher != null && (tid = teacher.getTid()) != null) {
                                            str = tid;
                                        }
                                        BlePacket.AuthCommand authPacket = new BlePacket.AuthCommand(str, cidToAuth);
                                        teacherViewModel._registrationButtonText.setValue("Authenticating");
                                        Log.d("CALIS", "Sending AUTH packet in dialog flow: TID=" + (teacher != null ? teacher.getTid() : null) + ", CID=" + cidToAuth);
                                        BleManager.sendPacket$default(teacherViewModel.getBleManager(), authPacket, null, 2, null);
                                    } else if (teacherViewModel3._regDialogStep.getValue() == null) {
                                        if (classroom != null && classroom.isBound()) {
                                            teacherViewModel.setWaitingForReconnect(false);
                                            teacherViewModel.authenticateDevice();
                                        } else if ((devState == DeviceState.FACTORY_MODE || devState == DeviceState.REGISTERING || classroom == null || !classroom.isBound()) && teacher != null && classroom != null) {
                                            BlePacket.RegCommand regPacket2 = new BlePacket.RegCommand(classroom.getCid(), teacher.getTid(), classroom.getClassroomName(), BlePermissionUtils.formatTeacherNameWithMiddleInitial$default(BlePermissionUtils.INSTANCE, teacher.getFullName(), null, 2, null));
                                            BleManager.sendPacket$default(teacherViewModel.getBleManager(), regPacket2, null, 2, null);
                                        }
                                    }
                                }
                            } else if (connectionState2 instanceof BleManager.ConnectionState.Disconnected) {
                                if ((previousState.element instanceof BleManager.ConnectionState.Disconnecting) || teacherViewModel.getBleManager().getIsExplicitlyDisconnected()) {
                                    teacherViewModel._userMessage.tryEmit("Disconnected");
                                }
                                teacherViewModel.getBleManager().setAuthenticated(false);
                                if (!teacherViewModel.getBleManager().getIsExplicitlyDisconnected()) {
                                    teacherViewModel._isUserDisconnected.setValue(Boxing.boxBoolean(false));
                                }
                                ClassroomEntity cls = teacherViewModel.getActiveClassroom().getValue();
                                if (cls == null) {
                                    cls = teacherViewModel.getCurrentClassroom().getValue();
                                }
                                if (cls != null && cls.isActiveSession()) {
                                    BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(teacherViewModel), null, null, new C01691(teacherViewModel, cls, null), 3, null);
                                }
                                CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, teacherViewModel.getApplication(), false, 2, null);
                                if (teacherViewModel._regDialogStep.getValue() == RegDialogStep.REGISTERING || teacherViewModel._regDialogStep.getValue() == RegDialogStep.AUTHENTICATING) {
                                    teacherViewModel._regDialogStep.setValue(RegDialogStep.AUTHENTICATING);
                                    teacherViewModel._registrationButtonText.setValue("Authenticating");
                                    if (teacherViewModel.getBleManager().isBluetoothEnabled() && teacherViewModel.getCurrentTeacher().getValue() != null) {
                                        String targetMac = (String) teacherViewModel._savedMacAddress.getValue();
                                        if (targetMac == null && (targetMac = (String) teacherViewModel._registrationDeviceAddress.getValue()) == null) {
                                            ClassroomEntity tempClassroomToRegister2 = teacherViewModel.getTempClassroomToRegister();
                                            targetMac = tempClassroomToRegister2 != null ? tempClassroomToRegister2.getDeviceAddress() : null;
                                            if (targetMac == null) {
                                                targetMac = teacherViewModel.getBleManager().getLastTargetAddress();
                                            }
                                        }
                                        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(teacherViewModel), null, null, new AnonymousClass2(teacherViewModel, targetMac, null), 3, null);
                                    }
                                } else if (teacherViewModel._regDialogStep.getValue() == RegDialogStep.CONNECTING && teacherViewModel.getBleManager().isBluetoothEnabled()) {
                                    BleManager.startScan$default(teacherViewModel.getBleManager(), false, 1, null);
                                }
                            }
                            previousState.element = connectionState2;
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$14$1$1, reason: invalid class name and collision with other inner class name */
                        /* JADX INFO: compiled from: TeacherViewModel.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$14$1$1", f = "TeacherViewModel.kt", i = {}, l = {570}, m = "invokeSuspend", n = {}, s = {})
                        static final class C01691 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ ClassroomEntity $cls;
                            int label;
                            final /* synthetic */ TeacherViewModel this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            C01691(TeacherViewModel teacherViewModel, ClassroomEntity classroomEntity, Continuation<? super C01691> continuation) {
                                super(2, continuation);
                                this.this$0 = teacherViewModel;
                                this.$cls = classroomEntity;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new C01691(this.this$0, this.$cls, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                return ((C01691) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Object invokeSuspend(Object $result) {
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        this.label = 1;
                                        if (this.this$0.repository.updateClassroomSession(this.$cls.getCid(), false, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                return Unit.INSTANCE;
                            }
                        }

                        /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$14$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: TeacherViewModel.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$14$1$2", f = "TeacherViewModel.kt", i = {}, l = {581}, m = "invokeSuspend", n = {}, s = {})
                        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ String $targetMac;
                            int label;
                            final /* synthetic */ TeacherViewModel this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            AnonymousClass2(TeacherViewModel teacherViewModel, String str, Continuation<? super AnonymousClass2> continuation) {
                                super(2, continuation);
                                this.this$0 = teacherViewModel;
                                this.$targetMac = str;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new AnonymousClass2(this.this$0, this.$targetMac, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Object invokeSuspend(Object $result) {
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        this.this$0.getBleManager().clearBleObject();
                                        this.label = 1;
                                        if (DelayKt.delay(2000L, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                if (this.this$0._regDialogStep.getValue() == RegDialogStep.AUTHENTICATING && this.this$0.getBleManager().isBluetoothEnabled()) {
                                    String str = this.$targetMac;
                                    if (!(str == null || StringsKt.isBlank(str))) {
                                        Log.d("CALIS", "Post-registration disconnect: directly reconnecting to targetMac: " + this.$targetMac);
                                        this.this$0.getBleManager().connect(this.$targetMac);
                                    } else {
                                        BleManager.startScan$default(this.this$0.getBleManager(), false, 1, null);
                                    }
                                }
                                return Unit.INSTANCE;
                            }
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$15, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$15", f = "TeacherViewModel.kt", i = {0}, l = {605}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    static final class AnonymousClass15 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        int label;

        AnonymousClass15(Continuation<? super AnonymousClass15> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            AnonymousClass15 anonymousClass15 = TeacherViewModel.this.new AnonymousClass15(continuation);
            anonymousClass15.L$0 = obj;
            return anonymousClass15;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass15) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:10:0x0025  */
        /* JADX WARN: Code duplicated, block: B:12:0x0034 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:15:0x0041  */
        /* JADX WARN: Code duplicated, block: B:19:0x0061  */
        /* JADX WARN: Code duplicated, block: B:21:0x0065  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:11:0x0032 -> B:13:0x0035). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:15:0x0041
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                r8 = this;
                java.lang.Object r0 = r8.L$0
                kotlinx.coroutines.CoroutineScope r0 = (kotlinx.coroutines.CoroutineScope) r0
                java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r2 = r8.label
                r3 = 1
                switch(r2) {
                    case 0: goto L1b;
                    case 1: goto L16;
                    default: goto Le;
                }
            Le:
                java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
                java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
                r1.<init>(r2)
                throw r1
            L16:
                kotlin.ResultKt.throwOnFailure(r9)
                r2 = r8
                goto L35
            L1b:
                kotlin.ResultKt.throwOnFailure(r9)
                r2 = r8
            L1f:
                boolean r4 = kotlinx.coroutines.CoroutineScopeKt.isActive(r0)
                if (r4 == 0) goto L71
                r4 = r2
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                r2.L$0 = r0
                r2.label = r3
                r5 = 3000(0xbb8, double:1.482E-320)
                java.lang.Object r4 = kotlinx.coroutines.DelayKt.delay(r5, r4)
                if (r4 != r1) goto L35
                return r1
            L35:
                com.example.ui.viewmodel.TeacherViewModel r4 = com.example.ui.viewmodel.TeacherViewModel.this
                kotlinx.coroutines.flow.StateFlow r4 = r4.getCurrentTeacher()
                java.lang.Object r4 = r4.getValue()
                if (r4 == 0) goto L1f
                com.example.ui.viewmodel.TeacherViewModel r4 = com.example.ui.viewmodel.TeacherViewModel.this
                com.example.ble.BleManager r4 = r4.getBleManager()
                boolean r4 = r4.isBluetoothEnabled()
                if (r4 == 0) goto L1f
                com.example.ui.viewmodel.TeacherViewModel r4 = com.example.ui.viewmodel.TeacherViewModel.this
                com.example.ble.BleManager r4 = r4.getBleManager()
                kotlinx.coroutines.flow.StateFlow r4 = r4.getConnectionState()
                java.lang.Object r4 = r4.getValue()
                com.example.ble.BleManager$ConnectionState r4 = (com.example.ble.BleManager.ConnectionState) r4
                boolean r5 = r4 instanceof com.example.ble.BleManager.ConnectionState.Disconnected
                if (r5 != 0) goto L65
                boolean r5 = r4 instanceof com.example.ble.BleManager.ConnectionState.Error
                if (r5 == 0) goto L1f
            L65:
                com.example.ui.viewmodel.TeacherViewModel r5 = com.example.ui.viewmodel.TeacherViewModel.this
                com.example.ble.BleManager r5 = r5.getBleManager()
                r6 = 0
                r7 = 0
                com.example.ble.BleManager.startScan$default(r5, r6, r3, r7)
                goto L1f
            L71:
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.AnonymousClass15.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$16, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$16", f = "TeacherViewModel.kt", i = {}, l = {617}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass16 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass16(Continuation<? super AnonymousClass16> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass16(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass16) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<List<BleManager.ScannedDevice>> scannedDevices = TeacherViewModel.this.getBleManager().getScannedDevices();
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    this.label = 1;
                    if (scannedDevices.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.16.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((List<BleManager.ScannedDevice>) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(List<BleManager.ScannedDevice> list, Continuation<? super Unit> continuation) {
                            BleManager.ScannedDevice scannedDevice;
                            BleManager.ScannedDevice scannedDevice2;
                            BleManager.ScannedDevice scannedDevice3;
                            Object value = teacherViewModel._regDialogStep.getValue();
                            RegDialogStep regDialogStep = RegDialogStep.AUTHENTICATING;
                            TeacherViewModel teacherViewModel2 = teacherViewModel;
                            boolean z = true;
                            if (value == regDialogStep) {
                                String str = (String) teacherViewModel2._registrationClassroomName.getValue();
                                String deviceAddress = (String) teacherViewModel._savedMacAddress.getValue();
                                if (deviceAddress == null && (deviceAddress = (String) teacherViewModel._registrationDeviceAddress.getValue()) == null) {
                                    ClassroomEntity tempClassroomToRegister = teacherViewModel.getTempClassroomToRegister();
                                    deviceAddress = tempClassroomToRegister != null ? tempClassroomToRegister.getDeviceAddress() : null;
                                    if (deviceAddress == null) {
                                        deviceAddress = teacherViewModel.getBleManager().getLastTargetAddress();
                                    }
                                }
                                TeacherViewModel teacherViewModel3 = teacherViewModel;
                                Iterator<T> it = list.iterator();
                                while (true) {
                                    if (!it.hasNext()) {
                                        scannedDevice3 = null;
                                        break;
                                    }
                                    T next = it.next();
                                    BleManager.ScannedDevice scannedDevice4 = (BleManager.ScannedDevice) next;
                                    String str2 = deviceAddress;
                                    if ((((((str2 == null || StringsKt.isBlank(str2)) ? z : false) || !StringsKt.equals(scannedDevice4.getAddress(), deviceAddress, z)) && (!teacherViewModel3.getBleManager().getIsSimulatedMode() || !Intrinsics.areEqual(scannedDevice4.getAddress(), "VIRTUAL_CALIS_DEVICE"))) ? false : z) || (((StringsKt.isBlank(str) || (!StringsKt.equals(scannedDevice4.getName(), str, z) && !StringsKt.contains(scannedDevice4.getName(), str, z))) && !StringsKt.equals(scannedDevice4.getName(), "Calis Classroom", z) && !StringsKt.contains(scannedDevice4.getName(), "Calis", z) && !StringsKt.contains(scannedDevice4.getName(), "Setup", z)) ? false : z) || scannedDevice4.getHasServiceUuid() || scannedDevice4.getState() != DeviceState.UNKNOWN) {
                                        scannedDevice3 = next;
                                        break;
                                    }
                                    z = true;
                                }
                                BleManager.ScannedDevice scannedDevice5 = scannedDevice3;
                                if (scannedDevice5 == null) {
                                    scannedDevice5 = (BleManager.ScannedDevice) CollectionsKt.firstOrNull((List) list);
                                }
                                if (scannedDevice5 != null) {
                                    BleManager.ConnectionState value2 = teacherViewModel.getBleManager().getConnectionState().getValue();
                                    if (!(value2 instanceof BleManager.ConnectionState.Connected) && !(value2 instanceof BleManager.ConnectionState.Connecting)) {
                                        teacherViewModel.getBleManager().stopScan();
                                        teacherViewModel.getBleManager().connect(scannedDevice5.getAddress());
                                    }
                                }
                            } else {
                                Object value3 = teacherViewModel2._regDialogStep.getValue();
                                RegDialogStep regDialogStep2 = RegDialogStep.CONNECTING;
                                TeacherViewModel teacherViewModel4 = teacherViewModel;
                                if (value3 == regDialogStep2) {
                                    String str3 = (String) teacherViewModel4._registrationDeviceAddress.getValue();
                                    if (str3 == null) {
                                        str3 = (String) teacherViewModel._savedMacAddress.getValue();
                                    }
                                    BleManager.ConnectionState value4 = teacherViewModel.getBleManager().getConnectionState().getValue();
                                    if ((value4 instanceof BleManager.ConnectionState.Disconnected) || (value4 instanceof BleManager.ConnectionState.Scanning)) {
                                        Iterator<T> it2 = list.iterator();
                                        while (true) {
                                            if (!it2.hasNext()) {
                                                scannedDevice2 = null;
                                                break;
                                            }
                                            T next2 = it2.next();
                                            BleManager.ScannedDevice scannedDevice6 = (BleManager.ScannedDevice) next2;
                                            String str4 = str3;
                                            if ((!(str4 == null || StringsKt.isBlank(str4)) && StringsKt.equals(scannedDevice6.getAddress(), str3, true)) || (scannedDevice6.getHasServiceUuid() && StringsKt.contains((CharSequence) scannedDevice6.getName(), (CharSequence) "Setup", true))) {
                                                scannedDevice2 = next2;
                                                break;
                                            }
                                        }
                                        BleManager.ScannedDevice scannedDevice7 = scannedDevice2;
                                        if (scannedDevice7 != null) {
                                            teacherViewModel.getBleManager().stopScan();
                                            teacherViewModel.getBleManager().connect(scannedDevice7.getAddress());
                                        }
                                    }
                                } else if (teacherViewModel4._regDialogStep.getValue() == null) {
                                    TeacherEntity value5 = teacherViewModel.getCurrentTeacher().getValue();
                                    ClassroomEntity value6 = teacherViewModel.getActiveClassroom().getValue();
                                    if (value6 == null && (value6 = teacherViewModel.getCurrentClassroom().getValue()) == null) {
                                        value6 = teacherViewModel.getTargetClassroom().getValue();
                                    }
                                    boolean z2 = teacherViewModel.getBleManager().getConnectionState().getValue() instanceof BleManager.ConnectionState.Connected;
                                    if (z2) {
                                        teacherViewModel.hasAttemptedStartupAutoConnect = true;
                                    }
                                    if (!teacherViewModel.hasAttemptedStartupAutoConnect && !z2 && value6 != null && value6.isBound() && value5 != null && !teacherViewModel.getBleManager().getIsExplicitlyDisconnected() && !((Boolean) teacherViewModel._isUserDisconnected.getValue()).booleanValue()) {
                                        String deviceAddress2 = (String) teacherViewModel._savedMacAddress.getValue();
                                        if (deviceAddress2 == null) {
                                            deviceAddress2 = value6.getDeviceAddress();
                                        }
                                        TeacherViewModel teacherViewModel5 = teacherViewModel;
                                        Iterator<T> it3 = list.iterator();
                                        while (true) {
                                            if (!it3.hasNext()) {
                                                scannedDevice = null;
                                                break;
                                            }
                                            T next3 = it3.next();
                                            BleManager.ScannedDevice scannedDevice8 = (BleManager.ScannedDevice) next3;
                                            String str5 = deviceAddress2;
                                            if (((!(str5 == null || StringsKt.isBlank(str5)) && StringsKt.equals(scannedDevice8.getAddress(), deviceAddress2, true)) || (teacherViewModel5.getBleManager().getIsSimulatedMode() && Intrinsics.areEqual(scannedDevice8.getAddress(), "VIRTUAL_CALIS_DEVICE"))) || (StringsKt.equals(scannedDevice8.getName(), value6.getClassroomName(), true) || StringsKt.contains((CharSequence) scannedDevice8.getName(), (CharSequence) value6.getClassroomName(), true) || StringsKt.equals(scannedDevice8.getName(), "Calis Classroom", true) || StringsKt.equals(scannedDevice8.getName(), "Calis Active Classroom", true) || (scannedDevice8.getHasServiceUuid() && StringsKt.contains((CharSequence) scannedDevice8.getName(), (CharSequence) "Calis", true)))) {
                                                scannedDevice = next3;
                                                break;
                                            }
                                        }
                                        BleManager.ScannedDevice scannedDevice9 = scannedDevice;
                                        if (scannedDevice9 != null) {
                                            BleManager.ConnectionState value7 = teacherViewModel.getBleManager().getConnectionState().getValue();
                                            if ((value7 instanceof BleManager.ConnectionState.Disconnected) || (value7 instanceof BleManager.ConnectionState.Scanning)) {
                                                teacherViewModel.hasAttemptedStartupAutoConnect = true;
                                                Log.d("CALIS", "Auto-connecting on startup to '" + scannedDevice9.getName() + "' (" + scannedDevice9.getAddress() + ")...");
                                                teacherViewModel.getBleManager().stopScan();
                                                teacherViewModel.getBleManager().connect(scannedDevice9.getAddress());
                                            }
                                        }
                                    }
                                }
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    public final void selectTaskForSubmissions(TaskEntity task) {
        this._selectedTaskForSubmissions.setValue(task);
        if (task != null) {
            markTaskSubmissionsAsViewed(task.getTkid());
            CalisBleService.INSTANCE.dismissTaskSubmissionNotification(getApplication());
        }
    }

    public static /* synthetic */ void startBleScan$default(TeacherViewModel teacherViewModel, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        teacherViewModel.startBleScan(z);
    }

    public final void startBleScan(boolean forceRestart) {
        this.bleManager.startScan(forceRestart);
    }

    public final void stopBleScan() {
        this.bleManager.stopScan();
    }

    public final void connectToDevice(String address) {
        Intrinsics.checkNotNullParameter(address, "address");
        this.hasAttemptedStartupAutoConnect = true;
        this.bleManager.setExplicitlyDisconnected(false);
        this._isUserDisconnected.setValue(false);
        this._savedMacAddress.setValue(address);
        ClassroomEntity classroom = this.activeClassroom.getValue();
        if (classroom == null) {
            classroom = this.currentClassroom.getValue();
        }
        if (classroom != null && classroom.isActiveSession()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07971(classroom, null), 3, null);
        }
        this.bleManager.stopScan();
        this.bleManager.connect(address);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$connectToDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$connectToDevice$1", f = "TeacherViewModel.kt", i = {}, l = {711}, m = "invokeSuspend", n = {}, s = {})
    static final class C07971 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07971(ClassroomEntity classroomEntity, Continuation<? super C07971> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C07971(this.$classroom, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07971) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.updateClassroomSession(this.$classroom.getCid(), false, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final void disconnectDevice() {
        Log.d("CALIS", "User clicked Disconnect in app");
        this.hasAttemptedStartupAutoConnect = true;
        this._isUserDisconnected.setValue(true);
        setWaitingForReconnect(false);
        this.bleManager.setExplicitlyDisconnected(true);
        this.bleManager.clearBleObject();
        ClassroomEntity classroom = this.activeClassroom.getValue();
        if (classroom == null) {
            classroom = this.currentClassroom.getValue();
        }
        if (classroom != null && classroom.isActiveSession()) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08011(classroom, null), 3, null);
        }
        CalisBleService.INSTANCE.setSessionActive(getApplication(), false);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$disconnectDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$disconnectDevice$1", f = "TeacherViewModel.kt", i = {}, l = {729}, m = "invokeSuspend", n = {}, s = {})
    static final class C08011 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08011(ClassroomEntity classroomEntity, Continuation<? super C08011> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08011(this.$classroom, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08011) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.updateClassroomSession(this.$classroom.getCid(), false, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$authenticateDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$authenticateDevice$1", f = "TeacherViewModel.kt", i = {}, l = {737}, m = "invokeSuspend", n = {}, s = {})
    static final class C07951 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C07951(Continuation<? super C07951> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C07951(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07951) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            TeacherEntity teacher;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (DelayKt.delay(500L, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            if (!TeacherViewModel.this.getBleManager().isAuthenticated().getValue().booleanValue() && (teacher = TeacherViewModel.this.getCurrentTeacher().getValue()) != null) {
                ClassroomEntity classroom = TeacherViewModel.this.getTempClassroomToRegister();
                if (classroom == null && (classroom = TeacherViewModel.this.getActiveClassroom().getValue()) == null && (classroom = TeacherViewModel.this.getCurrentClassroom().getValue()) == null) {
                    return Unit.INSTANCE;
                }
                BlePacket.AuthCommand authPacket = new BlePacket.AuthCommand(teacher.getTid(), classroom.getCid());
                Log.d("CALIS", "Sending AUTH packet: TID=" + teacher.getTid() + ", CID=" + classroom.getCid());
                final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                TeacherViewModel.this.getBleManager().sendPacket(authPacket, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$authenticateDevice$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return TeacherViewModel.C07951.invokeSuspend$lambda$0(teacherViewModel, ((Boolean) obj).booleanValue());
                    }
                });
                return Unit.INSTANCE;
            }
            return Unit.INSTANCE;
        }

        static final Unit invokeSuspend$lambda$0(TeacherViewModel this$0, boolean success) {
            if (success) {
                this$0._userMessage.tryEmit("Authenticating");
            }
            return Unit.INSTANCE;
        }
    }

    public final void authenticateDevice() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07951(null), 3, null);
    }

    public final void checkAndAutoAuthenticate() {
        SharedPreferences prefs = getApplication().getSharedPreferences("calis_auth_prefs", 0);
        String currentRole = prefs.getString("user_role", null);
        if (Intrinsics.areEqual(currentRole, "TEACHER")) {
            BleManager.ConnectionState connState = this.bleManager.getConnectionState().getValue();
            TeacherEntity teacher = this.currentTeacher.getValue();
            ClassroomEntity classroom = this.activeClassroom.getValue();
            if (classroom == null && (classroom = this.currentClassroom.getValue()) == null) {
                classroom = this.targetClassroom.getValue();
            }
            if ((connState instanceof BleManager.ConnectionState.Connected) && teacher != null && classroom != null) {
                if (!this.isAuthenticated.getValue().booleanValue() && this._regDialogStep.getValue() == null && !isWaitingForReconnect()) {
                    authenticateDevice();
                    return;
                }
                return;
            }
            if (!(connState instanceof BleManager.ConnectionState.Disconnected) || this.bleManager.getIsExplicitlyDisconnected()) {
                return;
            }
            if (classroom != null && classroom.isBound()) {
                BleManager.startScan$default(this.bleManager, false, 1, null);
            }
        }
    }

    public final void startSession() {
        final ClassroomEntity classroom = this.activeClassroom.getValue();
        if (classroom == null && (classroom = this.currentClassroom.getValue()) == null) {
            return;
        }
        if (!(this.bleManager.getConnectionState().getValue() instanceof BleManager.ConnectionState.Connected)) {
            this._userMessage.tryEmit("Connect to Calis Device first");
        } else if (!this.isAuthenticated.getValue().booleanValue()) {
            this._userMessage.tryEmit("Connection Failed: Try again later");
        } else {
            this.bleManager.sendPacket(BlePacket.StartSessionCommand.INSTANCE, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return TeacherViewModel.startSession$lambda$11(this.f$0, classroom, ((Boolean) obj).booleanValue());
                }
            });
        }
    }

    static final Unit startSession$lambda$11(TeacherViewModel this$0, ClassroomEntity $classroom, boolean success) {
        if (success) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new TeacherViewModel$startSession$1$1(this$0, $classroom, null), 3, null);
        }
        return Unit.INSTANCE;
    }

    public final void endSession() {
        final ClassroomEntity classroom = this.activeClassroom.getValue();
        if (classroom == null && (classroom = this.currentClassroom.getValue()) == null) {
            return;
        }
        final String dateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        this.bleManager.sendPacket(BlePacket.EndSessionCommand.INSTANCE, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TeacherViewModel.endSession$lambda$12(this.f$0, classroom, dateStr, ((Boolean) obj).booleanValue());
            }
        });
    }

    static final Unit endSession$lambda$12(TeacherViewModel this$0, ClassroomEntity $classroom, String $dateStr, boolean success) {
        if (success) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new TeacherViewModel$endSession$1$1(this$0, $classroom, $dateStr, null), 3, null);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$unregisterDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$unregisterDevice$1", f = "TeacherViewModel.kt", i = {}, l = {843}, m = "invokeSuspend", n = {}, s = {})
    static final class C08111 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C08111(Continuation<? super C08111> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08111(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08111) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this._userMessage.emit("Unregistering Calis Device", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final void unregisterDevice() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08111(null), 3, null);
        BleManager.sendPacket$default(this.bleManager, BlePacket.UnregCommand.INSTANCE, null, 2, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$approveStudent$1, reason: invalid class name */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$approveStudent$1", f = "TeacherViewModel.kt", i = {1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9}, l = {852, 855, 859, 882, 890, 892, 908, 909, 912, 920}, m = "invokeSuspend", n = {"classroom", "targetCid", "updatedPending", "classroom", "targetCid", "updatedPending", "currentTimestamp", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTimestamp", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "currentTimestamp", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "task", "currentTimestamp", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "currentTimestamp", "alreadyReceived", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "currentTimestamp", "alreadyReceived", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "currentTimestamp", "classroom", "targetCid", "updatedPending", "regApprovedPacket", "classroomId", "currentTasks", "sortedTasks", "currentTimestamp"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "L$9", "L$10", "J$0", "Z$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "L$9", "L$10", "J$0", "Z$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "J$0"})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ PendingRegistrationEntity $pending;
        final /* synthetic */ TeacherEntity $teacher;
        long J$0;
        Object L$0;
        Object L$1;
        Object L$10;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        Object L$8;
        Object L$9;
        boolean Z$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(PendingRegistrationEntity pendingRegistrationEntity, TeacherEntity teacherEntity, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$pending = pendingRegistrationEntity;
            this.$teacher = teacherEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new AnonymousClass1(this.$pending, this.$teacher, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:101:0x0412 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:102:0x0413  */
        /* JADX WARN: Code duplicated, block: B:105:0x0424  */
        /* JADX WARN: Code duplicated, block: B:106:0x042b  */
        /* JADX WARN: Code duplicated, block: B:108:0x0431  */
        /* JADX WARN: Code duplicated, block: B:109:0x0456  */
        /* JADX WARN: Code duplicated, block: B:112:0x0473  */
        /* JADX WARN: Code duplicated, block: B:115:0x0501 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:116:0x0502  */
        /* JADX WARN: Code duplicated, block: B:119:0x056a A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:120:0x056b  */
        /* JADX WARN: Code duplicated, block: B:99:0x03b3  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:105:0x0424 -> B:97:0x03ad). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:120:0x056b -> B:121:0x0576). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r36) {
            /*
                Method dump skipped, instruction units count: 1660
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        static final Unit invokeSuspend$lambda$2(TeacherViewModel this$0, boolean it) {
            this$0.getBleManager().clearTransactionState();
            return Unit.INSTANCE;
        }
    }

    public final void approveStudent(PendingRegistrationEntity pending) {
        Intrinsics.checkNotNullParameter(pending, "pending");
        TeacherEntity teacher = this.currentTeacher.getValue();
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass1(pending, teacher, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$rejectStudent$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$rejectStudent$1", f = "TeacherViewModel.kt", i = {}, l = {926, 928, 933}, m = "invokeSuspend", n = {}, s = {})
    static final class C08091 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ PendingRegistrationEntity $pending;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08091(PendingRegistrationEntity pendingRegistrationEntity, Continuation<? super C08091> continuation) {
            super(2, continuation);
            this.$pending = pendingRegistrationEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08091(this.$pending, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08091) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:14:0x005b A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:17:0x00a4 A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            MutableSharedFlow mutableSharedFlow;
            String studentName;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.rejectStudentRegistration(this.$pending, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    BleManager.sendPacket$default(TeacherViewModel.this.getBleManager(), new BlePacket.RegRejectedResponse(this.$pending.getRid()), null, 2, null);
                    this.label = 2;
                    if (DelayKt.delay(100L, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    BleManager bleManager = TeacherViewModel.this.getBleManager();
                    BlePacket.DoneResponse doneResponse = new BlePacket.DoneResponse(this.$pending.getRid());
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    bleManager.sendPacket(doneResponse, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$rejectStudent$1$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return TeacherViewModel.C08091.invokeSuspend$lambda$0(teacherViewModel, ((Boolean) obj).booleanValue());
                        }
                    });
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    studentName = this.$pending.getStudentName();
                    this.label = 3;
                    if (mutableSharedFlow.emit("Rejected " + studentName, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    BleManager.sendPacket$default(TeacherViewModel.this.getBleManager(), new BlePacket.RegRejectedResponse(this.$pending.getRid()), null, 2, null);
                    this.label = 2;
                    if (DelayKt.delay(100L, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    BleManager bleManager2 = TeacherViewModel.this.getBleManager();
                    BlePacket.DoneResponse doneResponse2 = new BlePacket.DoneResponse(this.$pending.getRid());
                    final TeacherViewModel teacherViewModel2 = TeacherViewModel.this;
                    bleManager2.sendPacket(doneResponse2, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$rejectStudent$1$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return TeacherViewModel.C08091.invokeSuspend$lambda$0(teacherViewModel2, ((Boolean) obj).booleanValue());
                        }
                    });
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    studentName = this.$pending.getStudentName();
                    this.label = 3;
                    if (mutableSharedFlow.emit("Rejected " + studentName, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    BleManager bleManager3 = TeacherViewModel.this.getBleManager();
                    BlePacket.DoneResponse doneResponse3 = new BlePacket.DoneResponse(this.$pending.getRid());
                    final TeacherViewModel teacherViewModel3 = TeacherViewModel.this;
                    bleManager3.sendPacket(doneResponse3, new Function1() { // from class: com.example.ui.viewmodel.TeacherViewModel$rejectStudent$1$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return TeacherViewModel.C08091.invokeSuspend$lambda$0(teacherViewModel3, ((Boolean) obj).booleanValue());
                        }
                    });
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    studentName = this.$pending.getStudentName();
                    this.label = 3;
                    if (mutableSharedFlow.emit("Rejected " + studentName, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 3:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        static final Unit invokeSuspend$lambda$0(TeacherViewModel this$0, boolean it) {
            this$0.getBleManager().clearTransactionState();
            return Unit.INSTANCE;
        }
    }

    public final void rejectStudent(PendingRegistrationEntity pending) {
        Intrinsics.checkNotNullParameter(pending, "pending");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08091(pending, null), 3, null);
    }

    /* JADX WARN: Code duplicated, block: B:25:0x00fa  */
    /* JADX WARN: Code duplicated, block: B:29:0x014f A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:30:0x0150  */
    /* JADX WARN: Code duplicated, block: B:32:0x015a A[LOOP:0: B:23:0x00f4->B:32:0x015a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:36:0x010c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0018  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x0150 -> B:31:0x0158). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object checkAndInitializeDailyAttendance(com.example.data.db.ClassroomEntity r21, java.util.List<com.example.data.db.ApprovedStudentEntity> r22, kotlin.coroutines.Continuation<? super kotlin.Unit> r23) {
        /*
            Method dump skipped, instruction units count: 370
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.checkAndInitializeDailyAttendance(com.example.data.db.ClassroomEntity, java.util.List, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$refreshDailyAttendance$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$refreshDailyAttendance$1", f = "TeacherViewModel.kt", i = {0, 0}, l = {962}, m = "invokeSuspend", n = {"cls", "students"}, s = {"L$0", "L$1"})
    static final class C08081 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        Object L$1;
        int label;

        C08081(Continuation<? super C08081> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08081(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08081) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            List<ApprovedStudentEntity> list;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    ClassroomEntity cls = TeacherViewModel.this.getTargetClassroom().getValue();
                    if (cls == null && (cls = TeacherViewModel.this.getActiveClassroom().getValue()) == null) {
                        cls = TeacherViewModel.this.getCurrentClassroom().getValue();
                    }
                    List<ApprovedStudentEntity> value = TeacherViewModel.this.getApprovedStudents().getValue();
                    if (cls != null && !value.isEmpty()) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(cls);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(value);
                        this.label = 1;
                        if (TeacherViewModel.this.checkAndInitializeDailyAttendance(cls, value, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        list = value;
                    }
                    return Unit.INSTANCE;
                case 1:
                    list = (List) this.L$1;
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void refreshDailyAttendance() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08081(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$updateAttendanceStatus$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$updateAttendanceStatus$1", f = "TeacherViewModel.kt", i = {}, l = {974, 975}, m = "invokeSuspend", n = {}, s = {})
    static final class C08121 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        final /* synthetic */ String $dateStr;
        final /* synthetic */ String $newStatus;
        final /* synthetic */ String $studentId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08121(ClassroomEntity classroomEntity, String str, String str2, String str3, Continuation<? super C08121> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
            this.$studentId = str;
            this.$dateStr = str2;
            this.$newStatus = str3;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08121(this.$classroom, this.$studentId, this.$dateStr, this.$newStatus, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08121) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0062 A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            MutableSharedFlow mutableSharedFlow;
            String str;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.updateAttendanceStatus(this.$classroom.getCid(), this.$studentId, this.$dateStr, this.$newStatus, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    str = this.$newStatus;
                    this.label = 2;
                    if (mutableSharedFlow.emit("Attendance updated for student: " + str, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    str = this.$newStatus;
                    this.label = 2;
                    if (mutableSharedFlow.emit("Attendance updated for student: " + str, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void updateAttendanceStatus(String studentId, String dateStr, String newStatus) {
        Intrinsics.checkNotNullParameter(studentId, "studentId");
        Intrinsics.checkNotNullParameter(dateStr, "dateStr");
        Intrinsics.checkNotNullParameter(newStatus, "newStatus");
        ClassroomEntity value = this.activeClassroom.getValue();
        if (value == null && (value = this.currentClassroom.getValue()) == null) {
            return;
        }
        ClassroomEntity classroom = value;
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08121(classroom, studentId, dateStr, newStatus, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$createTask$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$createTask$1", f = "TeacherViewModel.kt", i = {0, 1, 1, 1}, l = {992, PointerIconCompat.TYPE_TEXT}, m = "invokeSuspend", n = {"task", "task", "scoreStr", "tkPacket"}, s = {"L$0", "L$0", "L$1", "L$2"})
    static final class C07981 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ClassroomEntity $classroom;
        final /* synthetic */ long $deadline;
        final /* synthetic */ String $description;
        final /* synthetic */ int $maxScore;
        final /* synthetic */ String $title;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        final /* synthetic */ TeacherViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07981(ClassroomEntity classroomEntity, String str, String str2, long j, int i, TeacherViewModel teacherViewModel, Continuation<? super C07981> continuation) {
            super(2, continuation);
            this.$classroom = classroomEntity;
            this.$title = str;
            this.$description = str2;
            this.$deadline = j;
            this.$maxScore = i;
            this.this$0 = teacherViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C07981(this.$classroom, this.$title, this.$description, this.$deadline, this.$maxScore, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07981) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:14:0x006b  */
        /* JADX WARN: Code duplicated, block: B:15:0x0089  */
        /* JADX WARN: Code duplicated, block: B:18:0x00a1  */
        /* JADX WARN: Code duplicated, block: B:21:0x00c0  */
        /* JADX WARN: Code duplicated, block: B:24:0x00f2 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:25:0x00f3  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            TaskEntity task;
            String str;
            String description;
            BlePacket.TaskCommand tkPacket;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    TaskEntity task2 = new TaskEntity(IdGenerator.INSTANCE.generateTKID(), this.$classroom.getCid(), this.$title, this.$description, this.$deadline, System.currentTimeMillis() / 1000, this.$maxScore);
                    this.L$0 = task2;
                    this.label = 1;
                    if (this.this$0.repository.saveTask(task2, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    task = task2;
                    if (this.$maxScore > 0) {
                        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                        str = String.format(Locale.US, "%03d", Arrays.copyOf(new Object[]{Boxing.boxInt(this.$maxScore)}, 1));
                        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                    } else {
                        str = "000";
                    }
                    String scoreStr = str;
                    String tkid = task.getTkid();
                    String title = task.getTitle();
                    description = task.getDescription();
                    if (StringsKt.isBlank(description)) {
                        description = task.getTitle();
                    }
                    tkPacket = new BlePacket.TaskCommand(tkid, title, description, task.getDeadline(), task.getDatePosted(), scoreStr, 0);
                    if (tkPacket.getRid() != 0) {
                        BleManager.sendPacket$default(this.this$0.getBleManager(), tkPacket, null, 2, null);
                    }
                    this.L$0 = SpillingKt.nullOutSpilledVariable(task);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(scoreStr);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(tkPacket);
                    this.label = 2;
                    if (this.this$0._userMessage.emit("Task created and queued for broadcast!", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    task = (TaskEntity) this.L$0;
                    ResultKt.throwOnFailure($result);
                    if (this.$maxScore > 0) {
                        StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
                        str = String.format(Locale.US, "%03d", Arrays.copyOf(new Object[]{Boxing.boxInt(this.$maxScore)}, 1));
                        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                    } else {
                        str = "000";
                    }
                    String scoreStr2 = str;
                    String tkid2 = task.getTkid();
                    String title2 = task.getTitle();
                    description = task.getDescription();
                    if (StringsKt.isBlank(description)) {
                        description = task.getTitle();
                    }
                    tkPacket = new BlePacket.TaskCommand(tkid2, title2, description, task.getDeadline(), task.getDatePosted(), scoreStr2, 0);
                    if (tkPacket.getRid() != 0) {
                        BleManager.sendPacket$default(this.this$0.getBleManager(), tkPacket, null, 2, null);
                    }
                    this.L$0 = SpillingKt.nullOutSpilledVariable(task);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(scoreStr2);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(tkPacket);
                    this.label = 2;
                    if (this.this$0._userMessage.emit("Task created and queued for broadcast!", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void createTask(String title, String description, long deadline, int maxScore) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(description, "description");
        ClassroomEntity value = this.activeClassroom.getValue();
        if (value == null && (value = this.currentClassroom.getValue()) == null) {
            return;
        }
        ClassroomEntity classroom = value;
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07981(classroom, title, description, deadline, maxScore, this, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$deleteTask$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$deleteTask$1", f = "TeacherViewModel.kt", i = {}, l = {PointerIconCompat.TYPE_HORIZONTAL_DOUBLE_ARROW, PointerIconCompat.TYPE_ZOOM_IN}, m = "invokeSuspend", n = {}, s = {})
    static final class C07991 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ TaskEntity $task;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C07991(TaskEntity taskEntity, Continuation<? super C07991> continuation) {
            super(2, continuation);
            this.$task = taskEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C07991(this.$task, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C07991) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0045  */
        /* JADX WARN: Code duplicated, block: B:14:0x004a  */
        /* JADX WARN: Code duplicated, block: B:17:0x0057  */
        /* JADX WARN: Code duplicated, block: B:20:0x0091 A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            TaskEntity taskEntity;
            String tkid;
            MutableSharedFlow mutableSharedFlow;
            String title;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.deleteTask(this.$task.getTkid(), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    taskEntity = (TaskEntity) TeacherViewModel.this._selectedTaskForSubmissions.getValue();
                    if (taskEntity != null) {
                        tkid = taskEntity.getTkid();
                    } else {
                        tkid = null;
                    }
                    if (Intrinsics.areEqual(tkid, this.$task.getTkid())) {
                        TeacherViewModel.this._selectedTaskForSubmissions.setValue(null);
                    }
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    title = this.$task.getTitle();
                    this.label = 2;
                    if (mutableSharedFlow.emit("Task '" + title + "' deleted.", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    taskEntity = (TaskEntity) TeacherViewModel.this._selectedTaskForSubmissions.getValue();
                    if (taskEntity != null) {
                        tkid = taskEntity.getTkid();
                    } else {
                        tkid = null;
                    }
                    if (Intrinsics.areEqual(tkid, this.$task.getTkid())) {
                        TeacherViewModel.this._selectedTaskForSubmissions.setValue(null);
                    }
                    mutableSharedFlow = TeacherViewModel.this._userMessage;
                    title = this.$task.getTitle();
                    this.label = 2;
                    if (mutableSharedFlow.emit("Task '" + title + "' deleted.", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void deleteTask(TaskEntity task) {
        Intrinsics.checkNotNullParameter(task, "task");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C07991(task, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$deleteTask$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$deleteTask$2", f = "TeacherViewModel.kt", i = {}, l = {1024, 1028}, m = "invokeSuspend", n = {}, s = {})
    static final class C08002 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $tkid;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C08002(String str, Continuation<? super C08002> continuation) {
            super(2, continuation);
            this.$tkid = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08002(this.$tkid, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08002) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0040  */
        /* JADX WARN: Code duplicated, block: B:14:0x0045  */
        /* JADX WARN: Code duplicated, block: B:17:0x004e  */
        /* JADX WARN: Code duplicated, block: B:20:0x006b A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            TaskEntity taskEntity;
            String tkid;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.deleteTask(this.$tkid, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    taskEntity = (TaskEntity) TeacherViewModel.this._selectedTaskForSubmissions.getValue();
                    if (taskEntity != null) {
                        tkid = taskEntity.getTkid();
                    } else {
                        tkid = null;
                    }
                    if (Intrinsics.areEqual(tkid, this.$tkid)) {
                        TeacherViewModel.this._selectedTaskForSubmissions.setValue(null);
                    }
                    this.label = 2;
                    if (TeacherViewModel.this._userMessage.emit("Task deleted.", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    taskEntity = (TaskEntity) TeacherViewModel.this._selectedTaskForSubmissions.getValue();
                    if (taskEntity != null) {
                        tkid = taskEntity.getTkid();
                    } else {
                        tkid = null;
                    }
                    if (Intrinsics.areEqual(tkid, this.$tkid)) {
                        TeacherViewModel.this._selectedTaskForSubmissions.setValue(null);
                    }
                    this.label = 2;
                    if (TeacherViewModel.this._userMessage.emit("Task deleted.", this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void deleteTask(String tkid) {
        Intrinsics.checkNotNullParameter(tkid, "tkid");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08002(tkid, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$exportAttendanceData$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$exportAttendanceData$1", f = "TeacherViewModel.kt", i = {0, 0}, l = {1038}, m = "invokeSuspend", n = {"classroom", "logs"}, s = {"L$0", "L$1"})
    static final class C08021 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function1<String, Unit> $onComplete;
        Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C08021(Function1<? super String, Unit> function1, Continuation<? super C08021> continuation) {
            super(2, continuation);
            this.$onComplete = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08021(this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08021) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            String csv;
            Object objExportAttendanceCsv;
            List<AttendanceEntity> list;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    ClassroomEntity classroom = TeacherViewModel.this.getActiveClassroom().getValue();
                    if (classroom == null) {
                        classroom = TeacherViewModel.this.getCurrentClassroom().getValue();
                    }
                    List<AttendanceEntity> value = TeacherViewModel.this.getAttendanceLogs().getValue();
                    if (classroom != null) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(value);
                        this.label = 1;
                        objExportAttendanceCsv = TeacherViewModel.this.repository.exportAttendanceCsv(classroom.getCid(), value, this);
                        if (objExportAttendanceCsv == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        list = value;
                        csv = (String) objExportAttendanceCsv;
                    } else {
                        csv = "Date,Classroom ID,Student ID,Student Name,Status,Timestamp\n";
                    }
                    this.$onComplete.invoke(csv);
                    return Unit.INSTANCE;
                case 1:
                    list = (List) this.L$1;
                    ResultKt.throwOnFailure($result);
                    objExportAttendanceCsv = $result;
                    csv = (String) objExportAttendanceCsv;
                    this.$onComplete.invoke(csv);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void exportAttendanceData(Function1<? super String, Unit> onComplete) {
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08021(onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$exportCustomAttendanceCsv$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$exportCustomAttendanceCsv$1", f = "TeacherViewModel.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, l = {1056, 1065}, m = "invokeSuspend", n = {"classroom", "rawApproved", "$this$map\\1", "$this$mapTo\\2", "destination\\2", "item\\2", "st\\3", "$i$f$map\\1\\1054", "$i$f$mapTo\\2\\1451", "$i$a$-map-TeacherViewModel$exportCustomAttendanceCsv$1$approved$1\\3\\1453\\0", "e"}, s = {"L$0", "L$1", "L$2", "L$4", "L$5", "L$7", "L$8", "I$0", "I$1", "I$2", "L$0"})
    static final class C08031 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ CsvExportUtils.AttendanceExportConfig $config;
        final /* synthetic */ Function1<String, Unit> $onComplete;
        int I$0;
        int I$1;
        int I$2;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        Object L$8;
        Object L$9;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C08031(CsvExportUtils.AttendanceExportConfig attendanceExportConfig, Function1<? super String, Unit> function1, Continuation<? super C08031> continuation) {
            super(2, continuation);
            this.$config = attendanceExportConfig;
            this.$onComplete = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08031(this.$config, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08031) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:23:0x00c6 A[Catch: Exception -> 0x01ab, TryCatch #2 {Exception -> 0x01ab, blocks: (B:21:0x00c0, B:23:0x00c6, B:25:0x00dc), top: B:64:0x00c0 }] */
        /* JADX WARN: Code duplicated, block: B:25:0x00dc A[Catch: Exception -> 0x01ab, TRY_LEAVE, TryCatch #2 {Exception -> 0x01ab, blocks: (B:21:0x00c0, B:23:0x00c6, B:25:0x00dc), top: B:64:0x00c0 }] */
        /* JADX WARN: Code duplicated, block: B:29:0x011b A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:30:0x011c  */
        /* JADX WARN: Code duplicated, block: B:33:0x0132 A[Catch: Exception -> 0x016d, TryCatch #1 {Exception -> 0x016d, blocks: (B:31:0x012e, B:33:0x0132, B:35:0x013e, B:40:0x0175), top: B:62:0x012e }] */
        /* JADX WARN: Code duplicated, block: B:36:0x0161  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x011c -> B:62:0x012e). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:39:0x016f -> B:40:0x0175). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r31) {
            /*
                Method dump skipped, instruction units count: 528
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.C08031.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public final void exportCustomAttendanceCsv(CsvExportUtils.AttendanceExportConfig config, Function1<? super String, Unit> onComplete) {
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08031(config, onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$exportTaskSubmissionsData$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$exportTaskSubmissionsData$1", f = "TeacherViewModel.kt", i = {1, 2}, l = {1073, 1074, 1078}, m = "invokeSuspend", n = {"submissions", "e"}, s = {"L$0", "L$0"})
    static final class C08051 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function1<String, Unit> $onComplete;
        final /* synthetic */ TaskEntity $task;
        Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C08051(TaskEntity taskEntity, Function1<? super String, Unit> function1, Continuation<? super C08051> continuation) {
            super(2, continuation);
            this.$task = taskEntity;
            this.$onComplete = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08051(this.$task, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08051) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:19:0x004f A[Catch: Exception -> 0x0028, TryCatch #0 {Exception -> 0x0028, blocks: (B:8:0x001e, B:23:0x006e, B:9:0x0023, B:17:0x004b, B:19:0x004f, B:20:0x0053, B:14:0x002e), top: B:32:0x0006 }] */
        /* JADX WARN: Code duplicated, block: B:22:0x006d A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object objFirstOrNull;
            List<TaskSubmissionEntity> listEmptyList;
            Object objExportTaskSubmissionsCsv;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            try {
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        objFirstOrNull = FlowKt.firstOrNull(TeacherViewModel.this.repository.getSubmissionsForTask(this.$task.getTkid()), this);
                        if (objFirstOrNull == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        listEmptyList = (List) objFirstOrNull;
                        if (listEmptyList == null) {
                            listEmptyList = CollectionsKt.emptyList();
                        }
                        this.L$0 = SpillingKt.nullOutSpilledVariable(listEmptyList);
                        this.label = 2;
                        objExportTaskSubmissionsCsv = TeacherViewModel.this.repository.exportTaskSubmissionsCsv(this.$task, listEmptyList, this);
                        if (objExportTaskSubmissionsCsv == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        String csv = (String) objExportTaskSubmissionsCsv;
                        this.$onComplete.invoke(csv);
                        return Unit.INSTANCE;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        objFirstOrNull = $result;
                        listEmptyList = (List) objFirstOrNull;
                        if (listEmptyList == null) {
                            listEmptyList = CollectionsKt.emptyList();
                        }
                        this.L$0 = SpillingKt.nullOutSpilledVariable(listEmptyList);
                        this.label = 2;
                        objExportTaskSubmissionsCsv = TeacherViewModel.this.repository.exportTaskSubmissionsCsv(this.$task, listEmptyList, this);
                        if (objExportTaskSubmissionsCsv == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        String csv2 = (String) objExportTaskSubmissionsCsv;
                        this.$onComplete.invoke(csv2);
                        return Unit.INSTANCE;
                    case 2:
                        ResultKt.throwOnFailure($result);
                        objExportTaskSubmissionsCsv = $result;
                        String csv3 = (String) objExportTaskSubmissionsCsv;
                        this.$onComplete.invoke(csv3);
                        return Unit.INSTANCE;
                    case 3:
                        ResultKt.throwOnFailure($result);
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } catch (Exception e) {
                Log.e("TeacherViewModel", "Error exporting task submissions CSV", e);
                MutableSharedFlow mutableSharedFlow = TeacherViewModel.this._userMessage;
                String localizedMessage = e.getLocalizedMessage();
                this.L$0 = SpillingKt.nullOutSpilledVariable(e);
                this.label = 3;
                if (mutableSharedFlow.emit("Failed to generate task CSV: " + localizedMessage, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
        }
    }

    public final void exportTaskSubmissionsData(TaskEntity task, Function1<? super String, Unit> onComplete) {
        Intrinsics.checkNotNullParameter(task, "task");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08051(task, onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$exportCustomTasksCsv$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$exportCustomTasksCsv$1", f = "TeacherViewModel.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2}, l = {1094, 1100, 1107}, m = "invokeSuspend", n = {"classroom", "rawApproved", "$this$map\\1", "$this$mapTo\\2", "destination\\2", "item\\2", "st\\3", "$i$f$map\\1\\1092", "$i$f$mapTo\\2\\1451", "$i$a$-map-TeacherViewModel$exportCustomTasksCsv$1$approved$1\\3\\1453\\0", "classroom", "rawApproved", "approved", "submissionsMap", "task", "e"}, s = {"L$0", "L$1", "L$2", "L$4", "L$5", "L$7", "L$8", "I$0", "I$1", "I$2", "L$0", "L$1", "L$2", "L$3", "L$5", "L$0"})
    static final class C08041 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ CsvExportUtils.TasksExportConfig $config;
        final /* synthetic */ Function1<String, Unit> $onComplete;
        final /* synthetic */ List<TaskEntity> $selectedTasks;
        int I$0;
        int I$1;
        int I$2;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        Object L$8;
        Object L$9;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C08041(List<TaskEntity> list, CsvExportUtils.TasksExportConfig tasksExportConfig, Function1<? super String, Unit> function1, Continuation<? super C08041> continuation) {
            super(2, continuation);
            this.$selectedTasks = list;
            this.$config = tasksExportConfig;
            this.$onComplete = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08041(this.$selectedTasks, this.$config, this.$onComplete, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08041) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:26:0x00e0 A[Catch: Exception -> 0x0205, TryCatch #5 {Exception -> 0x0205, blocks: (B:24:0x00da, B:26:0x00e0, B:28:0x00f6), top: B:83:0x00da }] */
        /* JADX WARN: Code duplicated, block: B:28:0x00f6 A[Catch: Exception -> 0x0205, TRY_LEAVE, TryCatch #5 {Exception -> 0x0205, blocks: (B:24:0x00da, B:26:0x00e0, B:28:0x00f6), top: B:83:0x00da }] */
        /* JADX WARN: Code duplicated, block: B:32:0x0135 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:33:0x0136  */
        /* JADX WARN: Code duplicated, block: B:36:0x0142 A[Catch: Exception -> 0x016e, TryCatch #1 {Exception -> 0x016e, blocks: (B:34:0x013e, B:36:0x0142, B:38:0x014e, B:43:0x0178), top: B:76:0x013e }] */
        /* JADX WARN: Code duplicated, block: B:39:0x016b  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x0136 -> B:76:0x013e). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:42:0x0173 -> B:43:0x0178). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x01da -> B:79:0x01dd). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r31) {
            /*
                Method dump skipped, instruction units count: 624
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.C08041.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public final void exportCustomTasksCsv(List<TaskEntity> selectedTasks, CsvExportUtils.TasksExportConfig config, Function1<? super String, Unit> onComplete) {
        Intrinsics.checkNotNullParameter(selectedTasks, "selectedTasks");
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08041(selectedTasks, config, onComplete, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$resetAllState$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$resetAllState$1", f = "TeacherViewModel.kt", i = {}, l = {1115}, m = "invokeSuspend", n = {}, s = {})
    static final class C08101 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C08101(Continuation<? super C08101> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08101(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08101) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (TeacherViewModel.this.repository.deleteAllData(this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final void resetAllState() {
        disconnectDevice();
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08101(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TeacherViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1", f = "TeacherViewModel.kt", i = {}, l = {1121}, m = "invokeSuspend", n = {}, s = {})
    static final class C08071 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C08071(Continuation<? super C08071> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TeacherViewModel.this.new C08071(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C08071) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    SharedFlow<BlePacket> incomingPackets = TeacherViewModel.this.getBleManager().getIncomingPackets();
                    final TeacherViewModel teacherViewModel = TeacherViewModel.this;
                    this.label = 1;
                    if (incomingPackets.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TeacherViewModel.observeIncomingPackets.1.1

                        /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1, reason: invalid class name and collision with other inner class name */
                        /* JADX INFO: compiled from: TeacherViewModel.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1", f = "TeacherViewModel.kt", i = {0, 0, 1, 1, 2, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 13, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 22, 22, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26}, l = {1221, 1222, 1229, 1230, 1238, 1253, 1267, 1270, 1273, 1290, 1291, 1295, 1306, 1318, 1323, 1325, 1458, 1331, 1333, 1370, 1371, 1384, 1387, 1390, 1406, 1407, 1411}, m = "invokeSuspend", n = {"classroom", "pending", "classroom", "pending", "classroom", "classroom", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "timestamp", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "timestamp", "graceMins", "currentMinutes", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "timestamp", "graceMins", "currentMinutes", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "timestamp", "graceMins", "currentMinutes", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "currentTasks", "sortedTasks", "task", "timestamp", "graceMins", "currentMinutes", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "timestamp", "graceMins", "currentMinutes", "alreadyReceived", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "timestamp", "graceMins", "currentMinutes", "alreadyReceived", "classroom", "studentEntry", "targetCid", "dateFormat", "todayDateStr", "existingRecord", "graceTimeStr", "calendar", "attendanceStatus", "acceptPacket", "currentTasks", "sortedTasks", "timestamp", "graceMins", "currentMinutes", "classroom", "studentEntry", "classroom", "classroom", "isApproved", "scoreInt", "timestamp", "classroom", "student", "studentDisplayName", "isApproved", "scoreInt", "timestamp", "classroom", "student", "studentDisplayName", "taskList", "taskEntity", "taskTitle", "$this$withLock_u24default\\6", "isApproved", "scoreInt", "timestamp", "taskMaxScore", "$i$f$withLock\\6\\1330", "classroom", "student", "studentDisplayName", "taskList", "taskEntity", "taskTitle", "$this$withLock_u24default\\6", "isApproved", "scoreInt", "timestamp", "taskMaxScore", "$i$f$withLock\\6\\1330", "$i$a$-withLock$default-TeacherViewModel$observeIncomingPackets$1$1$1$6\\7\\1460\\0", "classroom", "student", "studentDisplayName", "taskList", "taskEntity", "taskTitle", "$this$withLock_u24default\\6", "existingSub\\7", "isApproved", "scoreInt", "timestamp", "taskMaxScore", "$i$f$withLock\\6\\1330", "$i$a$-withLock$default-TeacherViewModel$observeIncomingPackets$1$1$1$6\\7\\1460\\0", "classroom", "student", "studentDisplayName", "taskList", "taskEntity", "taskTitle", "markedPacket", "scoreMsg", "isApproved", "scoreInt", "timestamp", "taskMaxScore", "classroom", "student", "studentDisplayName", "taskList", "taskEntity", "taskTitle", "markedPacket", "scoreMsg", "isApproved", "scoreInt", "timestamp", "taskMaxScore", "classroom", "classroom", "isApproved", "classroom", "currentTasks", "sortedTasks", "task", "isApproved", "classroom", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "isApproved", "alreadyReceived", "classroom", "currentTasks", "sortedTasks", "task", "scoreStr", "tkPacket", "isApproved", "alreadyReceived", "classroom", "isApproved"}, s = {"L$0", "L$1", "L$0", "L$1", "L$0", "L$0", "L$0", "L$1", "L$2", "L$3", "L$4", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$13", "J$0", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$13", "L$14", "L$15", "J$0", "I$0", "I$1", "Z$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$13", "L$14", "L$15", "J$0", "I$0", "I$1", "Z$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "J$0", "I$0", "I$1", "L$0", "L$1", "L$0", "L$0", "Z$0", "I$0", "J$0", "L$0", "L$1", "L$2", "Z$0", "I$0", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "Z$0", "I$0", "J$0", "I$1", "I$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "Z$0", "I$0", "J$0", "I$1", "I$2", "I$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$9", "Z$0", "I$0", "J$0", "I$1", "I$2", "I$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "Z$0", "I$0", "J$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "Z$0", "I$0", "J$0", "I$1", "L$0", "L$0", "Z$0", "L$0", "L$1", "L$2", "L$4", "Z$0", "L$0", "L$1", "L$2", "L$4", "L$5", "L$6", "Z$0", "Z$1", "L$0", "L$1", "L$2", "L$4", "L$5", "L$6", "Z$0", "Z$1", "L$0", "Z$0"})
                        static final class C01711 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ BlePacket $packet;
                            int I$0;
                            int I$1;
                            int I$2;
                            int I$3;
                            long J$0;
                            Object L$0;
                            Object L$1;
                            Object L$10;
                            Object L$11;
                            Object L$12;
                            Object L$13;
                            Object L$14;
                            Object L$15;
                            Object L$2;
                            Object L$3;
                            Object L$4;
                            Object L$5;
                            Object L$6;
                            Object L$7;
                            Object L$8;
                            Object L$9;
                            boolean Z$0;
                            boolean Z$1;
                            int label;
                            final /* synthetic */ TeacherViewModel this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            C01711(BlePacket blePacket, TeacherViewModel teacherViewModel, Continuation<? super C01711> continuation) {
                                super(2, continuation);
                                this.$packet = blePacket;
                                this.this$0 = teacherViewModel;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new C01711(this.$packet, this.this$0, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                return ((C01711) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            /* JADX WARN: Code duplicated, block: B:160:0x0b31  */
                            /* JADX WARN: Code duplicated, block: B:162:0x0bb9 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:163:0x0bba  */
                            /* JADX WARN: Code duplicated, block: B:166:0x0bcb  */
                            /* JADX WARN: Code duplicated, block: B:167:0x0bd6  */
                            /* JADX WARN: Code duplicated, block: B:169:0x0bdc  */
                            /* JADX WARN: Code duplicated, block: B:170:0x0bff  */
                            /* JADX WARN: Code duplicated, block: B:173:0x0cfd A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:174:0x0cfe  */
                            /* JADX WARN: Code duplicated, block: B:177:0x0d80 A[RETURN] */
                            /* JADX WARN: Code duplicated, block: B:178:0x0d81  */
                            /* JADX WARN: Code duplicated, block: B:65:0x0648  */
                            /* JADX WARN: Code duplicated, block: B:66:0x064d  */
                            /* JADX WARN: Code duplicated, block: B:68:0x0650  */
                            /* JADX WARN: Code duplicated, block: B:69:0x0655 A[PHI: r1
                              0x0655: PHI (r1v49 java.lang.String) = (r1v48 java.lang.String), (r1v53 java.lang.String), (r1v61 java.lang.String) binds: [B:47:0x05e7, B:49:0x05f3, B:67:0x064e] A[DONT_GENERATE, DONT_INLINE]] */
                            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:166:0x0bcb -> B:158:0x0b2b). Please report as a decompilation issue!!! */
                            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:178:0x0d81 -> B:179:0x0d94). Please report as a decompilation issue!!! */
                            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:338:0x155c -> B:332:0x150d). Please report as a decompilation issue!!! */
                            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:351:0x1653 -> B:352:0x1657). Please report as a decompilation issue!!! */
                            /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                                jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                                	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                                	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                                	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                                */
                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final java.lang.Object invokeSuspend(java.lang.Object r52) {
                                /*
                                    Method dump skipped, instruction units count: 5884
                                    To view this dump add '--comments-level debug' option
                                */
                                throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel.C08071.C01701.C01711.invokeSuspend(java.lang.Object):java.lang.Object");
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$1, reason: invalid class name and collision with other inner class name */
                            /* JADX INFO: compiled from: TeacherViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$1", f = "TeacherViewModel.kt", i = {}, l = {1141}, m = "invokeSuspend", n = {}, s = {})
                            static final class C01721 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                final /* synthetic */ ClassroomEntity $savedCls;
                                int label;
                                final /* synthetic */ TeacherViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                C01721(TeacherViewModel teacherViewModel, ClassroomEntity classroomEntity, Continuation<? super C01721> continuation) {
                                    super(2, continuation);
                                    this.this$0 = teacherViewModel;
                                    this.$savedCls = classroomEntity;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new C01721(this.this$0, this.$savedCls, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((C01721) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (this.this$0.repository.saveClassroom(this.$savedCls, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(this.this$0.getApplication());
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$2, reason: invalid class name */
                            /* JADX INFO: compiled from: TeacherViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$2", f = "TeacherViewModel.kt", i = {}, l = {1155}, m = "invokeSuspend", n = {}, s = {})
                            static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                final /* synthetic */ ClassroomEntity $classroom;
                                int label;
                                final /* synthetic */ TeacherViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass2(TeacherViewModel teacherViewModel, ClassroomEntity classroomEntity, Continuation<? super AnonymousClass2> continuation) {
                                    super(2, continuation);
                                    this.this$0 = teacherViewModel;
                                    this.$classroom = classroomEntity;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass2(this.this$0, this.$classroom, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
                                            if (this.this$0.repository.unregisterClassroom(this.$classroom.getCid(), this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    return Unit.INSTANCE;
                                }
                            }

                            /* JADX INFO: renamed from: com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$3, reason: invalid class name */
                            /* JADX INFO: compiled from: TeacherViewModel.kt */
                            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$observeIncomingPackets$1$1$1$3", f = "TeacherViewModel.kt", i = {0, 1, 2, 2, 2, 2, 3, 3, 3, 3}, l = {1169, 1171, 1181, 1184}, m = "invokeSuspend", n = {"classroom", "classroom", "classroom", "it\\1", "savedCls\\1", "$i$a$-let-TeacherViewModel$observeIncomingPackets$1$1$1$3$1\\1\\1179\\0", "classroom", "it\\1", "savedCls\\1", "$i$a$-let-TeacherViewModel$observeIncomingPackets$1$1$1$3$1\\1\\1179\\0"}, s = {"L$0", "L$0", "L$0", "L$2", "L$3", "I$0", "L$0", "L$2", "L$3", "I$0"})
                            static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                final /* synthetic */ TeacherViewModel this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                AnonymousClass3(TeacherViewModel teacherViewModel, Continuation<? super AnonymousClass3> continuation) {
                                    super(2, continuation);
                                    this.this$0 = teacherViewModel;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                    return new AnonymousClass3(this.this$0, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                                    return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                /* JADX WARN: Code duplicated, block: B:21:0x00a8 A[RETURN] */
                                /* JADX WARN: Code duplicated, block: B:25:0x00c3  */
                                /* JADX WARN: Code duplicated, block: B:27:0x00d9  */
                                /* JADX WARN: Code duplicated, block: B:29:0x0117 A[RETURN] */
                                /* JADX WARN: Code duplicated, block: B:30:0x0118  */
                                /* JADX WARN: Code duplicated, block: B:33:0x014f A[RETURN] */
                                /* JADX WARN: Code duplicated, block: B:34:0x0150  */
                                /* JADX WARN: Code duplicated, block: B:37:0x0167  */
                                /* JADX WARN: Code duplicated, block: B:40:0x017f  */
                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object $result) {
                                    ClassroomEntity classroom;
                                    Object value;
                                    RegDialogStep regDialogStep;
                                    TeacherViewModel teacherViewModel;
                                    ClassroomEntity tempClassroomToRegister;
                                    TeacherViewModel teacherViewModel2;
                                    ClassroomEntity classroomEntityCopy$default;
                                    CalisRepository calisRepository;
                                    ClassroomEntity classroom2;
                                    int i;
                                    ClassroomEntity classroomEntity;
                                    TeacherViewModel teacherViewModel3;
                                    ClassroomEntity classroomEntity2;
                                    TeacherViewModel teacherViewModel4;
                                    ClassroomEntity classroom3;
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            classroom = this.this$0.getActiveClassroom().getValue();
                                            if (classroom == null) {
                                                classroom = this.this$0.getCurrentClassroom().getValue();
                                            }
                                            if (classroom == null || !classroom.isActiveSession()) {
                                                this.this$0.getBleManager().setAuthenticated(true);
                                                value = this.this$0._regDialogStep.getValue();
                                                regDialogStep = RegDialogStep.AUTHENTICATING;
                                                teacherViewModel = this.this$0;
                                                if (value == regDialogStep) {
                                                    teacherViewModel._regDialogStep.setValue(RegDialogStep.SUCCESS);
                                                    this.this$0.setWaitingForReconnect(false);
                                                    tempClassroomToRegister = this.this$0.getTempClassroomToRegister();
                                                    if (tempClassroomToRegister != null) {
                                                        teacherViewModel2 = this.this$0;
                                                        classroomEntityCopy$default = ClassroomEntity.copy$default(tempClassroomToRegister, null, null, null, null, null, null, null, null, false, true, null, 1535, null);
                                                        calisRepository = teacherViewModel2.repository;
                                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                        this.L$1 = teacherViewModel2;
                                                        this.L$2 = SpillingKt.nullOutSpilledVariable(tempClassroomToRegister);
                                                        this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntityCopy$default);
                                                        this.I$0 = 0;
                                                        this.label = 3;
                                                        if (calisRepository.saveClassroom(classroomEntityCopy$default, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        classroom2 = classroom;
                                                        i = 0;
                                                        classroomEntity = classroomEntityCopy$default;
                                                        teacherViewModel3 = teacherViewModel2;
                                                        classroomEntity2 = tempClassroomToRegister;
                                                        ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(teacherViewModel3.getApplication());
                                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                                        this.L$1 = teacherViewModel3;
                                                        this.L$2 = SpillingKt.nullOutSpilledVariable(classroomEntity2);
                                                        this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntity);
                                                        this.I$0 = i;
                                                        this.label = 4;
                                                        if (DelayKt.delay(250L, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        teacherViewModel4 = teacherViewModel3;
                                                        classroom3 = classroom2;
                                                        if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                            Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                            teacherViewModel4.startSession();
                                                        }
                                                    }
                                                    this.this$0._userMessage.tryEmit("Classroom registered!");
                                                } else {
                                                    teacherViewModel.setWaitingForReconnect(false);
                                                    this.this$0._userMessage.tryEmit("Device ready!");
                                                }
                                            } else {
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                this.label = 1;
                                                if (this.this$0.repository.updateClassroomSession(classroom.getCid(), false, this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                this.label = 2;
                                                if (DelayKt.delay(150L, this) == coroutine_suspended) {
                                                    return coroutine_suspended;
                                                }
                                                this.this$0.getBleManager().setAuthenticated(true);
                                                value = this.this$0._regDialogStep.getValue();
                                                regDialogStep = RegDialogStep.AUTHENTICATING;
                                                teacherViewModel = this.this$0;
                                                if (value == regDialogStep) {
                                                    teacherViewModel._regDialogStep.setValue(RegDialogStep.SUCCESS);
                                                    this.this$0.setWaitingForReconnect(false);
                                                    tempClassroomToRegister = this.this$0.getTempClassroomToRegister();
                                                    if (tempClassroomToRegister != null) {
                                                        teacherViewModel2 = this.this$0;
                                                        classroomEntityCopy$default = ClassroomEntity.copy$default(tempClassroomToRegister, null, null, null, null, null, null, null, null, false, true, null, 1535, null);
                                                        calisRepository = teacherViewModel2.repository;
                                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                        this.L$1 = teacherViewModel2;
                                                        this.L$2 = SpillingKt.nullOutSpilledVariable(tempClassroomToRegister);
                                                        this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntityCopy$default);
                                                        this.I$0 = 0;
                                                        this.label = 3;
                                                        if (calisRepository.saveClassroom(classroomEntityCopy$default, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        classroom2 = classroom;
                                                        i = 0;
                                                        classroomEntity = classroomEntityCopy$default;
                                                        teacherViewModel3 = teacherViewModel2;
                                                        classroomEntity2 = tempClassroomToRegister;
                                                        ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(teacherViewModel3.getApplication());
                                                        this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                                        this.L$1 = teacherViewModel3;
                                                        this.L$2 = SpillingKt.nullOutSpilledVariable(classroomEntity2);
                                                        this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntity);
                                                        this.I$0 = i;
                                                        this.label = 4;
                                                        if (DelayKt.delay(250L, this) == coroutine_suspended) {
                                                            return coroutine_suspended;
                                                        }
                                                        teacherViewModel4 = teacherViewModel3;
                                                        classroom3 = classroom2;
                                                        if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                            Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                            teacherViewModel4.startSession();
                                                        }
                                                    }
                                                    this.this$0._userMessage.tryEmit("Classroom registered!");
                                                } else {
                                                    teacherViewModel.setWaitingForReconnect(false);
                                                    this.this$0._userMessage.tryEmit("Device ready!");
                                                }
                                            }
                                            CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, this.this$0.getApplication(), false, 2, null);
                                            return Unit.INSTANCE;
                                        case 1:
                                            classroom = (ClassroomEntity) this.L$0;
                                            ResultKt.throwOnFailure($result);
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                            this.label = 2;
                                            if (DelayKt.delay(150L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            this.this$0.getBleManager().setAuthenticated(true);
                                            value = this.this$0._regDialogStep.getValue();
                                            regDialogStep = RegDialogStep.AUTHENTICATING;
                                            teacherViewModel = this.this$0;
                                            if (value == regDialogStep) {
                                                teacherViewModel._regDialogStep.setValue(RegDialogStep.SUCCESS);
                                                this.this$0.setWaitingForReconnect(false);
                                                tempClassroomToRegister = this.this$0.getTempClassroomToRegister();
                                                if (tempClassroomToRegister != null) {
                                                    teacherViewModel2 = this.this$0;
                                                    classroomEntityCopy$default = ClassroomEntity.copy$default(tempClassroomToRegister, null, null, null, null, null, null, null, null, false, true, null, 1535, null);
                                                    calisRepository = teacherViewModel2.repository;
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                    this.L$1 = teacherViewModel2;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(tempClassroomToRegister);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntityCopy$default);
                                                    this.I$0 = 0;
                                                    this.label = 3;
                                                    if (calisRepository.saveClassroom(classroomEntityCopy$default, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    classroom2 = classroom;
                                                    i = 0;
                                                    classroomEntity = classroomEntityCopy$default;
                                                    teacherViewModel3 = teacherViewModel2;
                                                    classroomEntity2 = tempClassroomToRegister;
                                                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(teacherViewModel3.getApplication());
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                                    this.L$1 = teacherViewModel3;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(classroomEntity2);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntity);
                                                    this.I$0 = i;
                                                    this.label = 4;
                                                    if (DelayKt.delay(250L, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    teacherViewModel4 = teacherViewModel3;
                                                    classroom3 = classroom2;
                                                    if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                        Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                        teacherViewModel4.startSession();
                                                    }
                                                }
                                                this.this$0._userMessage.tryEmit("Classroom registered!");
                                            } else {
                                                teacherViewModel.setWaitingForReconnect(false);
                                                this.this$0._userMessage.tryEmit("Device ready!");
                                            }
                                            CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, this.this$0.getApplication(), false, 2, null);
                                            return Unit.INSTANCE;
                                        case 2:
                                            classroom = (ClassroomEntity) this.L$0;
                                            ResultKt.throwOnFailure($result);
                                            this.this$0.getBleManager().setAuthenticated(true);
                                            value = this.this$0._regDialogStep.getValue();
                                            regDialogStep = RegDialogStep.AUTHENTICATING;
                                            teacherViewModel = this.this$0;
                                            if (value == regDialogStep) {
                                                teacherViewModel._regDialogStep.setValue(RegDialogStep.SUCCESS);
                                                this.this$0.setWaitingForReconnect(false);
                                                tempClassroomToRegister = this.this$0.getTempClassroomToRegister();
                                                if (tempClassroomToRegister != null) {
                                                    teacherViewModel2 = this.this$0;
                                                    classroomEntityCopy$default = ClassroomEntity.copy$default(tempClassroomToRegister, null, null, null, null, null, null, null, null, false, true, null, 1535, null);
                                                    calisRepository = teacherViewModel2.repository;
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(classroom);
                                                    this.L$1 = teacherViewModel2;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(tempClassroomToRegister);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntityCopy$default);
                                                    this.I$0 = 0;
                                                    this.label = 3;
                                                    if (calisRepository.saveClassroom(classroomEntityCopy$default, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    classroom2 = classroom;
                                                    i = 0;
                                                    classroomEntity = classroomEntityCopy$default;
                                                    teacherViewModel3 = teacherViewModel2;
                                                    classroomEntity2 = tempClassroomToRegister;
                                                    ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(teacherViewModel3.getApplication());
                                                    this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                                    this.L$1 = teacherViewModel3;
                                                    this.L$2 = SpillingKt.nullOutSpilledVariable(classroomEntity2);
                                                    this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntity);
                                                    this.I$0 = i;
                                                    this.label = 4;
                                                    if (DelayKt.delay(250L, this) == coroutine_suspended) {
                                                        return coroutine_suspended;
                                                    }
                                                    teacherViewModel4 = teacherViewModel3;
                                                    classroom3 = classroom2;
                                                    if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                        Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                        teacherViewModel4.startSession();
                                                    }
                                                }
                                                this.this$0._userMessage.tryEmit("Classroom registered!");
                                            } else {
                                                teacherViewModel.setWaitingForReconnect(false);
                                                this.this$0._userMessage.tryEmit("Device ready!");
                                            }
                                            CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, this.this$0.getApplication(), false, 2, null);
                                            return Unit.INSTANCE;
                                        case 3:
                                            i = this.I$0;
                                            classroomEntity = (ClassroomEntity) this.L$3;
                                            classroomEntity2 = (ClassroomEntity) this.L$2;
                                            teacherViewModel3 = (TeacherViewModel) this.L$1;
                                            classroom2 = (ClassroomEntity) this.L$0;
                                            ResultKt.throwOnFailure($result);
                                            ReminderNotificationHelper.INSTANCE.checkAndPostSessionReminder(teacherViewModel3.getApplication());
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(classroom2);
                                            this.L$1 = teacherViewModel3;
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(classroomEntity2);
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(classroomEntity);
                                            this.I$0 = i;
                                            this.label = 4;
                                            if (DelayKt.delay(250L, this) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            teacherViewModel4 = teacherViewModel3;
                                            classroom3 = classroom2;
                                            if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                teacherViewModel4.startSession();
                                            }
                                            this.this$0._userMessage.tryEmit("Classroom registered!");
                                            CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, this.this$0.getApplication(), false, 2, null);
                                            return Unit.INSTANCE;
                                        case 4:
                                            int i2 = this.I$0;
                                            teacherViewModel4 = (TeacherViewModel) this.L$1;
                                            classroom3 = (ClassroomEntity) this.L$0;
                                            ResultKt.throwOnFailure($result);
                                            if (teacherViewModel4.getApplication().getSharedPreferences("calis_auth_prefs", 0).getBoolean("auto_start_session", true)) {
                                                Log.d("CALIS", "Auto-starting session after successful registration and auth");
                                                teacherViewModel4.startSession();
                                            }
                                            this.this$0._userMessage.tryEmit("Classroom registered!");
                                            CalisBleService.Companion.updateNotification$default(CalisBleService.INSTANCE, this.this$0.getApplication(), false, 2, null);
                                            return Unit.INSTANCE;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                }
                            }

                            static final Unit invokeSuspend$lambda$2(TeacherViewModel this$0, ApprovedStudentEntity $studentEntry, boolean success) {
                                this$0.getBleManager().clearTransactionState();
                                BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new TeacherViewModel$observeIncomingPackets$1$1$1$4$1(this$0, $studentEntry, null), 3, null);
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$3(TeacherViewModel this$0, BlePacket $packet, boolean success) {
                                this$0.getBleManager().clearTransactionState();
                                BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this$0), null, null, new TeacherViewModel$observeIncomingPackets$1$1$1$5$1(this$0, $packet, null), 3, null);
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$6(TeacherViewModel this$0, boolean it) {
                                this$0.getBleManager().clearTransactionState();
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$7(TeacherViewModel this$0, boolean it) {
                                this$0.getBleManager().clearTransactionState();
                                return Unit.INSTANCE;
                            }

                            static final Unit invokeSuspend$lambda$9(TeacherViewModel this$0, boolean it) {
                                this$0.getBleManager().clearTransactionState();
                                return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((BlePacket) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(BlePacket packet, Continuation<? super Unit> continuation) {
                            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(teacherViewModel), null, null, new C01711(packet, teacherViewModel, null), 3, null);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    private final void observeIncomingPackets() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C08071(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int parseTimeToMinutes(String raw) {
        int hour;
        String trimmed = StringsKt.trim((CharSequence) raw).toString().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(trimmed, "toUpperCase(...)");
        if ((trimmed.length() == 0) || Intrinsics.areEqual(trimmed, "N/A")) {
            return -1;
        }
        boolean isPM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "PM", false, 2, (Object) null);
        boolean isAM = StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "AM", false, 2, (Object) null);
        String clean = StringsKt.trim((CharSequence) StringsKt.replace$default(StringsKt.replace$default(trimmed, "AM", "", false, 4, (Object) null), "PM", "", false, 4, (Object) null)).toString();
        List parts = StringsKt.split$default((CharSequence) clean, new String[]{ServerSentEventKt.COLON}, false, 0, 6, (Object) null);
        int min = 0;
        if (parts.size() >= 2) {
            Integer intOrNull = StringsKt.toIntOrNull((String) parts.get(0));
            hour = intOrNull != null ? intOrNull.intValue() : 0;
            Integer intOrNull2 = StringsKt.toIntOrNull((String) parts.get(1));
            min = intOrNull2 != null ? intOrNull2.intValue() : 0;
        } else if (clean.length() >= 3) {
            Integer intOrNull3 = StringsKt.toIntOrNull(StringsKt.dropLast(clean, 2));
            hour = intOrNull3 != null ? intOrNull3.intValue() : 0;
            Integer intOrNull4 = StringsKt.toIntOrNull(StringsKt.takeLast(clean, 2));
            min = intOrNull4 != null ? intOrNull4.intValue() : 0;
        } else {
            Integer intOrNull5 = StringsKt.toIntOrNull(clean);
            hour = intOrNull5 != null ? intOrNull5.intValue() : 0;
        }
        if (isPM && hour < 12) {
            hour += 12;
        }
        if (isAM && hour == 12) {
            hour = 0;
        }
        return (hour * 60) + min;
    }
}
