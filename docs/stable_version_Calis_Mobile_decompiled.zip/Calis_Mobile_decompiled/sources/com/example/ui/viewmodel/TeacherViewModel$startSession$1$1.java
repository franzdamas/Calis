package com.example.ui.viewmodel;

import com.example.data.db.ClassroomEntity;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: TeacherViewModel.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.viewmodel.TeacherViewModel$startSession$1$1", f = "TeacherViewModel.kt", i = {1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3}, l = {781, 786, 792, 803}, m = "invokeSuspend", n = {"students", "todayDateStr", "students", "todayDateStr", "existingLogs", "existingStudentIds", "student", "timestamp", "students", "todayDateStr", "existingLogs", "existingStudentIds", "timestamp"}, s = {"L$0", "L$1", "L$0", "L$1", "L$2", "L$3", "L$5", "J$0", "L$0", "L$1", "L$2", "L$3", "J$0"})
final class TeacherViewModel$startSession$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ ClassroomEntity $classroom;
    long J$0;
    Object L$0;
    Object L$1;
    Object L$2;
    Object L$3;
    Object L$4;
    Object L$5;
    int label;
    final /* synthetic */ TeacherViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TeacherViewModel$startSession$1$1(TeacherViewModel teacherViewModel, ClassroomEntity classroomEntity, Continuation<? super TeacherViewModel$startSession$1$1> continuation) {
        super(2, continuation);
        this.this$0 = teacherViewModel;
        this.$classroom = classroomEntity;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new TeacherViewModel$startSession$1$1(this.this$0, this.$classroom, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((TeacherViewModel$startSession$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARN: Code duplicated, block: B:23:0x011d  */
    /* JADX WARN: Code duplicated, block: B:27:0x017a A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:28:0x017b  */
    /* JADX WARN: Code duplicated, block: B:33:0x01c4 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:34:0x01c5  */
    /* JADX WARN: Code duplicated, block: B:37:0x0183 A[SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:28:0x017b -> B:29:0x017e). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:28:0x017b
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object r22) {
        /*
            Method dump skipped, instruction units count: 472
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.ui.viewmodel.TeacherViewModel$startSession$1$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
