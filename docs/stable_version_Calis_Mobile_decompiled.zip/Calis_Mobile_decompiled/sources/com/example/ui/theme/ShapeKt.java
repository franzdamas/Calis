package com.example.ui.theme;

import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.Shapes;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Shape.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"ModernShapes", "Landroidx/compose/material3/Shapes;", "getModernShapes", "()Landroidx/compose/material3/Shapes;", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ShapeKt {
    private static final Shapes ModernShapes = new Shapes(RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(4)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(6)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)));

    public static final Shapes getModernShapes() {
        return ModernShapes;
    }
}
