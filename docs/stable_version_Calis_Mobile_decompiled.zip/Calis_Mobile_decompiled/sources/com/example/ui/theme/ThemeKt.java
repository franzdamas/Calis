package com.example.ui.theme;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import androidx.compose.foundation.DarkThemeKt;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.ContentColorKt;
import androidx.compose.material3.DynamicTonalPaletteKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalKt;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ProvidedValue;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.DensityKt;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a4\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00062\u0011\u0010\b\u001a\r\u0012\u0004\u0012\u00020\u00040\t¢\u0006\u0002\b\nH\u0007¢\u0006\u0002\u0010\u000b\u001a\u0019\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u000fH\u0007¢\u0006\u0004\b\u0010\u0010\u0011\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"DarkColorScheme", "Landroidx/compose/material3/ColorScheme;", "LightColorScheme", "CalisMobileTheme", "", "darkTheme", "", "dynamicColor", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "calisTextFieldColors", "Landroidx/compose/material3/TextFieldColors;", "containerColor", "Landroidx/compose/ui/graphics/Color;", "calisTextFieldColors-Iv8Zu3U", "(JLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/TextFieldColors;", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ThemeKt {
    private static final ColorScheme DarkColorScheme = ColorSchemeKt.m1932darkColorSchemeCXl9yA$default(ColorKt.getCalisPrimaryBlueLight(), androidx.compose.ui.graphics.ColorKt.Color(4278671749L), androidx.compose.ui.graphics.ColorKt.Color(4278413729L), ColorKt.getCalisPrimaryContainer(), 0, ColorKt.getCalisPrimaryBlueLight(), 0, androidx.compose.ui.graphics.ColorKt.Color(4278413729L), ColorKt.getCalisPrimaryContainer(), ColorKt.getCalisTertiaryTeal(), 0, 0, 0, ColorKt.getCalisDarkBackground(), androidx.compose.ui.graphics.ColorKt.Color(4294507260L), ColorKt.getCalisDarkSurface(), androidx.compose.ui.graphics.ColorKt.Color(4294507260L), ColorKt.getCalisDarkCard(), androidx.compose.ui.graphics.ColorKt.Color(4287931320L), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -517040, 15, null);
    private static final ColorScheme LightColorScheme;

    static final Unit CalisMobileTheme$lambda$6(boolean z, boolean z2, Function2 function2, int i, int i2, Composer composer, int i3) {
        CalisMobileTheme(z, z2, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static {
        long calisPrimaryBlue = ColorKt.getCalisPrimaryBlue();
        long jM4196getWhite0d7_KjU = Color.INSTANCE.m4196getWhite0d7_KjU();
        long calisPrimaryContainer = ColorKt.getCalisPrimaryContainer();
        long calisOnPrimaryContainer = ColorKt.getCalisOnPrimaryContainer();
        long calisPrimaryBlue2 = ColorKt.getCalisPrimaryBlue();
        long jM4196getWhite0d7_KjU2 = Color.INSTANCE.m4196getWhite0d7_KjU();
        long calisPrimaryContainer2 = ColorKt.getCalisPrimaryContainer();
        long calisOnPrimaryContainer2 = ColorKt.getCalisOnPrimaryContainer();
        long calisTertiaryTeal = ColorKt.getCalisTertiaryTeal();
        long calisTertiaryContainer = ColorKt.getCalisTertiaryContainer();
        long calisOnTertiaryContainer = ColorKt.getCalisOnTertiaryContainer();
        long calisLightBackground = ColorKt.getCalisLightBackground();
        long jM4196getWhite0d7_KjU3 = Color.INSTANCE.m4196getWhite0d7_KjU();
        long jColor = androidx.compose.ui.graphics.ColorKt.Color(4294507260L);
        long jM4196getWhite0d7_KjU4 = Color.INSTANCE.m4196getWhite0d7_KjU();
        long jM4196getWhite0d7_KjU5 = Color.INSTANCE.m4196getWhite0d7_KjU();
        long jM4196getWhite0d7_KjU6 = Color.INSTANCE.m4196getWhite0d7_KjU();
        LightColorScheme = ColorSchemeKt.m1936lightColorSchemeCXl9yA$default(calisPrimaryBlue, jM4196getWhite0d7_KjU, calisPrimaryContainer, calisOnPrimaryContainer, 0L, calisPrimaryBlue2, jM4196getWhite0d7_KjU2, calisPrimaryContainer2, calisOnPrimaryContainer2, calisTertiaryTeal, 0L, calisTertiaryContainer, calisOnTertiaryContainer, calisLightBackground, androidx.compose.ui.graphics.ColorKt.Color(4279179050L), jM4196getWhite0d7_KjU3, androidx.compose.ui.graphics.ColorKt.Color(4279179050L), androidx.compose.ui.graphics.ColorKt.Color(4294047225L), androidx.compose.ui.graphics.ColorKt.Color(4282865001L), Color.INSTANCE.m4194getTransparent0d7_KjU(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, jM4196getWhite0d7_KjU4, Color.INSTANCE.m4196getWhite0d7_KjU(), Color.INSTANCE.m4196getWhite0d7_KjU(), androidx.compose.ui.graphics.ColorKt.Color(4294047225L), jM4196getWhite0d7_KjU6, jM4196getWhite0d7_KjU5, jColor, 535823376, 0, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void CalisMobileTheme(boolean z, boolean z2, final Function2<? super Composer, ? super Integer, Unit> content, Composer composer, final int i, final int i2) {
        final boolean zIsSystemInDarkTheme;
        boolean z3;
        final ColorScheme colorSchemeDynamicDarkColorScheme;
        char c;
        Object obj;
        final boolean z4;
        final boolean z5;
        Object obj2;
        Intrinsics.checkNotNullParameter(content, "content");
        Composer composerStartRestartGroup = composer.startRestartGroup(1322222763);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(CalisMobileTheme)P(1,2)99@3537L7,111@3980L7,112@4031L7,113@4070L7,138@5403L411,150@5956L314,147@5820L450:Theme.kt#75kw8w");
        int i3 = i;
        if ((i & 6) == 0) {
            if ((i2 & 1) == 0) {
                zIsSystemInDarkTheme = z;
                int i4 = composerStartRestartGroup.changed(zIsSystemInDarkTheme) ? 4 : 2;
                i3 |= i4;
            } else {
                zIsSystemInDarkTheme = z;
            }
            i3 |= i4;
        } else {
            zIsSystemInDarkTheme = z;
        }
        int i5 = i2 & 2;
        if (i5 != 0) {
            i3 |= 48;
            z3 = z2;
        } else if ((i & 48) == 0) {
            z3 = z2;
            i3 |= composerStartRestartGroup.changed(z3) ? 32 : 16;
        } else {
            z3 = z2;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(content) ? 256 : 128;
        }
        if ((i3 & 147) == 146 && composerStartRestartGroup.getSkipping()) {
            composerStartRestartGroup.skipToGroupEnd();
            z4 = zIsSystemInDarkTheme;
            z5 = z3;
        } else {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "86@3077L21");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 1) != 0) {
                    i3 &= -15;
                }
            } else {
                if ((i2 & 1) != 0) {
                    zIsSystemInDarkTheme = DarkThemeKt.isSystemInDarkTheme(composerStartRestartGroup, 0);
                    i3 &= -15;
                }
                if (i5 != 0) {
                    z3 = false;
                }
            }
            composerStartRestartGroup.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1322222763, i3, -1, "com.example.ui.theme.CalisMobileTheme (Theme.kt:89)");
            }
            if (z3 && Build.VERSION.SDK_INT >= 31) {
                composerStartRestartGroup.startReplaceGroup(1193524636);
                ComposerKt.sourceInformation(composerStartRestartGroup, "92@3320L7");
                ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC:CompositionLocal.kt#9igjgp");
                Object objConsume = composerStartRestartGroup.consume(localContext);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Context context = (Context) objConsume;
                colorSchemeDynamicDarkColorScheme = zIsSystemInDarkTheme ? DynamicTonalPaletteKt.dynamicDarkColorScheme(context) : DynamicTonalPaletteKt.dynamicLightColorScheme(context);
                composerStartRestartGroup.endReplaceGroup();
            } else if (zIsSystemInDarkTheme) {
                composerStartRestartGroup.startReplaceGroup(-654230342);
                composerStartRestartGroup.endReplaceGroup();
                colorSchemeDynamicDarkColorScheme = DarkColorScheme;
            } else {
                composerStartRestartGroup.startReplaceGroup(-654229317);
                composerStartRestartGroup.endReplaceGroup();
                colorSchemeDynamicDarkColorScheme = LightColorScheme;
            }
            ProvidableCompositionLocal<View> localView = AndroidCompositionLocals_androidKt.getLocalView();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume2 = composerStartRestartGroup.consume(localView);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final View view = (View) objConsume2;
            if (view.isInEditMode()) {
                c = 1;
                composerStartRestartGroup.startReplaceGroup(1190266071);
            } else {
                composerStartRestartGroup.startReplaceGroup(1193822856);
                ComposerKt.sourceInformation(composerStartRestartGroup, "101@3594L340,101@3583L351");
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -654225601, "CC(remember):Theme.kt#9igjgp");
                c = 1;
                boolean zChangedInstance = ((((i3 & 14) ^ 6) > 4 && composerStartRestartGroup.changed(zIsSystemInDarkTheme)) || (i3 & 6) == 4) | composerStartRestartGroup.changedInstance(view);
                Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    obj2 = new Function0() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return ThemeKt.CalisMobileTheme$lambda$1$lambda$0(view, zIsSystemInDarkTheme);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(obj2);
                } else {
                    obj2 = objRememberedValue;
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                EffectsKt.SideEffect((Function0) obj2, composerStartRestartGroup, 0);
            }
            composerStartRestartGroup.endReplaceGroup();
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume3 = composerStartRestartGroup.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            Density density = (Density) objConsume3;
            ProvidableCompositionLocal<Configuration> localConfiguration = AndroidCompositionLocals_androidKt.getLocalConfiguration();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume4 = composerStartRestartGroup.consume(localConfiguration);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            Configuration configuration = (Configuration) objConsume4;
            ProvidableCompositionLocal<Context> localContext2 = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume5 = composerStartRestartGroup.consume(localContext2);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            DisplayMetrics displayMetrics = ((Context) objConsume5).getResources().getDisplayMetrics();
            float fMin = Math.min(displayMetrics.widthPixels, displayMetrics.heightPixels);
            float f = (configuration.smallestScreenWidthDp >= 600 ? c : (char) 0) != 0 ? 1.25f : 1.0f;
            boolean z6 = zIsSystemInDarkTheme;
            float fCoerceAtMost = RangesKt.coerceAtMost(density.getDensity(), RangesKt.coerceAtLeast(fMin / 392.0f, 1.0f)) * f;
            float fCoerceIn = RangesKt.coerceIn(density.getFontScale(), 0.85f, 1.0f) * f;
            Density Density = DensityKt.Density(fCoerceAtMost, fCoerceIn);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -654167642, "CC(remember):Theme.kt#9igjgp");
            boolean zChanged = composerStartRestartGroup.changed(configuration) | composerStartRestartGroup.changed(fCoerceAtMost) | composerStartRestartGroup.changed(fCoerceIn) | composerStartRestartGroup.changed(f);
            Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
            if (zChanged || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                Configuration configuration2 = new Configuration(configuration);
                configuration2.fontScale = fCoerceIn;
                configuration2.densityDpi = (int) (fCoerceAtMost * 160.0f);
                configuration2.screenWidthDp = (int) (configuration.screenWidthDp / f);
                configuration2.screenHeightDp = (int) (configuration.screenHeightDp / f);
                composerStartRestartGroup.updateRememberedValue(configuration2);
                obj = configuration2;
            } else {
                obj = objRememberedValue2;
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ProvidedValue[] providedValueArr = new ProvidedValue[2];
            providedValueArr[0] = CompositionLocalsKt.getLocalDensity().provides(Density);
            providedValueArr[c] = AndroidCompositionLocals_androidKt.getLocalConfiguration().provides((Configuration) obj);
            CompositionLocalKt.CompositionLocalProvider((ProvidedValue<?>[]) providedValueArr, ComposableLambdaKt.rememberComposableLambda(-1349052437, c, new Function2() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj3, Object obj4) {
                    return ThemeKt.CalisMobileTheme$lambda$5(colorSchemeDynamicDarkColorScheme, content, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, ProvidedValue.$stable | 48);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            z4 = z6;
            z5 = z3;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj3, Object obj4) {
                    return ThemeKt.CalisMobileTheme$lambda$6(z4, z5, content, i, i2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            });
        }
    }

    static final Unit CalisMobileTheme$lambda$1$lambda$0(View $view, boolean $darkTheme) {
        Context context = $view.getContext();
        Activity activity = context instanceof Activity ? (Activity) context : null;
        Window window = activity != null ? activity.getWindow() : null;
        if (window != null) {
            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, $view);
            Intrinsics.checkNotNullExpressionValue(controller, "getInsetsController(...)");
            controller.setAppearanceLightStatusBars(!$darkTheme);
            controller.setAppearanceLightNavigationBars(!$darkTheme);
        }
        return Unit.INSTANCE;
    }

    static final Unit CalisMobileTheme$lambda$5(final ColorScheme $colorScheme, final Function2 $content, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C155@6101L163,151@5966L298:Theme.kt#75kw8w");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1349052437, $changed, -1, "com.example.ui.theme.CalisMobileTheme.<anonymous> (Theme.kt:151)");
            }
            MaterialThemeKt.MaterialTheme($colorScheme, ShapeKt.getModernShapes(), TypeKt.getTypography(), ComposableLambdaKt.rememberComposableLambda(-1512949865, true, new Function2() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ThemeKt.CalisMobileTheme$lambda$5$lambda$4($colorScheme, $content, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 3504, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit CalisMobileTheme$lambda$5$lambda$4(ColorScheme $colorScheme, Function2 $content, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C156@6115L139:Theme.kt#75kw8w");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1512949865, $changed, -1, "com.example.ui.theme.CalisMobileTheme.<anonymous>.<anonymous> (Theme.kt:156)");
            }
            CompositionLocalKt.CompositionLocalProvider(ContentColorKt.getLocalContentColor().provides(Color.m4149boximpl($colorScheme.getOnSurface())), (Function2<? super Composer, ? super Integer, Unit>) $content, $composer, ProvidedValue.$stable);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: calisTextFieldColors-Iv8Zu3U, reason: not valid java name */
    public static final TextFieldColors m7058calisTextFieldColorsIv8Zu3U(long containerColor, Composer $composer, int $changed, int i) {
        ComposerKt.sourceInformationMarkerStart($composer, 2004379038, "C(calisTextFieldColors)P(0:c#ui.graphics.Color)166@6354L11,168@6466L11,169@6528L11,170@6589L11,171@6650L11,172@6727L11,173@6806L11,174@6880L11,175@6975L11,178@7153L11,179@7215L11,180@7275L11,167@6421L875:Theme.kt#75kw8w");
        long containerColor2 = (i & 1) != 0 ? MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurface() : containerColor;
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(2004379038, $changed, -1, "com.example.ui.theme.calisTextFieldColors (Theme.kt:167)");
        }
        OutlinedTextFieldDefaults outlinedTextFieldDefaults = OutlinedTextFieldDefaults.INSTANCE;
        long onSurface = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurface();
        long onSurface2 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurface();
        long primary = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary();
        long onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
        long onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
        long onSurfaceVariant3 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
        long onSurfaceVariant4 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
        long jM4157copywmQWz5c = Color.m4157copywmQWz5c(onSurfaceVariant4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant4) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant4) : 0.0f);
        long onSurfaceVariant5 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
        long jM4157copywmQWz5c2 = Color.m4157copywmQWz5c(onSurfaceVariant5, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant5) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant5) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant5) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant5) : 0.0f);
        TextFieldColors textFieldColorsM2343colors0hiis_0 = outlinedTextFieldDefaults.m2343colors0hiis_0(onSurface, onSurface2, 0L, 0L, containerColor2, containerColor2, 0L, 0L, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), 0L, null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOutlineVariant(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, primary, onSurfaceVariant, 0L, 0L, jM4157copywmQWz5c, jM4157copywmQWz5c2, 0L, 0L, onSurfaceVariant2, onSurfaceVariant3, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, (($changed << 12) & 57344) | (($changed << 15) & 458752), 0, 0, 0, 3072, 1719658188, 4092);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        ComposerKt.sourceInformationMarkerEnd($composer);
        return textFieldColorsM2343colors0hiis_0;
    }
}
