package com.example.ui.theme;

import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.graphics.Brush;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.TileMode;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b*\n\u0002\u0018\u0002\n\u0002\b\u0007\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0013\u0010\u001d\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003\"\u0013\u0010\u001f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b \u0010\u0003\"\u0013\u0010!\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\"\u0010\u0003\"\u0013\u0010#\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b$\u0010\u0003\"\u0013\u0010%\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b&\u0010\u0003\"\u0013\u0010'\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b(\u0010\u0003\"\u0013\u0010)\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b*\u0010\u0003\"\u0011\u0010+\u001a\u00020,¢\u0006\b\n\u0000\u001a\u0004\b-\u0010.\"\u0011\u0010/\u001a\u00020,¢\u0006\b\n\u0000\u001a\u0004\b0\u0010.\"\u0011\u00101\u001a\u00020,¢\u0006\b\n\u0000\u001a\u0004\b2\u0010.¨\u00063"}, d2 = {"CalisPrimaryBlue", "Landroidx/compose/ui/graphics/Color;", "getCalisPrimaryBlue", "()J", "J", "CalisPrimaryBlueLight", "getCalisPrimaryBlueLight", "CalisPrimaryContainer", "getCalisPrimaryContainer", "CalisOnPrimaryContainer", "getCalisOnPrimaryContainer", "CalisSecondaryTeal", "getCalisSecondaryTeal", "CalisSecondaryTealLight", "getCalisSecondaryTealLight", "CalisSecondaryContainer", "getCalisSecondaryContainer", "CalisOnSecondaryContainer", "getCalisOnSecondaryContainer", "CalisTertiaryTeal", "getCalisTertiaryTeal", "CalisTertiaryContainer", "getCalisTertiaryContainer", "CalisOnTertiaryContainer", "getCalisOnTertiaryContainer", "CalisDarkBackground", "getCalisDarkBackground", "CalisDarkSurface", "getCalisDarkSurface", "CalisDarkCard", "getCalisDarkCard", "CalisLightBackground", "getCalisLightBackground", "CalisLightSurface", "getCalisLightSurface", "CalisLightCard", "getCalisLightCard", "StatusPresentGreen", "getStatusPresentGreen", "StatusLateAmber", "getStatusLateAmber", "StatusAbsentRed", "getStatusAbsentRed", "PrimaryAccentGradient", "Landroidx/compose/ui/graphics/Brush;", "getPrimaryAccentGradient", "()Landroidx/compose/ui/graphics/Brush;", "SecondaryAccentGradient", "getSecondaryAccentGradient", "AccentGradient", "getAccentGradient", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ColorKt {
    private static final long CalisPrimaryBlue = androidx.compose.ui.graphics.ColorKt.Color(4278355143L);
    private static final long CalisPrimaryBlueLight = androidx.compose.ui.graphics.ColorKt.Color(4281908728L);
    private static final long CalisPrimaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4293982719L);
    private static final long CalisOnPrimaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4278413729L);
    private static final long CalisSecondaryTeal = androidx.compose.ui.graphics.ColorKt.Color(4279080072L);
    private static final long CalisSecondaryTealLight = androidx.compose.ui.graphics.ColorKt.Color(4281193663L);
    private static final long CalisSecondaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4293983738L);
    private static final long CalisOnSecondaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4279203438L);
    private static final long CalisTertiaryTeal = androidx.compose.ui.graphics.ColorKt.Color(4278630100L);
    private static final long CalisTertiaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4293721855L);
    private static final long CalisOnTertiaryContainer = androidx.compose.ui.graphics.ColorKt.Color(4278751666L);
    private static final long CalisDarkBackground = androidx.compose.ui.graphics.ColorKt.Color(4279179050L);
    private static final long CalisDarkSurface = androidx.compose.ui.graphics.ColorKt.Color(4280166715L);
    private static final long CalisDarkCard = androidx.compose.ui.graphics.ColorKt.Color(4281549141L);
    private static final long CalisLightBackground = androidx.compose.ui.graphics.ColorKt.Color(4294507260L);
    private static final long CalisLightSurface = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long CalisLightCard = androidx.compose.ui.graphics.ColorKt.Color(4294047225L);
    private static final long StatusPresentGreen = androidx.compose.ui.graphics.ColorKt.Color(4278355143L);
    private static final long StatusLateAmber = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
    private static final long StatusAbsentRed = androidx.compose.ui.graphics.ColorKt.Color(4293870660L);
    private static final Brush PrimaryAccentGradient = Brush.INSTANCE.m4120linearGradientmHitzGk((List<Color>) CollectionsKt.listOf((Object[]) new Color[]{Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279150057L)), Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4281908728L))}), (14 & 2) != 0 ? Offset.INSTANCE.m3934getZeroF1C5BW0() : 0, (14 & 4) != 0 ? Offset.INSTANCE.m3932getInfiniteF1C5BW0() : 0, (14 & 8) != 0 ? TileMode.INSTANCE.m4531getClamp3opZhB0() : 0);
    private static final Brush SecondaryAccentGradient = Brush.INSTANCE.m4120linearGradientmHitzGk((List<Color>) CollectionsKt.listOf((Object[]) new Color[]{Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4278630100L)), Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4284999929L))}), (14 & 2) != 0 ? Offset.INSTANCE.m3934getZeroF1C5BW0() : 0, (14 & 4) != 0 ? Offset.INSTANCE.m3932getInfiniteF1C5BW0() : 0, (14 & 8) != 0 ? TileMode.INSTANCE.m4531getClamp3opZhB0() : 0);
    private static final Brush AccentGradient = Brush.INSTANCE.m4120linearGradientmHitzGk((List<Color>) CollectionsKt.listOf((Object[]) new Color[]{Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279150057L)), Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4281908728L))}), (14 & 2) != 0 ? Offset.INSTANCE.m3934getZeroF1C5BW0() : 0, (14 & 4) != 0 ? Offset.INSTANCE.m3932getInfiniteF1C5BW0() : 0, (14 & 8) != 0 ? TileMode.INSTANCE.m4531getClamp3opZhB0() : 0);

    public static final long getCalisPrimaryBlue() {
        return CalisPrimaryBlue;
    }

    public static final long getCalisPrimaryBlueLight() {
        return CalisPrimaryBlueLight;
    }

    public static final long getCalisPrimaryContainer() {
        return CalisPrimaryContainer;
    }

    public static final long getCalisOnPrimaryContainer() {
        return CalisOnPrimaryContainer;
    }

    public static final long getCalisSecondaryTeal() {
        return CalisSecondaryTeal;
    }

    public static final long getCalisSecondaryTealLight() {
        return CalisSecondaryTealLight;
    }

    public static final long getCalisSecondaryContainer() {
        return CalisSecondaryContainer;
    }

    public static final long getCalisOnSecondaryContainer() {
        return CalisOnSecondaryContainer;
    }

    public static final long getCalisTertiaryTeal() {
        return CalisTertiaryTeal;
    }

    public static final long getCalisTertiaryContainer() {
        return CalisTertiaryContainer;
    }

    public static final long getCalisOnTertiaryContainer() {
        return CalisOnTertiaryContainer;
    }

    public static final long getCalisDarkBackground() {
        return CalisDarkBackground;
    }

    public static final long getCalisDarkSurface() {
        return CalisDarkSurface;
    }

    public static final long getCalisDarkCard() {
        return CalisDarkCard;
    }

    public static final long getCalisLightBackground() {
        return CalisLightBackground;
    }

    public static final long getCalisLightSurface() {
        return CalisLightSurface;
    }

    public static final long getCalisLightCard() {
        return CalisLightCard;
    }

    public static final long getStatusPresentGreen() {
        return StatusPresentGreen;
    }

    public static final long getStatusLateAmber() {
        return StatusLateAmber;
    }

    public static final long getStatusAbsentRed() {
        return StatusAbsentRed;
    }

    public static final Brush getPrimaryAccentGradient() {
        return PrimaryAccentGradient;
    }

    public static final Brush getSecondaryAccentGradient() {
        return SecondaryAccentGradient;
    }

    public static final Brush getAccentGradient() {
        return AccentGradient;
    }
}
