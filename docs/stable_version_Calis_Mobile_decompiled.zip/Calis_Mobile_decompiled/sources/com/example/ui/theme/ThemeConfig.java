package com.example.ui.theme;

import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R+\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00058F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\u000b\u0010\f\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\r"}, d2 = {"Lcom/example/ui/theme/ThemeConfig;", "", "<init>", "()V", "<set-?>", "Lcom/example/ui/theme/AppThemeMode;", "themeMode", "getThemeMode", "()Lcom/example/ui/theme/AppThemeMode;", "setThemeMode", "(Lcom/example/ui/theme/AppThemeMode;)V", "themeMode$delegate", "Landroidx/compose/runtime/MutableState;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ThemeConfig {
    public static final int $stable = 0;
    public static final ThemeConfig INSTANCE = new ThemeConfig();

    /* JADX INFO: renamed from: themeMode$delegate, reason: from kotlin metadata */
    private static final MutableState themeMode = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(AppThemeMode.LIGHT, null, 2, null);

    private ThemeConfig() {
    }

    public final AppThemeMode getThemeMode() {
        return (AppThemeMode) themeMode.getValue();
    }

    public final void setThemeMode(AppThemeMode appThemeMode) {
        Intrinsics.checkNotNullParameter(appThemeMode, "<set-?>");
        themeMode.setValue(appThemeMode);
    }
}
