package com.example;

/* JADX INFO: loaded from: classes8.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.aistudio.calismobile.xqkrtp";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
